import Vue from 'vue';
import Player from '../../plugins/player'


Vue.directive('player', {
	inserted(el, binding) {
		let params = binding.value;
		new Player(el, params.url, params.options || {});
	}
})