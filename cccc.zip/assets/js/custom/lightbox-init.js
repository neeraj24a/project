jQuery(function onReady() {
  
  jQuery(document).on('click', '.ajax-link', function(e) {
    e.preventDefault();
    jQuery.ajax({
      url: e.target.href,
      type: 'get',
      success: function(responce) {
        jQuery.featherlight(responce, {
          type: 'html'
        });
      },
      error: function(reason) {
        console.log(reason)
      }
    })
    
  })
})