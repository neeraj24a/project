/**
 * trackController
 *
 * @description :: Server-side logic for managing tracks
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

let moment = require('moment');
var pager = require('sails-pager');
var slugify = require('slugify');
var Promise = require('bluebird');

module.exports = {
	new: function(req, res) {
    res.view('admin/track/new');
  },
  create: (req, res) => {
    let params = req.params.all();
    console.log(params);
    let slug = slugify(params.artist +' '+ params.title, {
                replacement: '-',    // replace spaces with replacement
                remove: /[$*_+~.()'"!\-:@]/g,        // regex to remove characters
                lower: true          // result in lower case
              });
    let title = params.title;
    let artist = params.artist;
    let search = title.replace(/ *\([^)]*\) */g, "") +' '+ artist.replace(/ *\([^)]*\) */g, "");
    let rsearch = artist.replace(/ *\([^)]*\) */g, "") +' '+ title.replace(/ *\([^)]*\) */g, "");

    Track.create(Object.assign(params, { uploadedBy: req.session.user.login },{ slug: slug },{ search: search },{ rsearch: rsearch }), (err, track) => {
      if(err) {
        return res.serverError(err);
      }
      if (req.param('json')) res.json(track);
      else res.redirect('/admin/track');
    })
  },
  edit: (req, res, next) => {
    Track.findOne( req.param('id')).populate('remix').exec((err, track) => {
      if(err) return next(err);
      if(!track) return next();
      Genrefilter.find({}, function(err, genres) {
        if(req.param('json')) {
          res.json(track);
          return;
        }
        res.view('admin/track/edit',{
          genres: genres,
          track: track
        })
      })
    })
  },
  update: (req, res) => {
    let params = req.params.all();
    if(!params.id) {
      if(req.isSocket || params.json) {
        return res.json(data);
      }
      else {
        return res.badRequest(`This id (${params.id}) doesn\'t found`)
      }
    }
    Track.update(params.id, req.params.all()).exec((err, track) =>  {
      if(req.isSocket || req.param('json')) {
        if(err) {
          return res.json({
            error: err
          });
        }
        sails.sockets.blast('track-updated', track[0]);
        return res.json(track);
      }
      if(err) {
        return res.badRequest(err);
      }
      sails.sockets.blast('track-updated', track[0]);
      res.redirect('/admin/track');
    })
  },
  addStream: (req, res) => {
    let params = req.params.all();
    if(!params.id) {
      if(req.isSocket || params.json) {
        return res.json(data);
      }
      else {
        return res.badRequest(`This id (${params.id}) doesn\'t found`)
      }
    }
    let userId = req.session.user ? req.session.user.id : null;
    Stream.create({ track: params.id, type: false ,user: userId }, (err, track) => {
      if(err) {
        return res.serverError(err);
      }
    })
  },
  addDownload: (req, res) => {
    let params = req.params.all();
    console.log(params);
    if(!params.id) {
      if(req.isSocket || params.json) {
        return res.json(data);
      }
      else {
        return res.badRequest(`This id (${params.id}) doesn\'t found`)
      }
    }
    let userId = req.session.user ? req.session.user.id : null;
    console.log({ track: params.id, type: true,user: userId });
    Stream.create({ track: params.id, type: true ,user: userId }, (err, track) => {
      if(err) {
        return res.serverError(err);
      }
    })
  },
  searchAllRemixes: (req, res) => {
    Track.find({}).exec((error, updatedTracks) => {
      if(error) {
        sails.log(error)
        return;
      }
      updatedTracks.forEach(updatedTrack => {
        sails.log(updatedTrack.artist, updatedTrack.title)
        Track.find({
          artist: updatedTrack.artist,
					title: {
						contains: updatedTrack.title.substr(0, updatedTrack.title.indexOf('(')).trim()
					},
          // type: updatedTrack.type,
          id: {
            '!': updatedTrack.id
          }
        }).exec((error, tracks) => {
          if(error) {
            sails.log(error)
            return;
          }
          if(tracks.length) {
            let remix = tracks.map(item => item.id);
            console.log('Taked remix for: ',updatedTrack.artist, ' - ', updatedTrack.title, ' remixes count: ', remix.length)
            updatedTrack.remix = tracks.map(item => item.id);
            Track.update(updatedTrack.id, updatedTrack).exec((error, updated) => {
              if(error) {
                sails.log(error)
                return;
              }
              if(updated) sails.sockets.blast('track-updated', updated[0]);
            });
          }
        })
      })
    })
    return res.ok();
  },
  runCron: (req, res) => {
    let params = req.params.all();
    // Create date
    let dailyDate = moment(new Date()).subtract(1, 'day').startOf('day').format('YYYY-MM-DD');
    let weekDate = moment(new Date()).subtract(8, 'day').startOf('day').format('YYYY-MM-DD');
    let monthDate = moment(new Date()).subtract(31, 'day').startOf('day').format('YYYY-MM-DD');
    Track.query('UPDATE track SET track.day = 0 WHERE track.updatedAt <= ?', [ dailyDate ] ,function(err, rawResult) {
      if (err) { return res.serverError(err); }

      Track.query('UPDATE track SET track.week = 0 WHERE track.updatedAt <= ?', [ weekDate ] ,function(err, rawResult) {
        if (err) { return res.serverError(err); }
        Track.query('UPDATE track SET track.month = 0 WHERE track.updatedAt <= ?', [ monthDate ] ,function(err, rawResult) {
          if (err) { return res.serverError(err); }
          return res.ok();
        });
      });
    });
  },
  updateSearch: (req, res) => {
    Track.query("SELECT id, artist, title FROM track", function(err, rawResult){
      if(err){
        return res.serverError(err);
      }
      rawResult.forEach(function(track, index){
        let title = track.title;
        let artist = track.artist;
        if(title != null && artist != null){
          let search = title.replace(/ *\([^)]*\) */g, "") +' '+ artist.replace(/ *\([^)]*\) */g, "");
          let rsearch = artist.replace(/ *\([^)]*\) */g, "") +' '+ title.replace(/ *\([^)]*\) */g, "");
          let slug = slugify(title +' '+ artist, {
            replacement: '-',    // replace spaces with replacement
            remove: /[$*_+~.()'"!\-:@]/g,        // regex to remove characters
            lower: true          // result in lower case
          });
          Track.update(track.id, { search: search,rsearch: rsearch,slug: slug}).exec((err, tr) => {
            if(err){
              return res.serverError(err);
            }
            console.log('updated: '+track.id);
          })
        }
      });
    });
  },
  dayTrending: (req, res, next) => {
	let params = req.params.all();
	let type = params.search.query.type;
	let dailyDate = moment(new Date()).subtract(1, 'day').startOf('day').format('YYYY-MM-DD');
	let userId = req.session.user ? req.session.user.id : 'guest';
    let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
    let whereQry = "";
	console.log('day search filter');
	console.log(search);
	console.log(search.query.sort);
	let sort = '';
	if(search.query.hasOwnProperty('sort')){
		sort = ", "+search.query.sort;
	}
	if(search.query.hasOwnProperty('remixer')){
		whereQry += " AND t.remixer = '"+search.query.remixer+"'";
	}
	if(search.query.hasOwnProperty('toBpm')){
		whereQry += " AND t.bpm < '"+search.query.toBpm+"'";
	}
	if(search.query.hasOwnProperty('fromBpm')){
		whereQry += " AND t.bpm < '"+search.query.fromBpm+"'";
	}
	if(search.query.hasOwnProperty('genre')){
		whereQry += " AND t.genre = '"+search.query.genre+"'";
	}

	if(search.query.hasOwnProperty('subgenre')){
		whereQry += " AND t.subgenre = '"+search.query.subgenre+"'";
	}
	console.log(whereQry);
    let responseObj = {};
	responseObj['message'] = 'Data retrieved successfully';
    responseObj['tracks'] = [];
    responseObj['data'] = [];
	console.log("SELECT COUNT(*) as nos, t.* FROM `stream` s, `track` t WHERE s.type = 1 AND s.createdAt = '"+dailyDate+"' AND t.type = '"+type+"' AND s.track = t.id"+whereQry+" GROUP BY s.track Order BY nos DESC"+sort+" LIMIT 50");
	var trendingQueryAsync = Promise.promisify(Stream.query);
	trendingQueryAsync("SELECT COUNT(*) as nos, t.* FROM `stream` s, `track` t WHERE s.type = 1 AND s.createdAt = '"+dailyDate+"' AND t.type = '"+type+"' AND s.track = t.id"+whereQry+" GROUP BY s.track Order BY nos DESC"+sort+" LIMIT 50")
	.then(function(rawResult) {
		if (!rawResult) { return res.notFound(); }
		rawResult.forEach(function(track, index){
			track.remix = [];
		});
		responseObj.tracks = rawResult;
		responseObj.data = rawResult;
		return res.json(responseObj);
	}).catch(function (err) { return res.serverError(err); });
  },
  weekTrending: (req, res, next) => {
	let params = req.params.all();
	let type = params.search.query.type;
	
	let userId = req.session.user ? req.session.user.id : 'guest';
    let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
	console.log('week search filter');
	console.log(search);
	console.log(search.query);
    let startDate = moment(new Date()).subtract(1, 'day').startOf('day').format('YYYY-MM-DD');
    let weekDate = moment(new Date()).subtract(8, 'day').startOf('day').format('YYYY-MM-DD');
	let whereQry = "";
	let sort = '';
	if(search.query.hasOwnProperty('sort')){
		sort = ", "+search.query.sort;
	}
	if(search.query.hasOwnProperty('remixer')){
		whereQry += " AND t.remixer = '"+search.query.remixer+"'";
	}
	if(search.query.hasOwnProperty('toBpm')){
		whereQry += " AND t.bpm < '"+search.query.toBpm+"'";
	}
	if(search.query.hasOwnProperty('fromBpm')){
		whereQry += " AND t.bpm < '"+search.query.fromBpm+"'";
	}
	if(search.query.hasOwnProperty('genre')){
		whereQry += " AND t.genre = '"+search.query.genre+"'";
	}

	if(search.query.hasOwnProperty('subgenre')){
		whereQry += " AND t.subgenre = '"+search.query.subgenre+"'";
	}
	console.log(whereQry);
    let responseObj = {};
	responseObj['message'] = 'Data retrieved successfully';
    responseObj['tracks'] = [];
    responseObj['data'] = [];
	console.log("SELECT COUNT(*) as nos, t.* FROM `stream` s, `track` t WHERE s.type = 1 AND s.createdAt <= '"+startDate+"' AND s.createdAt >= '"+weekDate+"' AND t.type = '"+type+"' AND s.track = t.id"+whereQry+" GROUP BY s.track Order BY nos DESC"+sort+" LIMIT 50");
	var trendingQueryAsync = Promise.promisify(Stream.query);
	trendingQueryAsync("SELECT COUNT(*) as nos, t.* FROM `stream` s, `track` t WHERE s.type = 1 AND s.createdAt <= '"+startDate+"' AND s.createdAt >= '"+weekDate+"' AND t.type = '"+type+"' AND s.track = t.id"+whereQry+" GROUP BY s.track Order BY nos DESC"+sort+" LIMIT 50")
	.then(function(rawResult) {
		if (!rawResult) { return res.notFound(); }
		rawResult.forEach(function(track, index){
			track.remix = [];
		});
		responseObj.tracks = rawResult;
		responseObj.data = rawResult;
		return res.json(responseObj);
	}).catch(function (err) { return res.serverError(err); });
  },
  
  monthTrending: (req, res, next) => {
	let params = req.params.all();
	let type = params.search.query.type;
	
	let userId = req.session.user ? req.session.user.id : 'guest';
    let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
	console.log('month search filter');
	console.log(search);
	console.log(search.query);
    let startDate = moment(new Date()).subtract(1, 'day').startOf('day').format('YYYY-MM-DD');
    let monthDate = moment(new Date()).subtract(31, 'day').startOf('day').format('YYYY-MM-DD');
	let whereQry = "";
	let sort = '';
	if(search.query.hasOwnProperty('sort')){
		sort = ", "+search.query.sort;
	}
	if(search.query.hasOwnProperty('remixer')){
		whereQry += " AND t.remixer = '"+search.query.remixer+"'";
	}
	if(search.query.hasOwnProperty('toBpm')){
		whereQry += " AND t.bpm < '"+search.query.toBpm+"'";
	}
	if(search.query.hasOwnProperty('fromBpm')){
		whereQry += " AND t.bpm < '"+search.query.fromBpm+"'";
	}
	if(search.query.hasOwnProperty('genre')){
		whereQry += " AND t.genre = '"+search.query.genre+"'";
	}

	if(search.query.hasOwnProperty('subgenre')){
		whereQry += " AND t.subgenre = '"+search.query.subgenre+"'";
	}
	console.log(whereQry);
    let responseObj = {};
	responseObj['message'] = 'Data retrieved successfully';
    responseObj['tracks'] = [];
    responseObj['data'] = [];
	console.log("SELECT COUNT(*) as nos, t.* FROM `stream` s, `track` t WHERE s.type = 1 AND s.createdAt <= '"+startDate+"' AND s.createdAt >= '"+monthDate+"' AND t.type = '"+type+"' AND s.track = t.id"+whereQry+" GROUP BY s.track Order BY nos DESC"+sort+" LIMIT 50");
	var trendingQueryAsync = Promise.promisify(Stream.query);
	trendingQueryAsync("SELECT COUNT(*) as nos, t.* FROM `stream` s, `track` t WHERE s.type = 1 AND s.createdAt <= '"+startDate+"' AND s.createdAt >= '"+monthDate+"' AND t.type = '"+type+"' AND s.track = t.id"+whereQry+" GROUP BY s.track Order BY nos DESC"+sort+" LIMIT 50")
	.then(function(rawResult) {
		if (!rawResult) { return res.notFound(); }
		rawResult.forEach(function(track, index){
			track.remix = [];
		});
		responseObj.tracks = rawResult;
		responseObj.data = rawResult;
		return res.json(responseObj);
	}).catch(function (err) { return res.serverError(err); });
  },
  destroy: (req, res, next) => {
    sails.log.warn('Destroy track ', req.param('id'));
    Track.findOne( req.param('id'), (err, track) => {
      if(err) return next(err);
      if(!track) return next('track doesn\'t exist.');
      Track.destroy(req.param('id'), err => {
        if(err) return next(err);
      })
      if(req.isSocket) {
        res.ok();
      }
      else res.redirect('/admin/track');
    })
  },
  remixer: (req, res, next) => {
    Track.query("SELECT remixer FROM track WHERE remixer IS NOT NULL AND remixer <> '' GROUP BY remixer", function(err, rawResult){
      if(err){
        return next(err);
      }
      res.json(rawResult)
    });
  },
  'songDetails': (req, res, next) => {
    let params = req.params.all();
    let userId = req.session.user ? req.session.user.id : 'guest';
    let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
    let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 50));
    let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
    let searchParams = Object.assign({query: { sort: 'createdAt DESC' }, pagelimit: { page: page, limit: limit }}, search);

    Track.find({ slug: params.name }).limit(1)
    .then(function (record){
      if (!record) { 
        return res.notFound(); 
      }
      let title = record[0].title;
      let type = record[0].type;
      let len = title.indexOf("(");
      if(len != -1){
        var trimmedString = title.substring(0, len);
        title = trimmedString.trim();
      }
      searchParams.query.or = [{
        type: {
          contains: type
        },
        title: {
          contains: title
        }
      }];
      let getPagination = () => {
        return new Promise((resolve, reject) => {
          //Using Promises 
          pager.paginate(Track, searchParams.query, searchParams.pagelimit.page, limit, ['remix'], searchParams.query.sort ).then(function(records){
            records.tracks = records.data;
            records.searchFor = record[0];
            resolve(records);
          }).catch(function(err) {
              reject(err);
          });
        })
      }
  
      getPagination().then(responce => {
        if(req.param('json') || req.isSocket) {
          return res.json(Object.assign(responce, {ui: params.ui}))
        }
        else {
          return res.json(Object.assign(responce, {ui: params.ui}))
        }
      })
    })
    .catch(function (err) { 
      return res.serverError(err); 
    });
  },
  'artistDetails': (req, res, next) => {
    let params = req.params.all();
    let userId = req.session.user ? req.session.user.id : 'guest';
    let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
    let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 50));
    let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
    let searchParams = Object.assign({query: { sort: 'createdAt DESC' }, pagelimit: { page: page, limit: limit }}, search);
    let artistName = params.name;
    let lookFor = [' & ',' X ',' < ',' , ',', ',' feat ',' Feat. ',' ft ',' ft. ',' Ft. ',' Vs ',' vs '];
    let mtchChar = [];
    let artistsArr = [];
    lookFor.forEach(function(element, index){
      if(artistName.indexOf(element) != '-1'){
        mtchChar.push(element);
      }
    });
    if(mtchChar.length != 0){
      if(mtchChar.length == 1){
        searchParams.query.or = [];
        let arr = artistName.split(mtchChar);
        arr.forEach(function(a,index){
          let aFilter = {artist:{contains: a}};
          searchParams.query.or.push(aFilter);
        });
      } else {
        let i = 0;
        mtchChar.forEach(function(chr,index){
          if(artistName != undefined){
            let arr = artistName.split(chr);
            artistsArr.push(arr[0]);
            artistName = arr[1];
          }
        });
        artistsArr.forEach(function(a,index){
          let aFilter = {artist:{contains: a}};
          searchParams.query.or.push(aFilter);
        });
      }
    } else {
      searchParams.query.or = [{
        artist: {
          contains: artistName
        }
      }];
    //  searchParams.query.or.push({artist:{contains: artistName}});
    }
    let getPagination = () => {
      return new Promise((resolve, reject) => {
        //Using Promises 
        pager.paginate(Track, searchParams.query, searchParams.pagelimit.page, limit, ['remix'], searchParams.query.sort ).then(function(records){
          records.tracks = records.data;
          if(mtchChar.length > 1){
            records.searchFor = artistsArr.join(" & ");
          } else {
            records.searchFor = artistName;
          }
          resolve(records);
        }).catch(function(err) {
            reject(err);
        });
      })
    }

    getPagination().then(responce => {
      if(req.param('json') || req.isSocket) {
        return res.json(Object.assign(responce, {ui: params.ui}))
      }
      else {
        return res.json(Object.assign(responce, {ui: params.ui}))
      }
    })
    /*
    Track.find({ slug: params.name }).limit(1)
    .then(function (record){
      
      
    })
    .catch(function (err) { 
      return res.serverError(err); 
    });*/
  },
  index: (req, res, next) => {
    let params = req.params.all();
    let searchQuery = {};
    let forPagination = [];
    if(params.name) {
      searchQuery.or = [
        {
          artist: { contains: params.name }
        },
        {
          title: { contains: params.name }
        }
      ]
      forPagination.push(searchQuery.or)
    }
    if(params.genre) {
      searchQuery.genre = params.genre
      forPagination.push(searchQuery.genre)
    }
    if(params.subgenre) {
      searchQuery.subgenre = params.subgenre
      forPagination.push(searchQuery.subgenre)
    }
    if(params.date) {
      searchQuery.createdAt = JSON.parse(params.date);
    }
    let page = null, limit = null;
    if(params.page) {
      page = parseInt(params.page);
    }
    limit = params.limitPerPage ? params.limitPerPage : sails.session.settings ? sails.session.settings.trackPerPage : 50;
    if(params.sort) {
      searchQuery.sort = params.sort || 'popularity ASC'
    }
    

    sails.log.info('req params: ',params)
    sails.log.info('search params: ', searchQuery)

    
    let genreTask = new Promise((resolve, reject) => {
      Genrefilter
      .find()
      .exec((err, genres) => {
        if(err) return reject(err);
        return resolve({ genres: genres });
      });
    })
    let trackTask = new Promise((resolve, reject) => {
      Track
        .find(searchQuery)
        .populate('remix')
        .paginate({
          page: page,
          limit: limit || 9999
        })
        .exec((err, tracks) => {
          if(err) return reject(err);
          return resolve({ tracks: tracks });
        });
    })
    let getPagination = new Promise((resolve, reject) => {
      var currentPage = req.query.page || 1;
      var conditions = {active: true};

      //Using Promises 
      pager.paginate(Track, searchQuery, currentPage, limit, [], searchQuery.sort ).then(function(records){
        resolve({ pagination: records });
      }).catch(function(err) {
          reject(err);
      });
    })
    let tasks = [ trackTask ];
    if(req.param('json')) {
      
    }
    else {
      tasks.push(genreTask);
      tasks.push(getPagination);
    }
    Promise.all(tasks)
      .then(results => {
        let r = {};
        results.forEach(item => {
          Object.assign(r, item);
        })
        if(req.param('json') || req.isSocket) {
          res.json(r);
        }
        else {
          res.view('admin/track/index', r);
        }
      }).catch(reason => { 
        res.badRequest(reason);
      })
  },
  'search-autocomplete': (req, res, next) => {
    let params = req.params.all();
    let userId = req.session.user ? req.session.user.id : 'guest';
    let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
    let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 50));
    let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
    let searchParams = Object.assign({query: { sort: 'popularity DESC' }, pagelimit: { page: page, limit: limit }}, search);
    let getPagination = () => {
      return new Promise((resolve, reject) => {
        //Using Promises 
        pager.paginate(Track, searchParams.query, searchParams.pagelimit.page, limit, ['remix'], searchParams.query.sort ).then(function(records){
          records.tracks = records.data;
          resolve(records);
        }).catch(function(err) {
            reject(err);
        });
      })
    }


    getPagination().then(responce => {
      if(req.param('json') || req.isSocket) {
        return res.json(Object.assign(responce, {ui: params.ui}))
      }
      else {
        return res.json(Object.assign(responce, {ui: params.ui}))
      }
    })
  },
  show: (req, res, next) => {
    let params = req.params.all();
    if(!params.id) {
      if(req.isSocket || params.json) {
        return res.json(data);
      }
      else {
        return res.badRequest(`This id (${params.id}) doesn\'t found`)
      }
    }
    
    Track.findOne({ 'id': params.id }).populate('remix').exec((err, data) => {
      
      if(req.isSocket || params.json) {
        if(err) return res.json(err);
        return res.json(data);
      }
      if(err) return res.serverError(err);
      res.view('admin/track/show', {
        track: data
      })
    })
  },
  json: (req, res, next) => {
    let params = req.params.all();
    let searchParams = req.param('search');
    if(searchParams) {
      searchParams = JSON.parse(searchParams)
    }
    Track
      .find(searchParams || params || {})
      .exec((err, tracks) => {
        if(err) return next(err);
        res.json(tracks)
      })
  },
  trackfile: (req, res, next) => {
    res.sendfile(req.path.substr(1));
  }
};