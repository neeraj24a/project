/**
 * trackController
 *
 * @description :: Server-side logic for managing tracks
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

let moment = require('moment');
var pager = require('sails-pager');
var slugify = require('slugify');
var Promise = require('bluebird');
let fs = require('fs');
let path = require('path');
let rimraf = require('rimraf');
let request = require('request');

var os = require('os');
os.tmpDir = os.tmpdir;

let download = (req, res) => {
  let userId = req.session.user.id;
  console.log('Try download track', req.param('id'))
  if(req.session.user.isLocked) {
	return res.serverError(req.session.user.isLocked.msg);
  }
  UserTrack.findOne(req.param('id')).exec((err, track) => {
	if(err || !track) {
	  return res.serverError({ msg: 'Track not found!' });
	}
	sails.log('Track uploads: ', track.uploads[userId] || [])
	if(track.uploads[userId] && track.uploads[userId] >= 3 && !req.session.user.admin) {
	  sails.sockets.blast('error.' + userId, { error: 'You took maximum attempts to download' });
	  return res.serverError('You took maximum attempts to download.');
	}
	/*res.set({
	  'Content-Disposition': `attachment; filename="${track.name}"`
	})*/
	res.attachment(track.name);
	sails.session.redirectdownload = null;
	request(track.url).pipe(res).on('finish', function() {
	  let uploads = track.uploads;
	  uploads[userId] = (uploads[userId] || 0) + 1;
	  let newDownloaded = track.downloaded + 1;
	  let updatedAt = moment().format("YYYY-MM-DD HH:mm:ss");
	  Stream.create({ track: track.id, type: true ,user: userId }, (err, track) => {
		if(err) {
		  return res.serverError(err);
		}
		sails.sockets.blast('download stream added.');
	  })
	  UserTrack.update(track.id, { downloaded: newDownloaded, uploads: uploads, updatedAt: updatedAt }).exec((err, tr) => {
		if(err) return res.serverError(err);
		sails.sockets.blast('downloaded.' + userId, { track: tr });
	  })
	})
  })
}
module.exports = {
	addDjRemix: function(req, res){
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : null;
		let userName = req.session.user.login;
		if(userId === null){
			let responseObj = {'error': true, 'message': 'You have to be logged in.'};
			return res.json(responseObj);
		}
		res.setTimeout(0);
		let options = {
		  // adapter: require('skipper-s3'),
		  adapter: require('skipper-better-s3'),
		  bucket: sails.config.s3upload.bucket,
		  key: sails.config.s3upload.key,
		  secret: sails.config.s3upload.secret,
		  onProgress: progress => {
			sails.log('Upload progress:', progress)
		  }
		};
		req.file('name').upload(options, function whenDone(err, uploadedFiles) {
		  if (err) return res.serverError(err);
		  let promises = [];
		  _.each(uploadedFiles, function(file, index) {
			promises.push(new Promise((resolve, reject) => {
			  file.url = file.extra.Location;
			  delete file.fd;
			  resolve();
			}))
		  })
		  Promise.all(promises).then(function() {
			params.year = moment().year();
			params.type = 'remix';
			params.url = uploadedFiles[0].url; 
			let slug = slugify(params.artist +' '+ params.title, {
                replacement: '-',    // replace spaces with replacement
                remove: /[$*_+~.()'"!\-:@]/g,        // regex to remove characters
                lower: true          // result in lower case
              });
			let title = params.title;
			let artist = params.artist;
			let search = title.replace(/ *\([^)]*\) */g, "") +' '+ artist.replace(/ *\([^)]*\) */g, "");
			let rsearch = artist.replace(/ *\([^)]*\) */g, "") +' '+ title.replace(/ *\([^)]*\) */g, "");
			params.slug = slug;
			params.search = search;
			params.rsearch = rsearch;
			params.uploadedBy = userName;
			var origifile = req.file('name')._files[0].stream.filename;
			params.name = origifile;
			
			UserTrack.create(params, (err, track) => {
				if(err) {
				  console.log('Remix file upload error');
				  console.log(err);
				  let responseObj = {'error': true,'message': 'Something went wrong please try again.'};
				  return res.json(responseObj);
				}
				console.log('Remix Added Successfully');
				let responseObj = {'error': false,'message': 'File Uploaded Successfuly'};
				return res.json(responseObj);
			});
		  }, function(err) {
			res.serverError(err);
		  })
		});
	},
	update: (req, res) => {
		let params = req.params.all();
		if(!params.id) {
		  if(req.isSocket || params.json) {
			return res.json(data);
		  }
		  else {
			return res.badRequest(`This id (${params.id}) doesn\'t found`)
		  }
		}
		UserTrack.update(params.id, req.params.all()).exec((err, track) =>  {
		  if(req.isSocket || req.param('json')) {
			if(err) {
			  return res.json({
				error: err
			  });
			}
			sails.sockets.blast('track-updated', track[0]);
			return res.json(track);
		  }
		  if(err) {
			return res.badRequest(err);
		  }
		  sails.sockets.blast('track-updated', track[0]);
		  res.redirect('/uploads');
		})
	},
	destroy: (req, res, next) => {
		sails.log.warn('Destroy track ', req.param('id'));
		UserTrack.findOne( req.param('id'), (err, track) => {
		  if(err) return next(err);
		  if(!track) return next('track doesn\'t exist.');
		  Track.destroy(req.param('id'), err => {
			if(err) return next(err);
		  })
		  if(req.isSocket) {
			res.ok();
		  }
		  else res.redirect('/uploads');
		})
	},
	addOdest: function(req, res){
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : null;
		if(userId === null){
			return res.badRequest(`User not Logged In.`);
		}
		let userName = req.session.user.login;
		res.setTimeout(0);
		let options = {
		  // adapter: require('skipper-s3'),
		  adapter: require('skipper-better-s3'),
		  bucket: sails.config.s3upload.bucket,
		  key: sails.config.s3upload.key,
		  secret: sails.config.s3upload.secret,
		  onProgress: progress => {
			sails.log('Upload progress:', progress)
		  }
		};
		req.file('name').upload(options, function whenDone(err, uploadedFiles) {
		  if (err) return res.serverError(err);
		  let promises = [];
		  _.each(uploadedFiles, function(file, index) {
			promises.push(new Promise((resolve, reject) => {
			  file.url = file.extra.Location;
			  delete file.fd;
			  resolve();
			}))
		  })
		  Promise.all(promises).then(function() {
			params.year = moment().year();
			params.type = 'artist';
			params.url = uploadedFiles[0].url; 
			let slug = slugify(params.artist +' '+ params.title, {
                replacement: '-',    // replace spaces with replacement
                remove: /[$*_+~.()'"!\-:@]/g,        // regex to remove characters
                lower: true          // result in lower case
              });
			let title = params.title;
			let artist = params.artist;
			let search = title.replace(/ *\([^)]*\) */g, "") +' '+ artist.replace(/ *\([^)]*\) */g, "");
			let rsearch = artist.replace(/ *\([^)]*\) */g, "") +' '+ title.replace(/ *\([^)]*\) */g, "");
			params.slug = slug;
			params.search = search;
			params.rsearch = rsearch;
			params.uploadedBy = userName;
			var origifile = req.file('name')._files[0].stream.filename;
			params.name = origifile;
			
			UserTrack.create(params, (err, track) => {
				if(err) {
				  console.log('Artist file upload error');
				  console.log(err);
				  let responseObj = {'error': true,'message': 'Something went wrong please try again.'};
				  return res.json(responseObj);
				}
				console.log('Artist Added Successfully');
				let responseObj = {'error': false,'message': 'File Uploaded Successfuly'};
				return res.json(responseObj);
			});
		  }, function(err) {
			res.serverError(err);
		  })
		});
	},
	getTest: function(req, res){
		console.log(req.session.user);
		let responseObj = {'message': 'success', 'user': req.session.user};
		return res.json(responseObj);
	},
	getAlltracks: function(req, res){
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : 'guest';
		let userName = req.session.user ? req.session.user.login : '';
		let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
		let where = "";
		
		if(!req.session.user.admin){
			where = "WHERE uploadedBy = '"+userName+"'";
		}
		let orderBy = 'createdAt';
		let sel = '*';
		let sqlArray = [];
		if(search.query.hasOwnProperty('searchValue')){
			if(search.query.searchValue.indexOf("'") > -1){
				var arr = search.query.searchValue.split("'");
				search.query.searchValue = arr.join("\\'");
			}
			where += " MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE)";
			sel = "*, MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE) AS relevance";
			orderBy = 'relevance';
		}
		let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 20));
		let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
		let selct = 'SELECT '+sel+' FROM remix_odest_track ';
		let totalQry = '';
		if(!req.session.user.admin){
			selct = 'SELECT '+sel+' FROM remix_odest_track WHERE ';
			totalQry = 'SELECT COUNT(*) AS totalRow FROM remix_odest_track WHERE'+where;
		}
		if(req.session.user.admin){
			if(where.length > 0)
				totalQry = 'SELECT COUNT(*) AS totalRow FROM remix_odest_track WHERE'+where;
			else
				totalQry = 'SELECT COUNT(*) AS totalRow FROM remix_odest_track';
		}
		console.log(totalQry);
		let responseObj = {};
		responseObj['message'] = 'Data retrieved successfully';
		responseObj['tracks'] = [];
		responseObj['data'] = [];
		responseObj['meta'] = {'pageCount': 0, 'nextPage' : true, 'prevPage': true, 'total': 0, 'page': page, 'perPage': limit};
		console.log(selct+where+' ORDER BY '+orderBy+' DESC LIMIT '+ ((page  - 1) * limit) +', '+limit+'');
		var generalQueryAsync = Promise.promisify(Track.query);
		generalQueryAsync(selct+where+' ORDER BY '+orderBy+' DESC LIMIT '+ ((page  - 1) * limit) +', '+limit+'')
		.then(function(rawResult) {
			if (!rawResult) { return res.notFound(); }
			responseObj.tracks = rawResult;
			responseObj.data = rawResult;
			var totalQuery = Promise.promisify(Track.query);
			totalQuery(totalQry)
			.then(function(rawResult) {
				if (!rawResult) { return res.notFound(); }
				console.log('total');
				console.log(rawResult[0].totalRow);
				let lastPage = Math.ceil(parseInt(rawResult[0].totalRow) / limit);
				responseObj.meta.pageCount = lastPage;
				responseObj.meta.total = rawResult[0].totalRow;
				if(page == 1){
					responseObj.meta.prevPage = false;
					responseObj.meta.nextPage = page + 1;
				} else if(page == lastPage){
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = false;
				} else if (page != 1 && page < lastPage) {
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = page + 1;
				}
				console.log(responseObj.meta);
				return res.json(responseObj);
			}).catch(function (err) { return res.serverError(err); });
		}).catch(function (err) { return res.serverError(err); });
	},
	'artistDetails': (req, res, next) => {
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : 'guest';
		let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
		let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 50));
		let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
		let searchParams = Object.assign({query: { sort: 'createdAt DESC' }, pagelimit: { page: page, limit: limit }}, search);
		let artistName = params.name;
		let lookFor = [' & ',' X ',' < ',' , ',', ',' feat ',' Feat. ',' ft ',' ft. ',' Ft. ',' Vs ',' vs '];
		let mtchChar = [];
		let artistsArr = [];
		lookFor.forEach(function(element, index){
		  if(artistName.indexOf(element) != '-1'){
			mtchChar.push(element);
		  }
		});
		if(mtchChar.length != 0){
		  if(mtchChar.length == 1){
			searchParams.query.or = [];
			let arr = artistName.split(mtchChar);
			arr.forEach(function(a,index){
			  let aFilter = {artist:{contains: a}};
			  searchParams.query.or.push(aFilter);
			});
		  } else {
			let i = 0;
			mtchChar.forEach(function(chr,index){
			  if(artistName != undefined){
				let arr = artistName.split(chr);
				artistsArr.push(arr[0]);
				artistName = arr[1];
			  }
			});
			artistsArr.forEach(function(a,index){
			  let aFilter = {artist:{contains: a}};
			  searchParams.query.or.push(aFilter);
			});
		  }
		} else {
		  searchParams.query.or = [{
			artist: {
			  contains: artistName
			}
		  }];
		//  searchParams.query.or.push({artist:{contains: artistName}});
		}
		let getPagination = () => {
		  return new Promise((resolve, reject) => {
			//Using Promises 
			pager.paginate(UserTrack, searchParams.query, searchParams.pagelimit.page, limit, [], searchParams.query.sort ).then(function(records){
			  records.tracks = records.data;
			  if(mtchChar.length > 1){
				records.searchFor = artistsArr.join(" & ");
			  } else {
				records.searchFor = artistName;
			  }
			  resolve(records);
			}).catch(function(err) {
				reject(err);
			});
		  })
		}

		getPagination().then(responce => {
		  if(req.param('json') || req.isSocket) {
			return res.json(Object.assign(responce, {ui: params.ui}))
		  }
		  else {
			return res.json(Object.assign(responce, {ui: params.ui}))
		  }
		})
	},
	getRemixes: function(req, res) {
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : 'guest';
		let userName = req.session.user ? req.session.user.login : '';
		let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
		let where = " type = 'remix'";
		let orderBy = 'createdAt';
		let sel = '*';
		let sqlArray = [];
		if(search.query.hasOwnProperty('searchValue')){
			if(search.query.searchValue.indexOf("'") > -1){
				var arr = search.query.searchValue.split("'");
				search.query.searchValue = arr.join("\\'");
			}
			where += " MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE)";
			sel = "*, MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE) AS relevance";
			orderBy = 'relevance';
		}
		let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 20));
		let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
		
		let responseObj = {};
		responseObj['message'] = 'Data retrieved successfully';
		responseObj['tracks'] = [];
		responseObj['data'] = [];
		responseObj['meta'] = {'pageCount': 0, 'nextPage' : true, 'prevPage': true, 'total': 0, 'page': page, 'perPage': limit};
		var generalQueryAsync = Promise.promisify(Track.query);
		generalQueryAsync('SELECT '+sel+' FROM remix_odest_track WHERE'+where+' ORDER BY '+orderBy+' DESC LIMIT '+ ((page  - 1) * limit) +', '+limit+'')
		.then(function(rawResult) {
			if (!rawResult) { return res.notFound(); }
			responseObj.tracks = rawResult;
			responseObj.data = rawResult;
			var totalQuery = Promise.promisify(Track.query);
			totalQuery('SELECT COUNT(*) AS totalRow FROM remix_odest_track WHERE'+where)
			.then(function(rawResult) {
				if (!rawResult) { return res.notFound(); }
				console.log('total');
				console.log(rawResult[0].totalRow);
				let lastPage = Math.ceil(parseInt(rawResult[0].totalRow) / limit);
				responseObj.meta.pageCount = lastPage;
				responseObj.meta.total = rawResult[0].totalRow;
				if(page == 1){
					responseObj.meta.prevPage = false;
					responseObj.meta.nextPage = page + 1;
				} else if(page == lastPage){
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = false;
				} else if (page != 1 && page < lastPage) {
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = page + 1;
				}
				console.log(responseObj.meta);
				return res.json(responseObj);
			}).catch(function (err) { return res.serverError(err); });
		}).catch(function (err) { return res.serverError(err); });
	},
	'songDetails': (req, res, next) => {
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : 'guest';
		let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
		let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 50));
		let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
		let searchParams = Object.assign({query: { sort: 'title DESC' }, pagelimit: { page: page, limit: limit }}, search);

		UserTrack.find({ slug: params.name }).limit(1)
		.then(function (record){
		  if (!record) { 
			return res.notFound(); 
		  }
		  let title = record[0].title;
		  let type = record[0].type;
		  let len = title.indexOf("(");
		  if(len != -1){
			var trimmedString = title.substring(0, len);
			title = trimmedString.trim();
		  }
		  searchParams.query.or = [{
			slug: params.name
		  }];
		  let getPagination = () => {
			return new Promise((resolve, reject) => {
			  //Using Promises 
			  pager.paginate(UserTrack, searchParams.query, searchParams.pagelimit.page, limit, [], searchParams.query.sort ).then(function(records){
				records.tracks = records.data;
				records.searchFor = record[0];
				resolve(records);
			  }).catch(function(err) {
				  reject(err);
			  });
			})
		  }
	  
		  getPagination().then(responce => {
			if(req.param('json') || req.isSocket) {
			  return res.json(Object.assign(responce, {ui: params.ui}))
			}
			else {
			  return res.json(Object.assign(responce, {ui: params.ui}))
			}
		  })
		})
		.catch(function (err) { 
		  return res.serverError(err); 
		});
	},
	getOdest: function(req, res) {
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : 'guest';
		let userName = req.session.user ? req.session.user.login : '';
		let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
		let where = " type = 'artist'";
		let orderBy = 'createdAt';
		let sel = '*';
		let sqlArray = [];
		if(search.query.hasOwnProperty('searchValue')){
			if(search.query.searchValue.indexOf("'") > -1){
				var arr = search.query.searchValue.split("'");
				search.query.searchValue = arr.join("\\'");
			}
			where += " MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE)";
			sel = "*, MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE) AS relevance";
			orderBy = 'relevance';
		}
		let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 20));
		let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
		
		let responseObj = {};
		responseObj['message'] = 'Data retrieved successfully';
		responseObj['tracks'] = [];
		responseObj['data'] = [];
		responseObj['meta'] = {'pageCount': 0, 'nextPage' : true, 'prevPage': true, 'total': 0, 'page': page, 'perPage': limit};
		var generalQueryAsync = Promise.promisify(Track.query);
		generalQueryAsync('SELECT '+sel+' FROM remix_odest_track WHERE'+where+' ORDER BY '+orderBy+' DESC LIMIT '+ ((page  - 1) * limit) +', '+limit+'')
		.then(function(rawResult) {
			if (!rawResult) { return res.notFound(); }
			responseObj.tracks = rawResult;
			responseObj.data = rawResult;
			var totalQuery = Promise.promisify(Track.query);
			totalQuery('SELECT COUNT(*) AS totalRow FROM remix_odest_track WHERE'+where)
			.then(function(rawResult) {
				if (!rawResult) { return res.notFound(); }
				console.log('total');
				console.log(rawResult[0].totalRow);
				let lastPage = Math.ceil(parseInt(rawResult[0].totalRow) / limit);
				responseObj.meta.pageCount = lastPage;
				responseObj.meta.total = rawResult[0].totalRow;
				if(page == 1){
					responseObj.meta.prevPage = false;
					responseObj.meta.nextPage = page + 1;
				} else if(page == lastPage){
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = false;
				} else if (page != 1 && page < lastPage) {
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = page + 1;
				}
				return res.json(responseObj);
			}).catch(function (err) { return res.serverError(err); });
		}).catch(function (err) { return res.serverError(err); });
	},
	
	updateStream: function(req, res) {
		let params = req.params.all();
		if(!params.id) {
		  if(req.isSocket || params.json) {
			return res.json(data);
		  }
		  else {
			return res.badRequest(`This id (${params.id}) doesn\'t found`)
		  }
		}
		UserTrack.findOne( {id: params.id}, (err, track) => {
			console.log(err);
		  if(err) return next(err);
			if(!track) return res.json({'error': true,'message':'track doesn\'t exist.'});
				UserTrack.update({id: params.id}).set({played: (track.played + 1)});
			if(req.isSocket) {
				return res.json({'error': false,'message':'stream updated.'});
			}
		})
	},
	updateLikes: function(req, res) {
		let params = req.params.all();
		if(!params.id) {
		  if(req.isSocket || params.json) {
			return res.json(data);
		  }
		  else {
			return res.badRequest(`This id (${params.id}) doesn\'t found`)
		  }
		}
		let userId = req.session.user.id;
		console.log('Try like track', req.param('id'))
		if(req.session.user.isLocked) {
			return res.serverError(req.session.user.isLocked.msg);
		}
		UserTrack.findOne({id: params.id}, (err, track) => {
			if(err || !track) {
				return res.serverError({ msg: 'Track not found!' });
			}
			let newDisLiked = track.disliked;
			let newLiked = track.liked;
			let lyks = track.likes;
			let dislyks = track.dislikes;
			
			console.log('Track likes: ', lyks[userId] || 0);
			//sails.log('Track likes: ', track.likes[userId] || [])
			if(lyks[userId] && lyks[userId] > 0) {
				sails.sockets.blast('error.' + userId, { error: 'already liked' });
				console.log('Already Liked');
				return res.json({'error': true,'message': 'Already Liked'});
			}
			if(lyks[userId] === undefined || lyks[userId] == 0){
				lyks[userId] = (lyks[userId] || 0) + 1;
				newLiked = parseInt(newLiked) + 1;
			}
			if(dislyks[userId] === undefined){
				dislyks[userId] = 0;
				newDisLiked = parseInt(newDisLiked) - 1;
			} else {
				dislyks[userId] = (dislyks[userId] || 0) - 1;
				newDisLiked = parseInt(newDisLiked) - 1;
			}
			
			let updatedAt = moment().format("YYYY-MM-DD HH:mm:ss");
			UserTrack.update(track.id, { disliked: newDisLiked, liked: newLiked, likes: lyks, dislikes: dislyks, updatedAt: updatedAt }).exec((err, tr) => {
				if(err) return res.serverError(err);
				console.log('Like Added' + userId, { track: tr });
				sails.sockets.blast('liked.' + userId, { track: tr });
				return res.json({'error': false,'likeCount':newLiked,'dislikeCount': newDisLiked});
			})
		})
	},
	updateDislikes: function(req, res) {
		let params = req.params.all();
		if(!params.id) {
		  if(req.isSocket || params.json) {
			return res.json(data);
		  }
		  else {
			return res.badRequest(`This id (${params.id}) doesn\'t found`)
		  }
		}
		let userId = req.session.user.id;
		console.log('Try dislike track', req.param('id'))
		if(req.session.user.isLocked) {
			return res.serverError(req.session.user.isLocked.msg);
		}
		UserTrack.findOne({id: params.id}, (err, track) => {
			if(err || !track) {
				return res.serverError({ msg: 'Track not found!' });
			}
			let newDisLiked = track.disliked;
			let newLiked = track.liked;
			let lyks = track.likes;
			let dislyks = track.dislikes;
			console.log('Track dislikes: ', dislyks[userId] || []);
			//sails.log('Track dislikes: ', track.likes[userId] || [])
			if(dislyks[userId] && dislyks[userId] > 0) {
				sails.sockets.blast('error.' + userId, { error: 'already liked' });
				console.log('Already Dis Liked');
				return res.json({'error': true,'message': 'Already Dis Liked'});
			}
			if(lyks[userId] === undefined || lyks[userId] != 0){
				lyks[userId] = 0;
				newLiked = parseInt(newLiked) - 1;
			}
			if(dislyks[userId] === undefined || dislyks[userId] == 0){
				dislyks[userId] = 1;
				newDisLiked = parseInt(newDisLiked) + 1;
			} else {
				dislyks[userId] = (dislyks[userId] || 0) + 1;
				newDisLiked = parseInt(newDisLiked) + 1;
			}
			let updatedAt = moment().format("YYYY-MM-DD HH:mm:ss");
			UserTrack.update(track.id, { liked: newLiked, likes: lyks, disliked: newDisLiked, dislikes: dislyks, updatedAt: updatedAt }).exec((err, tr) => {
				if(err) return res.serverError(err);
				console.log('DisLike Added' + userId, { track: tr });
				sails.sockets.blast('disliked.' + userId, { track: tr });
				return res.json({'error': false,'likeCount':newLiked,'dislikeCount':newDisLiked});
			})
		})
	},
	downloadTrack: function(req, res) {
		console.log('Get gile', req.params.all());
                console.log(req.param('id'))
		if(!req.param('id')) {
		  return res.serverError('This id: ' + req.param('id') + ' is not defined')
		}
		download(req, res);
	}
};
