/**
 * Track.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */
let moment = require('moment');

module.exports = {
	tableName: 'remix_odest_track',
	attributes: {
		uploadedBy: {
		  type: 'string'
		},
		type: {
		  type: 'string',
		  enum: ['remix', 'artist'],
		  defaultsTo: 'artist'
		},
		comment: {
		  type: 'string',
		  enum: ['Clean', 'Dirty'],
		  defaultsTo: 'Clean'
		},
		name: {
		  type: 'string'
		},
		artist: {
		  type: 'string'
		},
		title: {
		  type: 'string'
		},
		remixer: {
		  type: 'string'
		},
		genre: {
		  type: 'string'
		},
		subgenre: {
		  type: 'string'
		},
		bpm: {
		  type: 'integer'
		},
		key: {
		  type: 'string'
		},
		year: {
		  type: 'integer'
		},
		action: {
		  type: 'integer',
		  defaultsTo: 0
		},
		url: {
		  type: 'string'
		},
		search: {
		  type: 'string'
		},
		rsearch: {
		  type: 'string'
		},
		slug: {
		  type: 'string'
		},
		played: {
			type: 'integer',
			defaultsTo: 0
		},
		downloaded: {
			type: 'integer',
			defaultsTo: 0
		},
		liked: {
			type: 'integer',
			defaultsTo: 0
		},
		disliked: {
			type: 'integer',
			defaultsTo: 0
		},
		createdAt: {
		  type: 'datetime',
		  defaultsTo: function() {
			return moment().format("YYYY-MM-DD HH:mm:ss")
			// return new Date();
		  }
		},
		updatedAt: {
		  type: 'datetime',
		  defaultsTo: function() {
			return moment().format("YYYY-MM-DD HH:mm:ss")
			// return new Date();
		  }
		},
		uploads: {
		  type: 'json',
		  defaultsTo: {}
		},
		likes: {
		  type: 'json',
		  defaultsTo: {}
		},
		dislikes: {
		  type: 'json',
		  defaultsTo: {}
		},
		size: {
		  type: 'integer',
		  defaultsTo: 0
		},
		toJSON: function() {
			var obj = this.toObject();
			delete obj.token;
			delete obj._csrf;
			return obj;
		}
	},
	beforeCreate: function(values, next) {
		delete values.json;
		delete values.saving;
		delete values.uploading;
		next();
	},
	beforeUpdate: function(values, next) {
		delete values.json;
		delete values.saving;
		delete values.uploading;
		next();
	}
};

