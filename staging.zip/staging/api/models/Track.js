/**
 * Track.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */
let moment = require('moment');

module.exports = {
  attributes: {
    uploadedBy: {
      type: 'string'
    },
    type: {
      type: 'string'
    },
    popularity: {
      type: 'integer',
      defaultsTo: 0
    },
    day: {
      type: 'integer',
      defaultsTo: 0
    },
    week: {
      type: 'integer',
      defaultsTo: 0
    },
    month: {
      type: 'integer',
      defaultsTo: 0
    },
    comment: {
      type: 'string',
      enum: ['Clean', 'Dirty'],
      defaultsTo: 'Clean'
    },
    name: {
      type: 'string'
    },
    artist: {
      type: 'string'
    },
    title: {
      type: 'string'
    },
    remix: {
      collection: 'Track'
    },
    remixer: {
      type: 'string'
    },
    genre: {
      type: 'string'
    },
    subgenre: {
      type: 'string'
    },
    bpm: {
      type: 'integer'
    },
    key: {
      type: 'string'
    },
    year: {
      type: 'integer'
    },
    action: {
      type: 'integer',
      defaultsTo: 0
    },
    url: {
      type: 'string'
    },
    search: {
      type: 'string'
    },
    rsearch: {
      type: 'string'
    },
    slug: {
      type: 'string'
    },
    createdAt: {
      type: 'datetime',
      defaultsTo: function() {
        return moment().format("YYYY-MM-DD HH:mm:ss")
        // return new Date();
      }
    },
    updatedAt: {
      type: 'datetime',
      defaultsTo: function() {
        return moment().format("YYYY-MM-DD HH:mm:ss")
        // return new Date();
      }
    },
    isRadio: {
      type: 'integer',
      defaultsTo: 0
    },
    uploads: {
      type: 'json',
      defaultsTo: {}
    },
    size: {
      type: 'integer',
      defaultsTo: 0
    },
    toJSON: function() {
        var obj = this.toObject();
        delete obj.token;
        delete obj._csrf;
        return obj;
    }
  },
  beforeCreate: function(values, next) {
    delete values.json;
    delete values.saving;
    delete values.uploading;
    next();
  },
  beforeUpdate: function(values, next) {
    delete values.json;
    delete values.saving;
    delete values.uploading;
    next();
  }
};

