import _ from 'lodash/core';
import {BASE_URL} from '../config';
import Vue from 'vue';
import moment from 'moment';
import './components/dropbox-saver';

import 'bootstrap-vue/dist/bootstrap-vue.css'
import BootstrapVue from 'bootstrap-vue';
import './components/player';
import WaveSurfer from 'wavesurfer.js';

import * as CoreService from './services/core-service';
import * as TrackService from './services/track-service';

Vue.config.errorHandler = function (err, vm, info) {
	console.log(err)
	console.log(vm)
	console.log(info)
}
Vue.use(BootstrapVue);


let app = new Vue({
	el: '#cart',
	data: {
    gettingArchive: false,
    loadingCart: true,
    saving: false,
    stopPlayer: false,
    cartTracks: [],
		moment,
		playing: false,
		artist: '',
		song: ''
	},
  beforeCreate() {
    this.loadingCart = true;
  },
	mounted () {
		this.$nextTick(() => {
			this.wavesurfer = new WaveSurfer.create({
				container: '#waveform',
				waveColor: '#ffffff',
				progressColor: '#333333',
				height: 70,
				backend: 'MediaElement'
			})
		})
		CoreService.getCart().then(data => {
      this.cartTracks = data.cart;
      this.loadingCart = false;
    }, reason => {
      this.loadingCart = false;
    })
    CoreService.getUserInfo().then(data => {
      this.user = data;
      if(io.socket && this.user && this.user.id) {
        io.socket.on('cart-update.' + this.user.id, function(data) {
          if(data.cart) this.cartTracks = data.cart;
          this.gettingArchive = false;
        }.bind(this))
      }
    })
    this.$on('onsaving', function() {
      this.saving = true;
    })
    this.$on('onsuccess', function() {
      this.markedAllAsDownloaded();
    })
	},
  methods: {
		play () {
			this.wavesurfer.playPause()
			if(this.wavesurfer.isPlaying()){
				this.playing = true;	
			} else {
				this.playing = false;
			}
		},
		playSong(track) {
			this.wavesurfer.on('ready', this.wavesurfer.play.bind(this.wavesurfer));
			if(this.wavesurfer.load(track.url)){
				this.wavesurfer.play()
			}
			this.playing = true;
			this.artist = track.artist;
			this.song = track.title;
			this.updateStream(track);
			this.stopAudioPlayer();
		},
		updateStream(track) {
			CoreService.updateStreamCount({trackId: track.id}).then(data => {
				console.log('Added Successfuly');
			}).catch();
		},
		stopAudioPlayer() {
			if(this.stopPlayer){
				clearTimeout(this.stopPlayer);
			}
			this.stopPlayer = setTimeout(function () {
			  this.wavesurfer.stop();
			  this.playing = false;
			}, 60000);
		},
    removeTrack(track) {
      CoreService.removeFromCart({trackId: track.id}).then(data => {
        this.cartTracks = data.cart;
      });
		},
		getDownloadCount(count) {
			let html = '';
			if(count == "1"){
				html += '<div class="count-1">&nbsp;</div>';
			} else if (count == "2") {
				html += '<div class="count-1">&nbsp;</div>';
				html += '<div class="count-2">&nbsp;</div>';
			} else if (count == "3") {
				html += '<div class="count-1">&nbsp;</div>';
				html += '<div class="count-2">&nbsp;</div>';
				html += '<div class="count-3">&nbsp;</div>';
			}
			return html;
		},
		getVersion(v) {
			if( v == "Clean" || v == "clean") {
				return "C";
			} else if( v == "Dirty" || v == "dirty") {
				return "D";
			}
		},
    getArtistTemplate (artistName) {
			let findChars = [' & ',' X ',' < ',' , ',', ',' feat ',' Feat. ',' ft ',' ft. ',' Ft. ',' Vs ',' vs '];
			let findPos = [];
			let html = "";
			let mtchChar = [];
			findChars.forEach(function(element, index){
				if(artistName.indexOf(element) != '-1'){
					mtchChar.push(element);
				}
			});
			if(mtchChar.length == 0){
				html = '<a href="/artist/'+artistName+'">'+artistName+'</a>';
				return html;
			} else if (mtchChar.length == 1){
				let string = artistName.split(mtchChar[0]);
				html = '<a href="/artist/'+string[0]+'">'+string[0]+'</a>'+mtchChar[0];
				html += '<a href="/artist/'+string[1]+'">'+string[1]+'</a>';
				return html;
			}
			for(var i = 0; i < findChars.length; i++){
				if(artistName.indexOf(findChars[i]) != -1){
					var searchStrLen = findChars[i].length;
					if (searchStrLen != 0) {
						var startIndex = 0, index;
						while ((index = artistName.indexOf(findChars[i], startIndex)) > -1) {
							var a = [];
							a['pos'] = index;
							a['chr'] = findChars[i]
							findPos.push(a);
							startIndex = index + searchStrLen;
						}
					}
				}
			}
			var sorted = findPos.sort(function(a, b){
							var keyA = a.pos,
							keyB = b.pos;
							if(keyA < keyB) return -1;
							if(keyA > keyB) return 1;
							return 0;
						});
			for(var j = 0; j < sorted.length; j++){
				if(j == 0){
					html += '<a href="/artist/'+artistName.substring(0, sorted[j]['pos'])+'">'+artistName.substring(0, sorted[j]['pos'])+'</a>';
					html += sorted[j]['chr'];
				} else {
					html += '<a href="/artist/'+artistName.substring((sorted[(j - 1)]['pos'] + sorted[(j - 1)]['chr'].length), sorted[j]['pos'])+'">'+artistName.substring((sorted[(j - 1)]['pos'] + sorted[(j - 1)]['chr'].length), sorted[j]['pos'])+'</a>';
					html += sorted[j]['chr'];
					if(j == (sorted.length - 1)){
						html += '<a href="/artist/'+artistName.substring((sorted[j]['pos'] + sorted[j]['chr'].length), artistName.length)+'">'+artistName.substring((sorted[j]['pos'] + sorted[j]['chr'].length), artistName.length)+'</a>';
					}
				}
			}
			return html;

		},
    getZip() {
      CoreService.getZip().then(data => {
        console.log(data)
      });
    },
    markedAllAsDownloaded() {
      console.log('marking');
      TrackService.markedAllAsDownloaded().then(data => {
        console.log('marked');
        console.log(data)
      })
      this.saving = false;
    }
  }
})
