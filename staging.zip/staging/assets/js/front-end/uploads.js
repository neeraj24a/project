import _ from 'lodash/core';
import clone from 'lodash/clone';
import {BASE_URL} from '../config';
import {polyfill} from 'es6-promise';
import Vue from 'vue';
import moment from 'moment';
import './components/player';
import './components/locked';
import './components/uploads-edit';
import './components/uploads-delete';
import WaveSurfer from 'wavesurfer.js';
import 'bootstrap-vue/dist/bootstrap-vue.css'

import BootstrapVue from 'bootstrap-vue';

import * as CoreService from './services/core-service';
import * as UploadsService from './services/uploads-service';
import { getGenreFilters } from './services/filter-service';
import { getRemixerFilters } from './services/remixer-filter-service';

Vue.config.errorHandler = function (err, vm, info) {
	console.log(err);
	console.log(vm);
	console.log(info);
}
Vue.use(BootstrapVue);

/* Home application */
let app = new Vue({
	el: '#uploads-app',
	data: {
		tracks: {
			id: null,
			artist: null,
			title: null,
			bpm: null,
			genre: null,
			subgenre: null,
			comment: null,
			key: null,
			year: null
		},
		activeSort: {
			type: 'createdAt',
			reverse: false
		},
		activeFilter: {
			trackType: 'audio',
			genre: null,
			subgenre: null,
			remixer: null,
			date: {
				name: null,
				createdAt: null,
				updatedAt: null
			},
			page: 1
		},
		noTracks: false,
		searchValue: '',
		loadingTrack: true,
		loadingMessage: 'Application loading',
		viewTracks: [],
		trackSchema: {},
		filters: [],
		remixers: [],
		noMore: null,
		user: null,
		pagination: null,
		locked: false,
		moment,
		window,
		playing: false,
		updateModal: null,
		deleteModal: null,
		saved: false
	},
	beforeCreate() {
		UploadsService.trackSchema().then(schema => {
			this.trackSchema = schema.model;
			return schema.model;
		});
	},
	mounted () {
		/*this.$nextTick(() => {
			this.wavesurfer = new WaveSurfer.create({
				container: '#waveform',
				waveColor: '#ffffff',
				progressColor: '#333333',
				height: 70,
				backend: 'MediaElement'
			})
		});*/
		
		this.loadingTracks();
	},
	methods: {
		/*play () {
			this.wavesurfer.playPause()
			if(this.wavesurfer.isPlaying()){
				this.playing = true;	
			} else {
				this.playing = false;
			}
		},
		playSong(track) {
			this.wavesurfer.on('ready', this.wavesurfer.play.bind(this.wavesurfer));
			if(this.wavesurfer.load(track.url)){
				this.wavesurfer.play()
			}
			this.playing = true;
			this.artist = track.artist;
			this.song = track.title;
			this.updateStream(track)
		},*/
		loadingTracks () {
			this.resetViewTrack();
			return this.getFilterTrack().then(data => {
				return data;
			});
		},
		onSearch(result) {
			delete this.activeFilter.artist;
			delete this.activeFilter.title;
			if(result.hasOwnProperty('artist')) this.activeFilter.artist = result.artist;
			if(result.hasOwnProperty('title')) this.activeFilter.title = result.title;
			
			if(typeof result === 'object') {
				this.searchValue = (result.artist || '...') + ' - ' + (result.title || '...');
			}
			else {
				this.searchValue = result;
			}
			this.resetViewTrack();
			return this.getFilterType()
		},
		resetAllFilter() {
			this.searchValue = '';
			delete this.activeFilter.artist;
			delete this.activeFilter.title;
			delete this.activeFilter.isClean;
			delete this.activeFilter.popularity;
			delete this.activeFilter.remixer;
			
			this.activeFilter = Object.assign(this.activeFilter, {
				genre: null,
				subgenre: null,
				date: {
					name: null,
					createdAt: null,
					updatedAt: null
				},
				page: 1
			})
			this.resetFilter();
			return this.getFilterTrack()
		},
		sortBy(e, sort) {
			let filter = e;
			if(filter == "title" && this.activeSort.reverse == sort){
				this.activeSort.reverse = sort;
			} else if(filter == "title" && this.activeSort.reverse != sort){
				this.activeSort.reverse = !sort;
			} else if (filter == "artist" && this.activeSort.reverse == sort) {
				this.activeSort.reverse = sort;
			} else if(filter == "artist" && this.activeSort.reverse != sort){
				this.activeSort.reverse = !sort;
			} else if (filter == "createdAt" && this.activeSort.reverse == sort) {
				this.activeSort.reverse = sort;
			} else if(filter == "createdAt" && this.activeSort.reverse != sort){
				this.activeSort.reverse = !sort;
			} else {
				this.activeSort.reverse = false;
			}
			
			this.activeSort.type = filter;

			this.resetViewTrack();
			return this.getFilterType();
		},
		sortByDate(e) {
			if(e.target.value == "" || e.target.value == "a"){
				this.activeSort.reverse = false;
			} else if(e.target.value == 'z'){
				this.activeSort.reverse = true;
			}
			this.activeSort.type = 'createdAt';

			this.resetViewTrack();
			return this.getFilterType()
		},
		prevPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				this.activeFilter.page--;
				this.getFilterTrack().then(() => {
					resolve();
				}, reason => {
					// this.activeFilter.page--;
					// this.noMore = reason;
				});
			})
		},
		nextPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				this.activeFilter.page++;
				this.getFilterTrack().then(() => {
					resolve();
				}, reason => {
					// this.activeFilter.page--;
					// this.noMore = reason;
				});
			})
		},
		savePrevious() {
			this.previousState = clone(this.pagination);
		},
		goToPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				let parsed = parseInt(this.pagination.page);
				if(!isNaN(parsed)) {
					this.activeFilter.page = Math.max(1, Math.min(this.previousState.pageCount, parsed));
					this.getFilterTrack().then(() => {
						resolve();
					}, reason => {
						// this.noMore = reason;
					});
				}
				else {
					this.pagination.page = this.previousState.page;
					reject('Not a number');
				}
			})
		},
		resetViewTrack() {
			this.noTracks = false;
			this.activeFilter.page = 1;
			this.viewTracks = [];
		},
		resetFilter() {
			this.trendingActive = false;
			this.trendingType = 'daily';
			this.searchValue = "";
			this.activeFilter =	{
									trackType: 'audio',
									genre: null,
									subgenre: null,
									remixer: null,
									date: {
										name: null,
										createdAt: null,
										updatedAt: null
									},
									page: 1
								};
			this.resetViewTrack();
			this.activeSort.type = 'createdAt';
			this.activeSort.reverse = false;
			return this.getFilterTrack();
		},
		getFilterTrack({params, concat} = {}) {
			this.noMore = false;
			let filterParams = Object.assign({}, params || {});
			// filter by search words if exist
			if(this.searchValue && this.searchValue.trim().length) {
				filterParams.searchValue = this.searchValue;
			}
			// sort settings
			if(this.popularityCheck === false) {
				filterParams.sort = 'createdAt ' + (this.activeSort.reverse ? 'ASC' : 'DESC');
				if(this.activeSort.type) {
					filterParams.sort = this.activeSort.type + ' ' + (this.activeSort.reverse ? 'ASC' : 'DESC');
				}
			} else {
				filterParams.sort = this.activeSort.type + ' DESC';	
			}
			this.loadingTrack = true;
			return new Promise((resolve, reject) => {
				UploadsService.getTracks({ search: {
					query: filterParams,
					pagelimit: {
						page: this.activeFilter.page
					}
				}
			}).then(data => {
					this.pagination = data.meta;
					this.viewTracks = concat ? this.viewTracks.concat(data.tracks) : data.tracks;
					this.loadingTrack = false;
					
					if (data.tracks.length) {
						resolve(data);
						this.noTracks = false;
					}
					else {
						this.noTracks = true;
						console.log('No more tracks')
						reject({ message: 'No more tracks'});
					}
				}, reason => {
					reject({ message: reason });
				})
			})
		},
		confirmRemove(track) {
			this.removedTrack = track;
			this.$root.$emit('show::modal', 'confirm');
		},
		showUpdateModal(track) {
			console.log(this.tracks);
			Object.assign(this.tracks, track);
			console.log(this.tracks);
			this.updateModal = track.id;
		},
		closeUpdateModal() {
			this.resetModalTrack();
			this.updateModal = null;
		},
		resetModalTrack(){
			this.tracks = {
				id: null,
				artist: null,
				title: null,
				bpm: null,
				genre: null,
				subgenre: null,
				comment: null,
				key: null,
				year: null
			};
		},
		showDeleteModal(id) {
			this.deleteModal = id;
		},
		editTrack(track) {
			
		},
		removeTrack(id) {
			/*if(!this.removedTrack) return;
			TrackService.removeTrack({ id: this.removedTrack.id }).then(() => {
				this.viewTracks.splice(this.viewTracks.indexOf(this.removedTrack), 1);
				delete this.removedTrack;
			}, reason => {
				console.log(reason)
			});*/
		},
		checkExpire() {
			let expDate = this.user.subscriptions[globalSettings.product_id];
			let isExist = new Date(`${expDate}`) > new Date().getTime();
			if(!isExist) {
				return true;
			}
			return false;
		},
		handleSubmit(event) {
			let self = this;
			if(this.saved){
				return;
			}
			setTimeout(function() {
				self.saved = false;
				self.resetModalTrack();
				self.updateModal = null;
				setTimeout(function(){
					return self.getFilterTrack();
				}, 2000)
			}, 2000);
			UploadsService.update(this.tracks).then(data => {
				console.log(data)
				this.saved = true;
			});
		}
	}
})
