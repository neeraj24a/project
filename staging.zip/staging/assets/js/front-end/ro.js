import _ from 'lodash/core';
import clone from 'lodash/clone';
import {BASE_URL} from '../config';
import {polyfill} from 'es6-promise';
import Vue from 'vue';
import moment from 'moment';
import './components/autocomplete';
import './components/locked';
import './components/modal';
import WaveSurfer from 'wavesurfer.js';


import 'bootstrap-vue/dist/bootstrap-vue.css'

import BootstrapVue from 'bootstrap-vue';

import * as CoreService from './services/core-service';
import * as UploadsService from './services/uploads-service';
import { getGenreFilters } from './services/filter-service';
import { filterComponent } from './components/filters.js';

Vue.config.errorHandler = function (err, vm, info) {
	console.log(err);
	console.log(vm);
	console.log(info);
}
Vue.use(BootstrapVue);

/* Home application */
let app = new Vue({
	el: '#app',
	data: {
		//wavesurfer: new WaveSurfer(),
		activeSort: {
			type: 'createdAt',
			reverse: false
		},
		activeFilter: {
			trackType: 'audio',
			genre: null,
			subgenre: null,
			remixer: null,
			date: {
				name: null,
				createdAt: null,
				updatedAt: null
			},
			page: 1
		},
		noTracks: false,
		popularityCheck: false,
		searchValue: '',
		loadingTrack: true,
		loadingMessage: 'Application loading',
		viewTracks: [],
		trackSchema: {},
		filters: [],
		remixers: [],
		filterCollection: {},
		alertType: null,
		noMore: null,
		downloadTrack: null,
		user: null,
		searchStart: null,
		pagination: null,
		cartQueue: [],
		locked: false,
		moment,
		window,
		playing: false,
		artist: '',
		song: '',
		cartCount: 0,
		showModal: false
	},
	beforeCreate() {
		UploadsService.trackSchema().then(schema => {
			this.trackSchema = schema.model;
			return schema.model;
		}).then(model => {
			return getGenreFilters();
		}).then(filters => {
			this.filters = filters;
		});
	},
	mounted () {
		this.$nextTick(() => {
			this.wavesurfer = new WaveSurfer.create({
				container: '#waveform',
				waveColor: '#ffffff',
				progressColor: '#333333',
				height: 70,
				backend: 'MediaElement'
			})
		});
		
		this.loadingTracks();
		CoreService.getUserInfo().then(data => {
			this.user = data;
			if(this.user && this.user.id && this.user.isLocked && !this.user.admin) {
				this.locked = this.user.isLocked;
			}
			if(this.user.error) {
				this.locked = {msg: this.user.error};
			}

			if(io.socket && this.user && this.user.id) {
				io.socket.on('downloaded.'+ this.user.id, function updateTrack({ track }) {
					track = track[0];
					if(this.user.admin) return;
					this.viewTracks.forEach(item => {
						if(track.id === item.id) {
							item.uploads[this.user.id] = track.uploads[this.user.id];
							this.$set(item, `uploads[${this.user.id}]`, track.uploads[this.user.id])
						}
						item.remix.forEach(remix => {
							if(track.id === remix.id) {
								remix.uploads[this.user.id] = track.uploads[this.user.id];
								this.$set(remix, `uploads[${this.user.id}]`, track.uploads[this.user.id])
							}
						})
					}, this);
				}.bind(this))
			}
		}, reason => {
			return reason;
		})
	},
	methods: {
		play () {
			this.wavesurfer.playPause()
			if(this.wavesurfer.isPlaying()){
				this.playing = true;	
			} else {
				this.playing = false;
			}
		},
		playSong(track) {
			this.wavesurfer.on('ready', this.wavesurfer.play.bind(this.wavesurfer));
			if(this.wavesurfer.load(track.url)){
				this.wavesurfer.play()
			}
			this.playing = true;
			this.artist = track.artist;
			this.song = track.title;
		},
		loadingTracks () {
			this.resetViewTrack();
			return this.getFilterTrack().then(data => {
				return data;
			});
		},
		getDownloadCount(count) {
			let html = '';
			if(count == "1"){
				html += '<div class="count-1">&nbsp;</div>';
			} else if (count == "2") {
				html += '<div class="count-1">&nbsp;</div>';
				html += '<div class="count-2">&nbsp;</div>';
			} else if (count == "3") {
				html += '<div class="count-1">&nbsp;</div>';
				html += '<div class="count-2">&nbsp;</div>';
				html += '<div class="count-3">&nbsp;</div>';
			}
			return html;
		},
		getArtistTemplate (artistName, type) {
			if(type == 'remix'){
				return artistName;
			}
			let findChars = [' & ',' X ',' < ',' , ',', ',' feat ',' Feat. ',' ft ',' ft. ',' Ft. ',' Vs ',' vs '];
			let findPos = [];
			let html = "";
			let mtchChar = [];
			findChars.forEach(function(element, index){
				if(artistName.indexOf(element) != '-1'){
					mtchChar.push(element);
				}
			});
			if(mtchChar.length == 0){
				html = '<a href="/unsigned-artist/'+artistName+'">'+artistName+'</a>';
				return html;
			} else if (mtchChar.length == 1){
				let string = artistName.split(mtchChar[0]);
				html = '<a href="/unsigned-artist/'+string[0]+'">'+string[0]+'</a>'+mtchChar[0];
				html += '<a href="/unsigned-artist/'+string[1]+'">'+string[1]+'</a>';
				return html;
			}
			for(var i = 0; i < findChars.length; i++){
				if(artistName.indexOf(findChars[i]) != -1){
					var searchStrLen = findChars[i].length;
					if (searchStrLen != 0) {
						var startIndex = 0, index;
						while ((index = artistName.indexOf(findChars[i], startIndex)) > -1) {
							var a = [];
							a['pos'] = index;
							a['chr'] = findChars[i]
							findPos.push(a);
							startIndex = index + searchStrLen;
						}
					}
				}
			}
			var sorted = findPos.sort(function(a, b){
							var keyA = a.pos,
							keyB = b.pos;
							if(keyA < keyB) return -1;
							if(keyA > keyB) return 1;
							return 0;
						});
			for(var j = 0; j < sorted.length; j++){
				if(j == 0){
					html += '<a href="/unsigned-artist/'+artistName.substring(0, sorted[j]['pos'])+'">'+artistName.substring(0, sorted[j]['pos'])+'</a>';
					html += sorted[j]['chr'];
				} else {
					html += '<a href="/unsigned-artist/'+artistName.substring((sorted[(j - 1)]['pos'] + sorted[(j - 1)]['chr'].length), sorted[j]['pos'])+'">'+artistName.substring((sorted[(j - 1)]['pos'] + sorted[(j - 1)]['chr'].length), sorted[j]['pos'])+'</a>';
					html += sorted[j]['chr'];
					if(j == (sorted.length - 1)){
						html += '<a href="/unsigned-artist/'+artistName.substring((sorted[j]['pos'] + sorted[j]['chr'].length), artistName.length)+'">'+artistName.substring((sorted[j]['pos'] + sorted[j]['chr'].length), artistName.length)+'</a>';
					}
				}
			}
			return html;

		},
		onSearch(result) {
			delete this.activeFilter.artist;
			delete this.activeFilter.title;
			if(result.hasOwnProperty('artist')) this.activeFilter.artist = result.artist;
			if(result.hasOwnProperty('title')) this.activeFilter.title = result.title;
			
			if(typeof result === 'object') {
				this.searchValue = (result.artist || '...') + ' - ' + (result.title || '...');
			}
			else {
				this.searchValue = result;
			}
			this.resetViewTrack();
			return this.getFilterType()
		},
		resetAllFilter() {
			this.searchValue = '';
			delete this.activeFilter.artist;
			delete this.activeFilter.title;
			delete this.activeFilter.isClean;
			delete this.activeFilter.popularity;
			delete this.activeFilter.remixer;
			
			this.activeFilter = Object.assign(this.activeFilter, {
				genre: null,
				subgenre: null,
				date: {
					name: null,
					createdAt: null,
					updatedAt: null
				},
				page: 1
			})
			this.resetFilter();
			return this.getFilterTrack()
		},
		sortBy(e, sort) {
			let filter = e;
			if(filter == "title" && this.activeSort.reverse == sort){
				this.activeSort.reverse = sort;
			} else if(filter == "title" && this.activeSort.reverse != sort){
				this.activeSort.reverse = !sort;
			} else if (filter == "artist" && this.activeSort.reverse == sort) {
				this.activeSort.reverse = sort;
			} else if(filter == "artist" && this.activeSort.reverse != sort){
				this.activeSort.reverse = !sort;
			} else if (filter == "createdAt" && this.activeSort.reverse == sort) {
				this.activeSort.reverse = sort;
			} else if(filter == "createdAt" && this.activeSort.reverse != sort){
				this.activeSort.reverse = !sort;
			} else {
				this.activeSort.reverse = false;
			}
			
			this.activeSort.type = filter;

			this.resetViewTrack();
			return this.getFilterType();
		},
		sortByDate(e) {
			if(e.target.value == "" || e.target.value == "a"){
				this.activeSort.reverse = false;
			} else if(e.target.value == 'z'){
				this.activeSort.reverse = true;
			}
			this.activeSort.type = 'createdAt';

			this.resetViewTrack();
			return this.getFilterType()
		},
		filterByClean(val) {
			let isClean = val;
			if(isClean == "all"){
				delete this.activeFilter.isClean;
			} else {
				if(isClean == this.activeFilter.isClean) 
					return;
				if(this.activeFilter.hasOwnProperty('isClean')) {
					if(isClean != this.activeFilter.isClean) {
						this.activeFilter.isClean = isClean;
					}
					else {
						delete this.activeFilter.isClean;
					}
				}
				else {
					this.activeFilter.isClean = isClean;
				}
			}

			this.resetViewTrack();
			return this.getFilterType()
		},
		filterByRemixer(remixer) {
			if(remixer.length > 0) {
				this.resetViewTrack();
				this.activeFilter.remixer = remixer;
				return this.getFilterType()
			} else {
				this.resetViewTrack();
				delete this.activeFilter.remixer;
				this.activeSort = {
					type: 'createdAt',
					reverse: false
				}
				return this.getFilterType();
			}
		},
		filterByTitle(title) {
			if(title == this.searchValue) return;
			if(title) {
				this.searchValue = title;
				this.activeSort = {
					type: 'title',
					reverse: false
				}
				this.resetViewTrack();
				return this.getFilterType();
			}
		},
		filterByFromBpm(e){
			if(!this.activeFilter.toBpm){
				this.activeFilter.toBpm = {'<': 500};
			}
			let filter = e.target.value;
			if(filter){
				this.activeFilter.fromBpm = {'>': filter};
			} else {
				delete this.activeFilter.fromBpm;
			}
			this.resetViewTrack();
			return this.getFilterType();
		},
		filterByToBpm(e){
			if(!this.activeFilter.fromBpm){
				this.activeFilter.fromBpm = {'<': 0};
			}
			let filter = e.target.value;
			if(filter){
				this.activeFilter.toBpm = {'<': filter};
			} else {
				delete this.activeFilter.toBpm;
			}
			this.resetViewTrack();
			return this.getFilterType();
		},
		resetBPM(){
			delete this.activeFilter.fromBpm;
			delete this.activeFilter.toBpm;
			this.resetViewTrack();
			return this.getFilterTrack();
		},
		filterByArtist(e) {
			let filter = e;
			if(filter == this.activeFilter.artist) return;
			if(filter) {
				if(this.activeFilter.artist && this.activeFilter.artist === filter) return;
				this.activeFilter.artist = filter;
			}
			else {
				delete this.activeFilter.artist;
			}
			this.resetViewTrack();
			return this.getFilterType()
		},
		filterByGenre(e) {
			let filter = e;
			if(filter == this.activeFilter.genre) return;
			if(filter) {
				if(this.activeFilter.genre && this.activeFilter.genre === filter) return;
				this.activeFilter.genre = filter;
			}
			else {
				delete this.activeFilter.genre;
			}
			this.resetViewTrack();
			return this.getFilterType()
		},
		filterBySubGenre(e) {
			let filter = e;
			if(filter == this.activeFilter.subgenre) return;
			if(filter) {
				if(this.activeFilter.subgenre && this.activeFilter.subgenre === filter) return;
				this.activeFilter.subgenre = filter;
			}
			else {
				delete this.activeFilter.subgenre;
			}
			this.resetViewTrack();
			return this.getFilterType();
		},
		
		prevPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				this.activeFilter.page--;
				this.getFilterTrack().then(() => {
					resolve();
				}, reason => {
					// this.activeFilter.page--;
					// this.noMore = reason;
				});
			})
		},
		nextPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				this.activeFilter.page++;
				this.getFilterTrack().then(() => {
					resolve();
				}, reason => {
					// this.activeFilter.page--;
					// this.noMore = reason;
				});
			})
		},
		savePrevious() {
			this.previousState = clone(this.pagination);
		},
		goToPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				let parsed = parseInt(this.pagination.page);
				if(!isNaN(parsed)) {
					this.activeFilter.page = Math.max(1, Math.min(this.previousState.pageCount, parsed));
					this.getFilterTrack().then(() => {
						resolve();
					}, reason => {
						// this.noMore = reason;
					});
				}
				else {
					this.pagination.page = this.previousState.page;
					reject('Not a number');
				}
			})
		},
		resetViewTrack() {
			this.noTracks = false;
			this.activeFilter.page = 1;
			this.viewTracks = [];
		},
		resetFilter() {
			this.trendingActive = false;
			this.trendingType = 'daily';
			this.searchValue = "";
			this.activeFilter =	{
									trackType: 'audio',
									genre: null,
									subgenre: null,
									remixer: null,
									date: {
										name: null,
										createdAt: null,
										updatedAt: null
									},
									page: 1
								};
			this.resetViewTrack();
			this.activeSort.type = 'createdAt';
			this.activeSort.reverse = false;
			return this.getFilterTrack();
		},
		filterLocal({local, filterParams, searchText}) {
			let viewTracks = local;
			delete filterParams.sort
			for(let key in filterParams) {
				viewTracks = viewTracks.filter(item => {
					if(key == 'or') {
						let artistExist = item.artist && item.artist.toLowerCase().indexOf(searchText) != -1
						let titleExist = item.title && item.title.toLowerCase().indexOf(searchText) != -1
						return artistExist || titleExist;
					}
					else {
						return  item[key] == filterParams[key]
					}
				})
			}
			return viewTracks
		},
		getVersion(v) {
			if( v == "Clean" || v == "clean") {
				return "C";
			} else if( v == "Dirty" || v == "dirty") {
				return "D";
			}
		},
		getFilterTrack({params, concat} = {}) {
			this.noMore = false;
			let filterParams = Object.assign({}, params || {});
			// filter by main genre if checked
			// if(this.user && this.user.id) {
				if(this.activeFilter.artist) filterParams.artist = this.activeFilter.artist;
				if(this.activeFilter.title) filterParams.title = this.activeFilter.title;

				if(this.activeFilter.genre) filterParams.genre = this.activeFilter.genre;

				// filter by sub genre if checked
				if(this.activeFilter.subgenre) filterParams.subgenre = this.activeFilter.subgenre;

				// filter by date if checked
				if(this.activeFilter.date.createdAt) filterParams.createdAt = this.activeFilter.date.createdAt;
				if(this.activeFilter.date.updatedAt) filterParams.updatedAt = this.activeFilter.date.updatedAt;

				if(this.activeFilter.toBpm && this.activeFilter.fromBpm){
					filterParams.fromBpm = this.activeFilter.fromBpm;
					filterParams.toBpm = this.activeFilter.toBpm;
				}
				
				if(this.activeFilter.remixer) filterParams.remixer = this.activeFilter.remixer;
			// }
			
			// get current page
			// filter by search words if exist
			if(this.searchValue && this.searchValue.trim().length) {
				filterParams.searchValue = this.searchValue;
			}
			if(this.activeFilter.hasOwnProperty('isClean')) {
				if(this.activeFilter.isClean == "clean") {
					filterParams.comment = 'clean';
				}
				else {
					filterParams.comment = ['dirty', null, ''];
				}
			}
			// sort settings
			if(this.popularityCheck === false) {
				filterParams.sort = 'createdAt ' + (this.activeSort.reverse ? 'ASC' : 'DESC');
				if(this.activeSort.type) {
					filterParams.sort = this.activeSort.type + ' ' + (this.activeSort.reverse ? 'ASC' : 'DESC');
				}
			} else {
				filterParams.sort = this.activeSort.type + ' DESC';	
			}
			this.loadingTrack = true;
			let currentUrl = window.location.href.toString().substr( window.location.href.toString().lastIndexOf('/') + 1);
			if(currentUrl == 'remix'){
				return new Promise((resolve, reject) => {
					UploadsService.getRemixTracks({ search: {
						query: filterParams,
						pagelimit: {
							page: this.activeFilter.page
						}
					}
				}).then(data => {
						this.pagination = data.meta;
						this.viewTracks = concat ? this.viewTracks.concat(data.tracks) : data.tracks;
						this.loadingTrack = false;
						
						if (data.tracks.length) {
							resolve(data);
							this.noTracks = false;
						}
						else {
							this.noTracks = true;
							console.log('No more tracks')
							reject({ message: 'No more tracks'});
						}
					}, reason => {
						reject({ message: reason });
					})
				})
			} else if(currentUrl == 'unsigned-artists'){
				return new Promise((resolve, reject) => {
					const currentUrl = window.location.href.toString().substr( window.location.href.toString().lastIndexOf('/') + 1);
					UploadsService.getOdestTracks({ search: {
						query: filterParams,
						pagelimit: {
							page: this.activeFilter.page
						}
					}
				}).then(data => {
						this.pagination = data.meta;
						this.viewTracks = concat ? this.viewTracks.concat(data.tracks) : data.tracks;
						this.loadingTrack = false;
						
						if (data.tracks.length) {
							resolve(data);
							this.noTracks = false;
						}
						else {
							this.noTracks = true;
							console.log('No more tracks')
							reject({ message: 'No more tracks'});
						}
					}, reason => {
						reject({ message: reason });
					})
				})
			}
			return new Promise((resolve, reject) => {
				const currentUrl = window.location.href.toString().substr( window.location.href.toString().lastIndexOf('/') + 1);
				console.log(currentUrl);
				UploadsService.getRemixTracks({ search: {
						query: filterParams,
						pagelimit: {
							page: this.activeFilter.page
						}
					}
			}).then(data => {
					this.pagination = data.meta;
					this.viewTracks = concat ? this.viewTracks.concat(data.tracks) : data.tracks;
					this.loadingTrack = false;
					
					if (data.tracks.length) {
						resolve(data);
						this.noTracks = false;
					}
					else {
						this.noTracks = true;
						console.log('No more tracks')
						reject({ message: 'No more tracks'});
					}
				}, reason => {
					reject({ message: reason });
				})
			})
		},
		checkExpire() {
			let expDate = this.user.subscriptions[globalSettings.product_id];
			let isExist = new Date(`${expDate}`) > new Date().getTime();
			if(!isExist) {
				return true;
			}
			return false;
		},
		confirmDownload(event, track) {
			if(this.locked.type == 'expire') {
				if(event) event.preventDefault();
				if(event) event.stopPropagation();
				this.$root.$emit('show::modal', 'expire');
			}
			this.downloadTrack = track;
			if(this.downloadTrack.uploads && this.downloadTrack.uploads[this.user.id] >= 3 && !this.user.admin) {
				if(event) event.preventDefault();
				this.alertType = 'downloadLimit';
				return this.$root.$emit('show::modal', 'alert');
			}
			if(this.user && this.user.id && !this.user.admin && this.downloadTrack.uploads[this.user.id] >= 3) {
				if(event) event.preventDefault();
				this.downloadTrack.uploads[this.user.id] = this.downloadTrack.uploads[this.user.id] + 1;
			}
		},
		getTrack() {
			if(this.user.admin) return;
			this.window.location = '/download-track/' + this.downloadTrack.id;
			this.$set(this.downloadTrack.uploads, this.user.id, (this.downloadTrack.uploads[this.user.id] || 0) + 1)
		},
		likeThisSong(event, track) {
			let self = this;
			if(this.locked.type == 'expire') {
				if(event) event.preventDefault();
				if(event) event.stopPropagation();
				this.$root.$emit('show::modal', 'expire');
			}
			let lyks = JSON.parse(track.likes);
			console.log(lyks[this.user.id]);
			if(lyks && lyks[this.user.id] && lyks[this.user.id] > 0){
				if(event) event.preventDefault();
				this.alertType = 'isLiked';
				return this.$root.$emit('show::modal', 'alert');
			} else {
				UploadsService.updateRemixOdestLikesCount({trackId: track.id}).then(data => {
					if(data.error) {
						console.log('Error Occured In Like update');
					}
					else {
						console.log('Like Added Successfuly');
						self.getFilterTrack();
					}
				});
			}
		},
		dislikeThisSong(event, track) {
			let self = this;
			if(this.locked.type == 'expire') {
				if(event) event.preventDefault();
				if(event) event.stopPropagation();
				this.$root.$emit('show::modal', 'expire');
			}
			let dislyks = JSON.parse(track.dislikes);
			console.log(dislyks[this.user.id]);
			if(dislyks && dislyks[this.user.id] && dislyks[this.user.id] > 0){
				if(event) event.preventDefault();
				this.alertType = 'isDisliked';
				return this.$root.$emit('show::modal', 'alert');
			} else {
				UploadsService.updateRemixOdestDisLikesCount({trackId: track.id}).then(data => {
					if(data.error) {
						console.log('Error Occured In DisLike update');
					}
					else {
						console.log('DisLike Added Successfuly');
						self.getFilterTrack();
					}
				});
			}
		}
	}
})
