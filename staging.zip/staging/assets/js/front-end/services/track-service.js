'use strict';
import axios from 'axios';
import {BASE_URL} from '../../config';

const getConfig = function() {
  const url = `${BASE_URL}/config`;
  return axios.get(url).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      error: error
    })
  });
}

const trackSchema = function(updateNeeded) {
  const url = `${BASE_URL}/get-model/track`;
  return axios.get(url).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      message: 'Tracks model not found',
      error: error
    })
  });
}

const getTracks = (params) => {
  const url = `${BASE_URL}/search/autocomplete`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.get(url, params, function(data) {
		    resolve(data);
      });
    }
    axios.get(url, {
      params: Object.assign({ json: true }, params)
    }).then(response => {
      // get body data
	    return response.data.tracks;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}
const requestPageDownload= (params) => {
	const url = `${BASE_URL}/download-page`;
	return new Promise((resolve, reject) => {
		if(io.socket) {
		  return io.socket.get(url, params, function(data) {
				resolve(data);
		  });
		}
		axios.get(url, {
		  params: Object.assign({ json: true }, params)
		}).then(response => {
		  // get body data
			return response;
		}, error => {
		  // error callback
		  reject(new Error({
			message: 'Tracks not found',
			erorr: erorr
		  }))
		  return new Error({
			message: 'Tracks not found',
			erorr: erorr
		  })
		});
	})
}
const removeTrack = (params) => {
  const url = `${BASE_URL}/admin/track/destroy`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.delete(`${BASE_URL}/admin/track/destroy/${params.id}`, { _csrf: params.csrf }, function (data){
        resolve();
      });
    }
    else {
      axios.delete(`${BASE_URL}/admin/track/destroy/${params.id}`, { _csrf: params.csrf }).then((data) => {
        resolve();
      });
    }
  })
}
const upload = (formData) => {
    const url = `${BASE_URL}/file/upload`;
    return axios.post(url, formData)
        // get data
        .then(x => x.data)
        // add url field
        .then(x => x.map(file => Object.assign({},
            file, {})));
}

const save = (file, _csrf) =>{
  const url = `${BASE_URL}/track/create`;
    return axios.post(url, {
      _csrf: _csrf,
      fileInfo: file
    })
        // get data
        .then(x => x.data, err => {
          console.log(err)
        })
        // // add url field
        // .then(x => x.map(file => Object.assign({},
        //     file, {})));
}

const checkDownloadCount = ({id, csrf}) => {
  const url = `${BASE_URL}/check-download-track`;
  return new Promise((resolve, reject) => {
    axios.get(`${url}/${id}`, { _csrf: csrf || '' }).then(response =>{
      resolve(response.data);
    }).catch(error => {
      console.log(error);
    });
  })
}
const markedAllAsDownloaded = () => {
  const url = `${BASE_URL}/marked-as-downloaded`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.get(url, {}, responce => {
        resolve(responce);
      });
    }
    else {
      axios.get(url, { }).then(data => {
        resolve();
      });
    }
  })
}

export { 
  trackSchema,
  getTracks,
  requestPageDownload,
  removeTrack,
  getConfig,
  upload,
  checkDownloadCount,
  save,
  markedAllAsDownloaded
}