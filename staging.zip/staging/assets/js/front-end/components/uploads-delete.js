import Vue from 'vue';

export default Vue.component('delete-modal', {
	template: '#delete-modal-template',
    props: ['id'],
    methods: {
    	close() {  this.$emit('close') }
    }
})