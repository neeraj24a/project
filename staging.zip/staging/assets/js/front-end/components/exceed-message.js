import Vue from 'vue';

export default Vue.directive('exceed-message', {
	inserted(el, binding, vnode) {
		let params = binding.value;
		el.addEventListener('click', e => {
			if(params.disabled) {
				alert(params.message);
				e.preventDefault();
			}
		}, this);
	}
})