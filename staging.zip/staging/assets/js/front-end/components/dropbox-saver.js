import Vue from 'vue';
let dropboxSaver = Vue.component('dropbox-saver', {
	template: `
    <a class="btn btn-block btn-social btn-dropbox dropbox-save" v-on:click.prevent="!loading && dropboxSave()">
      <span class="fa fa-dropbox"></span>
      <span v-if="!loading">Save to your Dropbox</span>
      <span v-if="loading">Loading...</span>
    </a>
  `,
  data: function() {
    return {
      loading: true,
      cart: []
    }
  },
  props: ['model', 'success-cb'],
  watch: {
    model: function(val) {
      console.log(val)
      this.cart = val;
    }
  },
  mounted() {
    this.cart = this.model;
    let checkDB = setInterval(function() {
      this.loading = !(window.Dropbox && typeof window.Dropbox.save === 'function');
      if(!this.loading) clearInterval(checkDB);
    }.bind(this), 1000)
    
  },
  methods: {
    dropboxSave() {
      console.log(this.loading)
      if(!this.loading) {
        let files = this.cart.map(track => {
          return {
            url: track.url,
            filename: track.name
          };
        });
        let tick = files.length;

        this.$emit('onsaving', true);
        let successHandler = function() {
          this.loading = false;
          console.log('Success dropbox saving');
          this.$parent.$emit('onsuccess');
        }.bind(this)
        let errorHandler = function(errorMessage) {
          console.log('Dropbox error: ', errorMessage);
          this.$parent.$emit('onerror', errorMessage);
          this.loading = false;
        }.bind(this)
        

        let options = {
          files: files,
          success:  function(){
            successHandler();
          },
          cancel: function(){
            errorHandler('Cancel');
          },
          error: function(errorMessage) {
            errorHandler(errorMessage);
          }
        };
        if(files.length) {
          this.loading = true;
          window.Dropbox.save(options)
        }
      }
      else {
        alert(`Dropbox plugin isn't initted!`)
      }
    }
  }
});

export {
  dropboxSaver
}