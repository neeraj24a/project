var webpack = require("webpack") ,
  path = require("path");
var PATHS = {
  root   : path.resolve("."),
  assets : path.join(path.resolve("."), "assets"),
  dist   : path.join(path.resolve("."), ".tmp/public/js")
};

var webpackOptions = {
  context: PATHS.assets,
  entry: {
    track: './js/server/track.js',
	home: './js/front-end/home.js',
	uploads: './js/front-end/uploads.js',
    audio: './js/front-end/audio.js',
    artist: './js/front-end/artist.js',
    cart: './js/front-end/cart.js',
	ro: './js/front-end/ro.js',
	remix: './js/front-end/remix.js',
	unsignedArtist: './js/front-end/unsigned-artist.js'
  },
  output: {
    path: PATHS.dist + '/bundle',
    filename: "[name]-bundle.js",
    chunkFilename: 'chunks/[name].js'
  },
  devtool: 'source-map',
  stats: {
      colors: true,
      reasons: true,
  },
  module: {
    loaders: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
          options: {
            "plugins": ["transform-es2015-modules-amd"],
            presets: ["es2015"]
          }
        }
      },
      {
        test: /\.css$/,
        use: [
          { loader: "style-loader" },
          { loader: "css-loader" }
        ]
      }
    ]
  },
  resolve: {
    modules: ['node_modules'],
    alias: {
      'vue': 'vue/dist/vue'
    }
  },
  plugins: [
    // new webpack.optimize.UglifyJsPlugin()
    new webpack.HotModuleReplacementPlugin(),
    new webpack.optimize.CommonsChunkPlugin({
      name: "common"
    }),
    new webpack.DefinePlugin({
      'process.env.PORT': JSON.stringify(process.env.NODE_ENV || '1337'),
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'develop')
    })
  ]
};

module.exports = function(gulp, plugins, growl) {
  gulp.task('babel:dev', function(cb) {
    webpack(webpackOptions).run(function(err, stats) {
      console.log(err)
      if(err) {
        console.error('>> webpack err: ', err);
      }
      cb();
    });
    return {};
  });
};