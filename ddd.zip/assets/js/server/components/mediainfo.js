var CHUNK_SIZE = 5 * 1024 * 1024;
var miLib, mi;
var processing = false;

var x2js = window['X2JS'] ? new X2JS() : null;

// Results 
function addResult(name, result) {
  if(!x2js) reject('x2js module did not load')
  var resultObj = x2js.xml_str2json(result);
  resultObj.date = Date.now();
  resultObj.fileName = name;
  return new Promise((resolve, reject) => {
    resolve(resultObj);
  })
}
// MediaInfo processing

const parseFile = (file) => {
  return new Promise((resolve, reject) => {
    if (processing) {
      return;
    }
    processing = true;

    var fileSize = file.size, offset = 0, state = 0, seekTo = -1, seek = null;

    mi.open_buffer_init(fileSize, offset);

    var processChunk = function(e) {
      var l;
      if (e.target.error === null) {
        var chunk = new Uint8Array(e.target.result);
        l = chunk.length;
        state = mi.open_buffer_continue(chunk, l);
        seekTo = mi.open_buffer_continue_goto_get();
        if(seekTo === -1){
          offset += l;
        }else{
          offset = seekTo;
          mi.open_buffer_init(fileSize, seekTo);
        }
        chunk = null;
      } else {
        var msg = 'An error happened reading your file!';
        console.err(msg, e.target.error);
        processingDone();
        alert(msg);
        return;
      }
      // bit 4 set means finalized
      if (state&0x08) {
        var result = mi.inform();
        mi.close();
        addResult(file.name, result).then(data => {
          resolve(data);
        });
        processingDone();
        return;
      }
      seek(l);
    };

    function processingDone() {
      processing = false;
    }

    seek = function(length) {
      if (processing) {
        var r = new FileReader();
        var blob = file.slice(offset, length + offset);
        r.onload = processChunk;
        r.readAsArrayBuffer(blob);
      }
      else {
        mi.close();
        processingDone();
      }
    };
    // start
    seek(CHUNK_SIZE);
  })
}




// init mediainfo
const init = () => {
  return new Promise((resolve, reject) => {
    miLib = MediaInfo(function() {
      console.debug('MediaInfo ready');
      window['miLib'] = miLib; // debug
      mi = new miLib.MediaInfo();
      if(miLib) {
        resolve(mi);
      }
      else {
        reject({
          error: 'Mediainfo plugin error'
        });
      }
    });
  })
}

export {init, parseFile};