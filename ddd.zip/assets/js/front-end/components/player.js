import Vue from 'vue';
import {AudioPlayer, VideoPlayer} from '../../plugins/player'

let videoHolder = document.createElement('div');
videoHolder.innerHTML = `<div class="video-player">
											<div class="video-placeholder"></div>
											<a class="close">X</a>
											<div class="video-title" id="videoTitle"></div>
										</div>`;
document.body.appendChild(videoHolder);

let videoInst = new VideoPlayer(videoHolder, null, null, {});

let count = 0;
let prevUid = null


export default Vue.directive('player', {
	inserted(el, binding) {
		let playerInst = null;
		if(binding.value.options.type == 'audio') {
			playerInst = new AudioPlayer(el, binding.value.url, Object.assign(binding.value.options, {
				preview: binding.value.options.previewAudio
			}));
		}
		if(binding.value.options.type == 'video') {
			let uid = count;
			count++;
			el.querySelector('.tracks-list__play').addEventListener('click', e => {
				e.preventDefault();
				console.log(prevUid == uid);
				if(prevUid == uid) {
					videoInst.toggle();
					return;
				}
				console.log('reset')
				prevUid = uid;
				// playerInst = videoInst;
				videoInst.updateOptions(binding.value.url,binding.value.title, Object.assign(binding.value.options, {
					preview: binding.value.options.previewVideo,
					onPlay: function() {
						console.log('play', el)
						el.classList.add('playing');
					},
					onPause: function() {
						console.log('pause', el)
						el.classList.remove('playing');
					},
					onUpdate: function() {
						console.log('update', el)
						el.classList.remove('playing');
					}
				}));
				videoInst.play();
			}, this)
			// playerInst = new VideoPlayer(el, binding.value.url, Object.assign(binding.value.options, {
			// 	preview: binding.value.options.previewVideo
			// }));
		}
		if(io.socket) {
			io.socket.on('settings-updated', function updateSetup(params) {
				if(playerInst && typeof playerInst.updateOptions === 'function') {
					playerInst.updateOptions({
						preview: playerInst.options.type === 'audio' ? params.previewAudio : params.previewVideo
					})
				}
			})
		}
	}
})