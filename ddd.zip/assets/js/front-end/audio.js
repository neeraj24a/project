import _ from 'lodash/core';
import clone from 'lodash/clone';
import {BASE_URL} from '../config';
import {polyfill} from 'es6-promise';
import Vue from 'vue';
import moment from 'moment';
import './components/autocomplete';
import './components/player';
import './components/locked';
import WaveSurfer from 'wavesurfer.js';


import 'bootstrap-vue/dist/bootstrap-vue.css'

import BootstrapVue from 'bootstrap-vue';

import * as CoreService from './services/core-service';
import * as AudioService from './services/audio-service';
import { getGenreFilters } from './services/filter-service';
import { getRemixerFilters } from './services/remixer-filter-service';
import { filterComponent } from './components/filters.js';

Vue.config.errorHandler = function (err, vm, info) {
	console.log(err);
	console.log(vm);
	console.log(info);
}
Vue.use(BootstrapVue);

/* Home application */
let app = new Vue({
	el: '#app',
	data: {
		//wavesurfer: new WaveSurfer(),
		activeSort: {
			type: 'createdAt',
			reverse: false
		},
		activeFilter: {
			trackType: 'audio',
			genre: null,
			subgenre: null,
			date: {
				name: null,
				createdAt: null,
				updatedAt: null
			},
			page: 1
		},
		noTracks: false,
		popularityCheck: false,
		searchValue: '',
		loadingTrack: true,
		loadingMessage: 'Application loading',
		viewTracks: [],
		trackSchema: {},
		filters: [],
		remixers: [],
		filterCollection: {},
		alertType: null,
		noMore: null,
		downloadTrack: null,
		user: null,
		searchStart: null,
		pagination: null,
		searchTitle: null,
		titleText: null,
		cartQueue: [],
		locked: false,
		moment,
		window,
		playing: false,
		artist: '',
		song: '',
		cartCount: 0
	},
	beforeCreate() {
		AudioService.trackSchema().then(schema => {
			this.trackSchema = schema.model;
			return schema.model;
		}).then(remixers => {
			new Promise((resolve, reject) => {
				getRemixerFilters().then(data => {
					this.remixers = data;
					console.log(this.remixers);
				})
			})
		}).then(model => {
			return getGenreFilters();
		}).then(filters => {
			this.filters = filters;
		})
	},
	mounted () {
		this.$nextTick(() => {
			this.wavesurfer = new WaveSurfer.create({
				container: '#waveform',
				waveColor: '#ffffff',
				progressColor: '#333333',
				height: 40,
				backend: 'MediaElement'
			})
		})
		this.loadingTracks();
		this.loadCart();
		CoreService.getUserInfo().then(data => {
			this.user = data;
			if(this.user && this.user.id && this.user.isLocked && !this.user.admin) {
				this.locked = this.user.isLocked;
			}
			if(this.user.error) {
				this.locked = {msg: this.user.error};
			}

			this.checkCart(this.viewTracks);
			if(io.socket && this.user && this.user.id) {
				io.socket.on('downloaded.'+ this.user.id, function updateTrack({ track }) {
					track = track[0];
					if(this.user.admin) return;
					this.viewTracks.forEach(item => {
						if(track.id === item.id) {
							item.uploads[this.user.id] = track.uploads[this.user.id];
							this.$set(item, `uploads[${this.user.id}]`, track.uploads[this.user.id])
						}
						item.remix.forEach(remix => {
							if(track.id === remix.id) {
								remix.uploads[this.user.id] = track.uploads[this.user.id];
								this.$set(remix, `uploads[${this.user.id}]`, track.uploads[this.user.id])
							}
						})
					}, this);
				}.bind(this))

				io.socket.on('cart-update.'+ this.user.id, function updateTrack({ id, cart, type }) {
					let changed = _.find(this.viewTracks, { 'id': id*1 });
					if (changed) {
						if(type === 'add') {
							this.$set(changed, 'added', true);
							this.$set(changed, 'processing', false);
						}
						if(type === 'remove') {
							this.$set(changed, 'added', false);
							this.$set(changed, 'processing', false);
						}
					}
				}.bind(this))

				io.socket.on('cart-update.'+ this.user.id, function updateTrack(updated) {
					let changed = _.find(this.viewTracks, { 'id': updated.id*1 });
					changed = updated;
				}.bind(this))
			}
		}, reason => {
			return reason;
		})
	},
	methods: {
		play () {
			this.wavesurfer.playPause()
			if(this.wavesurfer.isPlaying()){
				this.playing = true;	
			} else {
				this.playing = false;
			}
		},
		playSong(track) {
			this.wavesurfer.on('ready', this.wavesurfer.play.bind(this.wavesurfer));
			if(this.wavesurfer.load(track.url)){
				this.wavesurfer.play()
			}
			this.playing = true;
			this.artist = track.artist;
			this.song = track.title;
			this.updateStream(track)
		},
		updateStream(track) {
			CoreService.updateStreamCount({trackId: track.id}).then(data => {
				if(data.error) {
					console.log('Error Occured In Stream update');
				}
				else {
					console.log('Added Successfuly');
				}
			});
		},
		loadingTracks () {
			this.resetViewTrack();
			return this.getAudioTrack().then(data => {
				return data;
			});
		},
		getDownloadCount(count) {
			let html = '';
			if(count == "1"){
				html += '<div class="count-1">&nbsp;</div>';
			} else if (count == "2") {
				html += '<div class="count-1">&nbsp;</div>';
				html += '<div class="count-2">&nbsp;</div>';
			} else if (count == "3") {
				html += '<div class="count-1">&nbsp;</div>';
				html += '<div class="count-2">&nbsp;</div>';
				html += '<div class="count-3">&nbsp;</div>';
			}
			return html;
		},
		getVersion(v) {
			if( v == "Clean" || v == "clean") {
				return "C";
			} else if( v == "Dirty" || v == "dirty") {
				return "D";
			}
		},
		getArtistTemplate (artistName) {
			let findChars = [' & ',' X ',' < ',' , ',', ',' feat ',' Feat. ',' ft ',' ft. ',' Ft. ',' Vs ',' vs '];
			let findPos = [];
			let html = "";
			let mtchChar = [];
			findChars.forEach(function(element, index){
				if(artistName.indexOf(element) != '-1'){
					mtchChar.push(element);
				}
			});
			if(mtchChar.length == 0){
				html = '<a href="/artist/'+artistName+'">'+artistName+'</a>';
				return html;
			} else if (mtchChar.length == 1){
				let string = artistName.split(mtchChar[0]);
				html = '<a href="/artist/'+string[0]+'">'+string[0]+'</a>'+mtchChar[0];
				html += '<a href="/artist/'+string[1]+'">'+string[1]+'</a>';
				return html;
			}
			for(var i = 0; i < findChars.length; i++){
				if(artistName.indexOf(findChars[i]) != -1){
					var searchStrLen = findChars[i].length;
					if (searchStrLen != 0) {
						var startIndex = 0, index;
						while ((index = artistName.indexOf(findChars[i], startIndex)) > -1) {
							var a = [];
							a['pos'] = index;
							a['chr'] = findChars[i]
							findPos.push(a);
							startIndex = index + searchStrLen;
						}
					}
				}
			}
			var sorted = findPos.sort(function(a, b){
							var keyA = a.pos,
							keyB = b.pos;
							if(keyA < keyB) return -1;
							if(keyA > keyB) return 1;
							return 0;
						});
			for(var j = 0; j < sorted.length; j++){
				if(j == 0){
					html += '<a href="/artist/'+artistName.substring(0, sorted[j]['pos'])+'">'+artistName.substring(0, sorted[j]['pos'])+'</a>';
					html += sorted[j]['chr'];
				} else {
					html += '<a href="/artist/'+artistName.substring((sorted[(j - 1)]['pos'] + sorted[(j - 1)]['chr'].length), sorted[j]['pos'])+'">'+artistName.substring((sorted[(j - 1)]['pos'] + sorted[(j - 1)]['chr'].length), sorted[j]['pos'])+'</a>';
					html += sorted[j]['chr'];
					if(j == (sorted.length - 1)){
						html += '<a href="/artist/'+artistName.substring((sorted[j]['pos'] + sorted[j]['chr'].length), artistName.length)+'">'+artistName.substring((sorted[j]['pos'] + sorted[j]['chr'].length), artistName.length)+'</a>';
					}
				}
			}
			return html;

		},
		onSearch(result) {
			delete this.activeFilter.artist;
			delete this.activeFilter.title;
			if(result.hasOwnProperty('artist')) this.activeFilter.artist = result.artist;
			if(result.hasOwnProperty('title')) this.activeFilter.title = result.title;
			
			if(typeof result === 'object') {
				this.searchValue = (result.artist || '...') + ' - ' + (result.title || '...');
			}
			else {
				this.searchValue = result;
			}
			this.resetViewTrack();
			return this.getFilterTrack()
		},
		resetAllFilter() {
			this.searchValue = '';
			delete this.activeFilter.artist;
			delete this.activeFilter.title;
			delete this.activeFilter.isClean;
			delete this.activeFilter.popularity;
			delete this.activeFilter.remixer;
			
			this.activeFilter = Object.assign(this.activeFilter, {
				genre: null,
				subgenre: null,
				date: {
					name: null,
					createdAt: null,
					updatedAt: null
				},
				page: 1
			})
			this.resetFilter();
			return this.getFilterTrack()
		},
		sortBy(e) {
			let filter = "";
			
			if(e.target.value == "title-r"){
				this.activeSort.reverse = true;
				filter = "title";
			} else if(e.target.value == "artist-r"){
				this.activeSort.reverse = true;
				filter = "artist";
			} else {
				this.activeSort.reverse = false;
				filter = e.target.value;
			}
			this.activeSort.type = filter;

			this.resetViewTrack();
			return this.getFilterTrack()
		},
		sortByDate(e) {
			if(e.target.value == "" || e.target.value == "a"){
				this.activeSort.reverse = false;
			} else if(e.target.value == 'z'){
				this.activeSort.reverse = true;
			}
			this.activeSort.type = 'createdAt';

			this.resetViewTrack();
			return this.getFilterTrack()
		},
		filterByClean(e) {
			let isClean = e.target.value;
			if(isClean == ""){
				delete this.activeFilter.isClean;
			} else {
				if(isClean == this.activeFilter.isClean) return;
				if(this.activeFilter.hasOwnProperty('isClean')) {
					if(isClean != this.activeFilter.isClean) {
						this.activeFilter.isClean = isClean;
					}
					else {
						delete this.activeFilter.isClean;
					}
				}
				else {
					this.activeFilter.isClean = isClean;
				}
			}

			this.resetViewTrack();
			return this.getFilterTrack()
		},
		filterByRemixer(remixer) {
			//if(artist == this.searchValue) return;
			if(remixer.length > 0) {
				this.resetViewTrack();
				this.activeFilter.remixer = remixer;
				//this.searchValue = artist;
				this.activeSort = {
					type: 'title',
					reverse: false
				}
				return this.getFilterTrack()
			} else {
				this.resetViewTrack();
				this.activeSort = {
					type: 'createdAt',
					reverse: false
				}
				return this.getFilterTrack();
			}
		},
		filterByTitle(title) {
			if(title == this.searchValue) return;
			if(title) {
				this.searchValue = title;
				this.activeSort = {
					type: 'title',
					reverse: false
				}
				this.resetViewTrack();
				return this.getFilterTrack();
			}
		},
		filterByFromBpm(e){
			debugger;
			if(!this.activeFilter.toBpm){
				this.activeFilter.toBpm = {'<': 500};
			}
			let filter = e.target.value;
			if(filter){
				this.activeFilter.fromBpm = {'>': filter};
			} else {
				delete this.activeFilter.fromBpm;
			}
			this.resetViewTrack();
			return this.getFilterTrack();
		},
		filterByToBpm(e){
			debugger;
			if(!this.activeFilter.fromBpm){
				this.activeFilter.fromBpm = {'<': 0};
			}
			let filter = e.target.value;
			if(filter){
				this.activeFilter.toBpm = {'<': filter};
			} else {
				delete this.activeFilter.toBpm;
			}
			this.resetViewTrack();
			return this.getFilterTrack();
		},
		resetBPM(){
			delete this.activeFilter.fromBpm;
			delete this.activeFilter.toBpm;
			this.resetViewTrack();
			return this.getFilterTrack();
		},
		filterSideBarGenre(e){
			let genre = e.target.value;
			this.filterByGenre(genre);
		},
		filterSideBarRemixer(e){
			let remixer = e.target.value;
			this.filterByRemixer(remixer);
		},
		filterByArtist(e) {
			let filter = e;
			if(filter == this.activeFilter.artist) return;
			if(filter) {
				if(this.activeFilter.artist && this.activeFilter.artist === filter) return;
				this.activeFilter.artist = filter;
			}
			else {
				delete this.activeFilter.artist;
			}
			this.resetViewTrack();
			return this.getFilterTrack()
		},
		filterByGenre(e) {
			let filter = e;
			if(filter == this.activeFilter.genre) return;
			if(filter) {
				if(this.activeFilter.genre && this.activeFilter.genre === filter) return;
				this.activeFilter.genre = filter;
			}
			else {
				delete this.activeFilter.genre;
			}
			this.resetViewTrack();
			return this.getFilterTrack()
		},
		filterSideBarSubGenre(e){
			let genre = e.target.value;
			this.filterBySubGenre(genre);
		},
		filterBySubGenre(e) {
			let filter = e;
			if(filter == this.activeFilter.subgenre) return;
			if(filter) {
				if(this.activeFilter.subgenre && this.activeFilter.subgenre === filter) return;
				this.activeFilter.subgenre = filter;
			}
			else {
				delete this.activeFilter.subgenre;
			}
			this.resetViewTrack();
			return this.getFilterTrack();
		},
		filterTrending(e){
			let rangeName = e.target.value;
			this.filterByDate(rangeName);
		},
		filterByDate(rangeName) {
			if(rangeName == this.activeFilter.date.name) return;
			this.activeFilter.trendingType = rangeName;
			let start = null, end = null;
			this.activeFilter.date.name = rangeName;
			delete this.activeFilter.date.createdAt;
			delete this.activeFilter.date.updatedAt;
			delete this.activeFilter.isRadio;
			this.resetViewTrack();
			switch (rangeName) {
				case 'daily':
					// tracks by current day
					start = moment(new Date()).subtract(1, 'day').startOf('day').toDate();
					end = moment(new Date()).subtract(-1, 'day').startOf('day').toDate();
					this.activeFilter.date.updatedAt = {
						'>': moment(start).format("YYYY-MM-DD HH:mm:ss"),
						'<': moment(end).format("YYYY-MM-DD HH:mm:ss")
					};
					this.activeFilter.day = {'>': 0};
					this.popularityCheck = true;
					this.activeSort.type = 'day';
					this.activeFilter.week = null;
					this.activeFilter.month = null;
					break;
				case 'weekly':
					// tracks by last seven days
					start = moment(new Date()).subtract(7, 'day').startOf('day').toDate();
					end = moment(new Date()).subtract(-1, 'day').startOf('day').toDate();
					this.activeFilter.date.updatedAt = {
						'>': moment(start).format("YYYY-MM-DD HH:mm:ss"),
						'<': moment(end).format("YYYY-MM-DD HH:mm:ss")
					};
					this.activeFilter.week = {'>': 0};
					this.popularityCheck = true;
					this.activeFilter.day = null;
					this.activeFilter.month = null;
					this.activeSort.type = 'week';
					break;
				case 'monthly':
					// tracks by current month
					start = moment(new Date()).startOf('month').toDate();
					// start = moment(new Date()).subtract(30, 'day').startOf('day').toDate();
					end = moment(new Date()).subtract(-1, 'day').startOf('day').toDate();
					this.activeFilter.date.updatedAt = {
						'>': moment(start).format("YYYY-MM-DD HH:mm:ss"),
						'<': moment(end).format("YYYY-MM-DD HH:mm:ss")
					};
					this.activeFilter.day = null;
					this.activeFilter.week = null;
					this.activeFilter.month = {'>': 0};
					this.popularityCheck = true;
					this.activeSort.type = 'month';
					break;
				case 'radio':
					// tracks by radio
					this.activeFilter.isRadio = true;
					this.popularityCheck = false;
					this.activeFilter.day = null;
					this.activeFilter.week = null;
					this.activeFilter.month = null;
					this.activeSort.type = 'createdAt';
					this.popularityCheck = false;
					break;
				default:
					// no date limit
					start = end = null;
					this.activeFilter.date = {
						name: null,
						createdAt: null,
						updatedAt: null
					};
					this.activeFilter.day = null;
					this.activeFilter.week = null;
					this.activeFilter.month = null;
					this.popularityCheck = false;
					this.activeSort.type = 'createdAt';
					break;
			}
			

			this.resetViewTrack();
			return this.getFilterTrack();
		},
		filterByType(type) {
			if(type == this.activeFilter.trackType) return;
			this.activeFilter.trackType = type;
			if(!type) {
				this.activeFilter.trackType = 'audio';
			}
			this.resetViewTrack();
			return this.getFilterTrack()
		},
		prevPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				this.activeFilter.page--;
				this.getFilterTrack().then(() => {
					resolve();
				}, reason => {
					// this.activeFilter.page--;
					// this.noMore = reason;
				});
			})
		},
		nextPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				this.activeFilter.page++;
				this.getFilterTrack().then(() => {
					resolve();
				}, reason => {
					// this.activeFilter.page--;
					// this.noMore = reason;
				});
			})
		},
		savePrevious() {
			this.previousState = clone(this.pagination);
		},
		goToPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				let parsed = parseInt(this.pagination.page);
				if(!isNaN(parsed)) {
					this.activeFilter.page = Math.max(1, Math.min(this.previousState.pageCount, parsed));
					this.getFilterTrack().then(() => {
						resolve();
					}, reason => {
						// this.noMore = reason;
					});
				}
				else {
					this.pagination.page = this.previousState.page;
					reject('Not a number');
				}
			})
		},
		showRemix(track) {
			this.$set(track, 'showRemix', !track.showRemix)
		},
		resetViewTrack() {
			delete this.activeFilter.remixer;
			this.activeFilter.page = 1;
			this.viewTracks = [];
		},
		resetFilter() {
			this.searchValue = "";
			this.resetViewTrack();
			this.activeSort.type = 'createdAt';
			this.activeSort.reverse = false;
			return this.getFilterTrack();
		},
		filterLocal({local, filterParams, searchText}) {
			let viewTracks = local;
			delete filterParams.sort
			for(let key in filterParams) {
				viewTracks = viewTracks.filter(item => {
					if(key == 'or') {
						let artistExist = item.artist && item.artist.toLowerCase().indexOf(searchText) != -1
						let titleExist = item.title && item.title.toLowerCase().indexOf(searchText) != -1
						return artistExist || titleExist;
					}
					else {
						return  item[key] == filterParams[key]
					}
				})
			}
			return viewTracks
		},
		getFilterTrack({params, concat} = {}) {
			this.noMore = false;
			let filterParams = Object.assign({}, params || {});
			// filter by main genre if checked
			// if(this.user && this.user.id) {
				if(this.activeFilter.artist) filterParams.artist = this.activeFilter.artist;
				if(this.activeFilter.title) filterParams.title = this.activeFilter.title;

				if(this.activeFilter.genre) filterParams.genre = this.activeFilter.genre;

				// filter by sub genre if checked
				if(this.activeFilter.subgenre) filterParams.subgenre = this.activeFilter.subgenre;

				// filter by date if checked
				if(this.activeFilter.date.createdAt) filterParams.createdAt = this.activeFilter.date.createdAt;
				if(this.activeFilter.date.updatedAt) filterParams.updatedAt = this.activeFilter.date.updatedAt;

				if(this.activeFilter.toBpm && this.activeFilter.fromBpm){
					filterParams.bpm = { '>=': this.activeFilter.fromBpm, '<=': this.activeFilter.toBpm };
				}
				
				//popularity filter
				if(this.activeFilter.popularity) filterParams.popularity = this.activeFilter.popularity;
				//top downloads filter
				if(this.activeFilter.day) filterParams.day = this.activeFilter.day;
				if(this.activeFilter.week) filterParams.week = this.activeFilter.week;
				if(this.activeFilter.month) filterParams.month = this.activeFilter.month;

				if(this.activeFilter.isRadio) filterParams.isRadio = '1';
				if(this.activeFilter.trackType) filterParams.type = this.activeFilter.trackType;
				if(this.activeFilter.remixer) filterParams.remixer = this.activeFilter.remixer;
			// }
			
			// get current page
			// filterParams.page = this.activeFilter.page || 1;
			// filter by search words if exist
			if(this.searchValue && this.searchValue.trim().length) {
				
				if(this.activeFilter.artist || this.activeFilter.title) {
					
				}
				else {
					filterParams.or = [
						{
							artist: {
								contains: this.searchValue
							}
						},
						{
							title: {
								contains: this.searchValue
							}
						}
					];
				}
			}
			if(this.activeFilter.hasOwnProperty('isClean')) {
				if(this.activeFilter.isClean == "clean") {
					filterParams.comment = 'clean';
				}
				else {
					filterParams.comment = ['dirty', null, ''];
				}
			}
			// sort settings
			if(this.popularityCheck === false) {
				filterParams.sort = 'createdAt ' + (this.activeSort.reverse ? 'ASC' : 'DESC');
				if(this.activeSort.type) {
					filterParams.sort = this.activeSort.type + ' ' + (this.activeSort.reverse ? 'ASC' : 'DESC');
				}
			} else {
				filterParams.sort = this.activeSort.type + ' DESC';	
			}
			this.loadingTrack = true;
			return new Promise((resolve, reject) => {
				AudioService.getTracks({ search: {
					query: filterParams,
					pagelimit: {
						page: this.activeFilter.page
					}
				}
			}).then(data => {
					this.pagination = data.meta;
					this.checkCart(data.tracks);
					this.viewTracks = concat ? this.viewTracks.concat(data.tracks) : data.tracks;
					this.loadingTrack = false;
					
					if (data.tracks.length) {
						resolve(data);
						this.noTracks = false;
					}
					else {
						this.noTracks = true;
						console.log('No more tracks')
						reject({ message: 'No more tracks'});
					}
				}, reason => {
					reject({ message: reason });
				})
			})
		},
		getAudioTrack({params, concat} = {}) {
			return new Promise((resolve, reject) => {
				var newURL = window.location.protocol + "://" + window.location.host + "/" + window.location.pathname;
				var pathArray = window.location.pathname.split( '/' );
				var name = pathArray[2];
				let filterParams = Object.assign({}, params || {});
				filterParams.or = [
					{
						slug: {
							contains: name
						}
					}
				];
				AudioService.getTracks({ search: {
					name: name,
					query: filterParams,
					pagelimit: {
						page: this.activeFilter.page
					}
				}
			}).then(data => {
					console.log(data);
					if (data === undefined) {
						this.noTracks = true;
						console.log('No more tracks')
						reject({ message: 'No more tracks'});
						this.loadingTrack = false;	
					}
					else {
						this.pagination = data.meta;
						this.checkCart(data.tracks);
						this.titleText = data.searchFor.title;
						var trimmedString = this.titleText.substr(0, 35);
						//re-trim if we are in the middle of a word
						trimmedString = trimmedString.substr(0, Math.min(trimmedString.length, trimmedString.lastIndexOf(" ")))
						this.searchTitle = trimmedString;
						this.viewTracks = concat ? this.viewTracks.concat(data.tracks) : data.tracks;
						this.loadingTrack = false;	
					}
				}, reason => {
					reject({ message: reason });
				})
			})
		},
		confirmRemove(track) {
			this.removedTrack = track;
			this.$root.$emit('show::modal', 'confirm');
		},
		removeTrack() {
			if(!this.removedTrack) return;
			AudioService.removeTrack({ id: this.removedTrack.id }).then(() => {
      	this.viewTracks.splice(this.viewTracks.indexOf(this.removedTrack), 1);
				delete this.removedTrack;
			}, reason => {
				console.log(reason)
			});
		},
		checkExpire() {
			let expDate = this.user.subscriptions[globalSettings.product_id];
			let isExist = new Date(`${expDate}`) > new Date().getTime();
			if(!isExist) {
				return true;
			}
			return false;
		},
		confirmDownload(event, track) {
			if(this.locked.type == 'expire') {
				if(event) event.preventDefault();
				if(event) event.stopPropagation();
				this.$root.$emit('show::modal', 'expire');
			}
			this.downloadTrack = track;
			if(this.downloadTrack.uploads && this.downloadTrack.uploads[this.user.id] >= 3 && !this.user.admin) {
				if(event) event.preventDefault();
				this.alertType = 'downloadLimit';
				return this.$root.$emit('show::modal', 'alert');
			}
			if(this.user && this.user.id && !this.user.admin && this.downloadTrack.uploads[this.user.id] >= 3) {
				if(event) event.preventDefault();
				this.downloadTrack.uploads[this.user.id] = this.downloadTrack.uploads[this.user.id] + 1;
			}
		},
		getTrack() {
			if(this.user.admin) return;
			this.window.location = '/download-track/' + this.downloadTrack.id;
			this.$set(this.downloadTrack.uploads, this.user.id, (this.downloadTrack.uploads[this.user.id] || 0) + 1)
		},
		checkCart(tracks) {
			if(!tracks) return;
			tracks.forEach(track => {
				let added = _.find(this.cart, {'id': track.id });
				if(added) this.$set(track, 'added', true);
			})
		},
		loadCart() {
			console.log('load cart')
			return CoreService.getCart().then(data => {
				this.cart = data ? data.cart : [];
				this.checkCart(this.viewTracks);
				return data;
			})
		},
		toggleCart(track) {
			if(track.added)
				this.removeFromCart(track);
			else
				this.addToCart(track)
		},
		processingQueue() {
			if(this.cartQueue.length) {
				let track = this.cartQueue[0];
				if(track.queue) return;
				track.queue = true;
				CoreService.addToCart({trackId: track.id}).then(data => {
					delete track.queue;
					this.$set(track, 'processing', false);
					if(data.error) {
						this.cartQueue.forEach(item => item.processing = false);
						this.cartQueue = [];
						this.$root.$emit('show::modal', 'full_cart');
					}
					else {
						// track.added = true;
						this.$set(track, 'added', true);
						
						this.cartQueue.splice(0, 1);
						if(this.cartQueue.length) this.processingQueue();
					}
				});
			}
		},
		addToCart(track) {
			if(track.processing) return;
			this.cartQueue.push(track);
			this.processingQueue();
			this.$set(track, 'processing', true);
			if(this.cartCount == ''){
				this.cartCount = 0;	
			} else {
				this.cartCount++;
			}
			app.$refs.cartCount.innerText = this.cartCount;
		},
		removeFromCart(track) {
			if(track.processing) return;
			this.$set(track, 'processing', true);
			CoreService.removeFromCart({trackId: track.id}).then(data => {
				this.$set(track, 'added', false);
				this.$set(track, 'processing', false);
			});
		}
	}
})
