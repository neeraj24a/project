'use strict';
import axios from 'axios';
import {BASE_URL} from '../../config';

const getDayTrendings = (params) => {
  const url = `${BASE_URL}/day-trending`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.get(url, params, function(data) {
		    resolve(data);
      });
    }
    axios.get(url, {
      params: Object.assign({ json: true }, params)
    }).then(response => {
      // get body data
	    return response.data;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}
const getWeekTrendings = (params) => {
  const url = `${BASE_URL}/week-trending`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.get(url, params, function(data) {
		    resolve(data);
      });
    }
    axios.get(url, {
      params: Object.assign({ json: true }, params)
    }).then(response => {
      // get body data
	    return response.data;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}

const getMonthTrendings = (params) => {
  const url = `${BASE_URL}/month-trending`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.get(url, params, function(data) {
		    resolve(data);
      });
    }
    axios.get(url, {
      params: Object.assign({ json: true }, params)
    }).then(response => {
      // get body data
	    return response.data;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}

const checkDownloadCount = ({id, csrf}) => {
  const url = `${BASE_URL}/check-download-track`;
  return new Promise((resolve, reject) => {
    axios.get(`${url}/${id}`, { _csrf: csrf || '' }).then(response =>{
      resolve(response.data);
    }).catch(error => {
      console.log(error);
    });
  })
}
const markedAllAsDownloaded = () => {
  const url = `${BASE_URL}/marked-as-downloaded`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.get(url, {}, responce => {
        resolve(responce);
      });
    }
    else {
      axios.get(url, { }).then(data => {
        resolve();
      });
    }
  })
}

export { 
  getDayTrendings,
  getWeekTrendings,
  getMonthTrendings,
  checkDownloadCount,
  markedAllAsDownloaded
}