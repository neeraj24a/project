/**
 * isLoggedIn
 *
 * @module      :: Policy
 * @description :: Simple policy to allow any authenticated user
 * @docs        :: http://sailsjs.org/#!documentation/policies
 *
 */

module.exports = function(req, res, next) {
  let returnUrl = req.url;
  // If `req.session.me` exists, that means the user is logged in.
  if (req.session.user) {
    
    return next();
  }

  // If this is not an HTML-wanting browser, e.g. AJAX/sockets/cURL/etc.,
  // send a 401 response letting the user agent know they need to login to
  // access this endpoint.
  if (req.wantsJSON) {
    return res.send(401);
  }
  if(returnUrl && returnUrl.indexOf('download-track') != -1) {
    sails.session.redirectdownload = String(returnUrl);
  }
  // Otherwise if this is an HTML-wanting browser, do a redirect.
  return res.redirect('/login?returnto=' + returnUrl);
};