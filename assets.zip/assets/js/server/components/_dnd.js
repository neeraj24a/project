import _ from 'lodash/core';
import Vue from 'vue';
import {BASE_URL, dropBoxKey} from '../../config';
import * as mediainfo from './mediainfo';
import * as TrackService from '../services/track-service';

function clearInputFile(f){
  if(f.value){
    f.value = '';
    if(f.value){
      var form = document.createElement('form'),
          parentNode = f.parentNode, ref = f.nextSibling;
      form.appendChild(f);
      form.reset();
      parentNode.insertBefore(f,ref);
    }
  }
}

// hash generation function
let generateRandomHash = function() {
  let hexDigits = '0123456789abcdef',
      s = [];
  for (let i = 0; i < 32; i++) {
      s[i] = hexDigits.substr(Math.floor(Math.random() * hexDigits.length), 1);
  }
  return s.join('');
};

//  @dragover="dragover" @drop="drop"
export default Vue.component('dnd', {
  template: `<div class="dnd-zone">
    <div v-if="mediainfo">
      <div v-if="isdnd" class="drop-zone" @dragover="dragover" @drop="drop">
        <span>Drop your files here</span>
      </div>
      <div class="fallback">
        <input type="file" @change="drop" multiple />
      </div>
    </div>
    <div v-else-if="!mediainfo">
      {{mediainfo.error ? mediainfo.error : 'Loading mediainfo plugin'}}
    </div>
  </div>
  `,
  data: () => {
    return {
      mediainfo: false,
      isdnd: !!window.File && !!window.FileReader && !!window.FileList && !!window.Blob
    }
  },
  props: ['options', 'preparedFiles'],
  mounted() {
    mediainfo.init().then(response => {
      console.log('mediainfo plugin inited')
      this.mediainfo = true;
    }, reason => {
      this.mediainfo.error = reason;
      alert(reason)
    })
  },
  methods: {
    viewFiles: function(files) {
      this.options.callback(files);
    },
    metaForFiles: (files) => {
      let promises = [];
      files.forEach((file) => {
        promises.push(new Promise((resolve, reject) => {
          window.jsmediatags.read(file.destination, {
            onSuccess: (data) => {
              file.metatags = data.tags;
              resolve(file);
            },
            onError: (error) => {
              resolve(file);
            }
          })
        }));
      });
      return Promise.all(promises).then(values => {
        
      });
    },
    dropboxCallback: (files) => {
      return metaForFiles(files)
    },
    dragover: (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'copy';
    },
    drop: function(e) {
      e.preventDefault();
      e.stopPropagation();
      // if(e.target) e.target.reset();
      let files = [];
      switch (e.type) {
        case 'drop':
          files = e.dataTransfer.files;
          break;
        case 'change':
          files = e.target.files;
          break;
      }
      this.$emit('processing', 1);
      let num = 0;
      // let result = [];
      let self = this;
      function step(){
        let file = files[num];
        this.$emit('processing', parseInt(100 / files.length * num));
        this.getInfo(file).then(data => {
          // result.push(data);
          this.$emit('addprepareded', data);
          if(num < files.length - 1) {
            num++;
            step.call(this);
          }
          else {
            // this.viewFiles(result);
            clearInputFile(e.target);
            this.$emit('processing', false);
          }
        })
      }
      step.call(this);
      // Promise.all(promises).then(values => {
      //   this.viewFiles(values);
      //   clearInputFile(e.target);
      // });
    },
    getKey: function (key, metatags) {
      let result = null;
      for (let value in metatags) {
        let ticker = metatags[value];
        for (let field in ticker) {
          if(key.toLowerCase() == field.toLowerCase()) {
             result = ticker[field];
             break;
          }
        }
        if(result) break;
      }
      return result;
    },
    getMediaInfo: function(file) {
      return new Promise((resolve, reject)=> {
        mediainfo.parseFile(file).then(data => {
          let info = data.File.track;
          let metatags = {
            artist:         this.getKey('Performer', info),
            title:          this.getKey('Track_name', info) || this.getKey('Movie_name', info),
            genre:          this.getKey('Genre', info),
            year:           this.getKey('Recorded_date', info) || this.getKey('Encoded_date', info),
            subgenre:       this.getKey('Grouping', info),
            bpm:            this.getKey('BPM', info),
            key:            this.getKey('Initial_key', info) || this.getKey('initialkey', info),
            comment:        this.getKey('Comment', info),
            remixer:        this.getKey('Composer', info)
          };
          file.metatags = Object.assign(file.metatags, metatags);
          resolve(file);
        }, reason => {
          console.error(reason)
          reject(file);
        })
      })
    },
    checkExisting(file) {
      // get remix for attachment to new track before upload to server 
      return new Promise((resolve, reject) => {
        if(this.preparedFiles && _.find(this.preparedFiles, { artist: file.metatags.artist, title: file.metatags.title })){
          console.warn('File was add to upload');
          return resolve(null);
        }
        if(!file) return reject(null);
        let filterParams = {
          artist: file.metatags.artist,
          title: file.metatags.title
        };
        let ui = new Date().getTime() + Math.floor(Math.random() * 9999);
        TrackService.getTracks({
          search: {
            query: filterParams
          },
          ui: ui
        }).then(responce => {
          let isExist = !!responce.tracks.length;
          file.isExist = isExist;
          if(isExist) {
            resolve(file)
          }
          else {
            reject(file);
          }
        })
      })
    },
    getMetatags: function(file) {
      return new Promise((resolve, reject) => {
        window.jsmediatags.read(file, {
          onSuccess: (data) => {
            file.metatags = data.tags;
            if(data.tags.artist && data.tags.title) {
              resolve(file);
            }
            else {
              reject(file);
            }
          },
          onError: (reason) => {
            console.log('jsmetatags error: ',reason)
            reject(file);
          }
        })
      })
    },
    getInfo: function(file) {
      return new Promise((resolve, reject) => {
        this.getMetatags(file)
            .then(data => {
              return this.checkExisting(data).then(data => {
                return Promise.reject(data);
              }, data => {
                return Promise.resolve(this.getMediaInfo(data))
              })
            }, data => {
              return this.getMediaInfo(data).then(data => {
                return this.checkExisting(data).then(data => {
                  return data;
                }, data => {
                  return data;
                })
              }, data => {
                return data;
              })
            })
            .then(data => {
              resolve(data);
            })
            .catch(data => {
              resolve(data)
            })
      })
    }
  }
})