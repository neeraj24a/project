'use strict';
import _ from 'lodash/core';
import * as axios from 'axios';
import {BASE_URL} from '../../config';


const getEditSchema = () => {
  return new Promise((resolve, reject) => {
    let schema = {
      name: null,
      artist: null,
      title: null,
      genre: null,
      subgenre: null,
      bpm: null,
      key: null,
      comment: null,
      type: null,
      year: null,
      isRadio: false,
      remixer: '',
      remix: []
    }
    resolve(schema)
  })
}
const getViewSchema = () => {
  return new Promise((resolve, reject) => {
    let schema = {
      // name: null,
      artist: null,
      title: null,
      genre: null,
      subgenre: null,
      bpm: null,
      key: null,
      comment: null,
      type: null,
      year: null,
      isRadio: 0,
      remixer: '',
      remix: []
    }
    resolve(schema)
  })
}

const trackSchema = (updateNeeded) => {
  const url = `${BASE_URL}/get-model/track`;
  return axios.get(url).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      message: 'Tracks model not found',
      erorr: error
    })
  });
}
const getTrack = function(params) {
  const url = `${BASE_URL}/admin/track/${params.id}`;
  console.log(url);
  return new Promise((resolve, reject) => {
    axios.get(url, {
      params: Object.assign({ json: true }, params)
    }).then(response => {
      // get body data
      // setTimeout(() => {
        resolve(response.data)
      // }, 1000)
      return response.data;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}
const getTracks = function(params) {
  const url = `${BASE_URL}/search/autocomplete`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.get(url, params, function(data) {
        resolve(data);
      });
    }
    axios.get(url, {
      params: Object.assign({ json: true }, params)
    }).then(response => {
      // get body data
      resolve(response.data.tracks);
      return response.data.tracks;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}
const removeTrack = (params) => {
  const url = `${BASE_URL}/admin/track/destroy`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.delete(`${BASE_URL}/admin/track/destroy/${params.id}`, { _csrf: params.csrf }, function (data){
        resolve();
      });
    }
    else {
      axios.delete(`${BASE_URL}/admin/track/destroy/${params.id}`, { _csrf: params.csrf }).then((data) => {
        resolve();
      });
    }
  })
}
const upload = ({formData, onProgress}) => {
    const url = `${BASE_URL}/admin/file/upload`;
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        url: url,
        onUploadProgress: (e) => {
          if(onProgress) onProgress((e.loaded / e.total * 100).toFixed(2))
        },
        data: formData
      })
        // get data
        .then(x => x.data)
        // add url field
        .then(x => {
          let data = x.map(file => Object.assign({}, file, {}))
          resolve(data)
        });
    });
}
const s3upload = ({formData, onProgress}) => {
    const url = `${BASE_URL}/admin/file/s3upload`;
    return new Promise((resolve, reject) => {
      axios.post(url, formData, {
        onUploadProgress: (e) => {
          if(onProgress) onProgress((e.loaded / e.total * 100).toFixed(2))
        }
      })
        // get data
        .then(responce => {
          return responce.data;
        })
        // add url field
        .then(responce => {
          let data = responce.map(file => Object.assign({}, file, {}))
          resolve(data)
        });
    });
}
const s3uploadMulti = ({formData, onProgress}) => {
    const url = `${BASE_URL}/admin/file/s3upload-multi`;
    return new Promise((resolve, reject) => {
      axios.post(url, formData, {
        onUploadProgress: (e) => {
          if(onProgress) onProgress((e.loaded / e.total * 100).toFixed(2))
        }
      })
        // get data
        .then(responce => {
          return responce.data;
        })
        // add url field
        .then(responce => {
          let data = responce.map(file => Object.assign({}, file, {}))
          resolve(data)
        });
    });
}
const save = (params) => {
  const url = `${BASE_URL}/admin/track/create`;
  params = Object.assign(params, { json: true });
  return axios.post(url, params)
      // get data
      .then(x => {
        return x.data;
      }, err => {
        console.log(err)
      })
        // // add url field
        // .then(x => x.map(file => Object.assign({},
        //     file, {})));
}
const update = (params) => {
  // /admin/track/update/:id
  const url = `${BASE_URL}/admin/track/update/${params.id}`;
  params = Object.assign(params, { json: true });
  return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.post(url, params, function(data) {
        resolve(data);
      });
    }
    axios.post(url, params)
    // get data
    .then(x => {
      resolve(x.data)
      return x.data;
    }, err => {
      reject(err)
    })
  })
}
const getMetadata = ({formData, params}) => {
  const url = `${BASE_URL}/metadata`;
  return new Promise((resolve, reject) => {
    axios.post(url, {
      params: {},
      data: formData
    }).then(response => {
      // get body data
      // setTimeout(() => {
        resolve(response.data)
      // }, 1000)
      return response.data;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}
const searchAllRemixes = () => {
  const url = `${BASE_URL}/search-all-remixes`;
  return new Promise((resolve, reject) => {
    axios.get(url, {
      params: {}
    }).then(response => {
      return resolve(response.data);
    }, error => {
      return reject(new Error({
        message: erorr.message,
        erorr: erorr
      }))
    });
  })
}

export { 
  getViewSchema,
  trackSchema,
  getTrack,
  getTracks,
  removeTrack,
  searchAllRemixes,
  upload,
  s3upload,
  getMetadata,
  save,
  update
}