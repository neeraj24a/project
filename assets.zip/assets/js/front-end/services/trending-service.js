'use strict';
import axios from 'axios';
import {BASE_URL} from '../../config';

const getDayTrendings = function(params) {
  const url = `${BASE_URL}/day-trending/${params.type}`;
  return axios.get(url).then(response => {
    // get body data
    return response.data;
  }, error => {
    // error callback
    console.log(error);
    return new Error({
      message: 'Filters not found',
      error: error
    })
  });
}
const getWeekTrendings = (params) => {
    const url = `${BASE_URL}/week-trending/${params.type}`;
	return axios.get(url).then(response => {
		// get body data
		return response.data;
	}, error => {
		// error callback
		console.log(error);
		return new Error({
		  message: 'Filters not found',
		  error: error
		})
	});
}

const getMonthTrendings = (params) => {
    const url = `${BASE_URL}/month-trending/${params.type}`;
	return axios.get(url).then(response => {
		// get body data
		return response.data;
	}, error => {
		// error callback
		console.log(error);
		return new Error({
		  message: 'Filters not found',
		  error: error
		})
	});
}

const checkDownloadCount = ({id, csrf}) => {
  const url = `${BASE_URL}/check-download-track`;
  return new Promise((resolve, reject) => {
    axios.get(`${url}/${id}`, { _csrf: csrf || '' }).then(response =>{
      resolve(response.data);
    }).catch(error => {
      console.log(error);
    });
  })
}
const markedAllAsDownloaded = () => {
  const url = `${BASE_URL}/marked-as-downloaded`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.get(url, {}, responce => {
        resolve(responce);
      });
    }
    else {
      axios.get(url, { }).then(data => {
        resolve();
      });
    }
  })
}

export { 
  getDayTrendings,
  getWeekTrendings,
  getMonthTrendings,
  checkDownloadCount,
  markedAllAsDownloaded
}