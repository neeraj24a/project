import _ from 'lodash/core';
import {BASE_URL} from '../config';
import Vue from 'vue';
import moment from 'moment';
import './components/dropbox-saver';

import 'bootstrap-vue/dist/bootstrap-vue.css'
import BootstrapVue from 'bootstrap-vue';

import * as CoreService from './services/core-service';
import * as TrackService from './services/track-service';

Vue.config.errorHandler = function (err, vm, info) {
	console.log(err)
	console.log(vm)
	console.log(info)
}
Vue.use(BootstrapVue);


let app = new Vue({
	el: '#cart',
	data: {
    gettingArchive: false,
    loadingCart: true,
    saving: false,
    cartTracks: [],
		moment
	},
  beforeCreate() {
    this.loadingCart = true;
  },
	mounted () {
		CoreService.getCart().then(data => {
      this.cartTracks = data.cart;
      this.loadingCart = false;
    }, reason => {
      this.loadingCart = false;
    })
    CoreService.getUserInfo().then(data => {
      this.user = data;
      if(io.socket && this.user && this.user.id) {
        io.socket.on('cart-update.' + this.user.id, function(data) {
          if(data.cart) this.cartTracks = data.cart;
          this.gettingArchive = false;
        }.bind(this))
      }
    })
    this.$on('onsaving', function() {
      this.saving = true;
    })
    this.$on('onsuccess', function() {
      this.markedAllAsDownloaded();
    })
	},
  methods: {
    removeTrack(track) {
      CoreService.removeFromCart({trackId: track.id}).then(data => {
        this.cartTracks = data.cart;
      });
    },
    getZip() {
      CoreService.getZip().then(data => {
        console.log(data)
      });
    },
    markedAllAsDownloaded() {
      console.log('marking');
      TrackService.markedAllAsDownloaded().then(data => {
        console.log('marked');
        console.log(data)
      })
      this.saving = false;
    }
  }
})