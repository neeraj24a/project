/**
 * FileController
 *
 * @description :: Server-side logic for managing files
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

let fs = require('fs');
let path = require('path');
let archiver = require('archiver');
let rimraf = require('rimraf');
let request = require('request');
var jsmediatags = require("jsmediatags");
let moment = require('moment');

let markDownloadedTracks = ({tracks, userId}) => {
  tracks.forEach(item => {
    console.log('marked', item.id)
    Track.findOne(item.id).exec((err, track) => {
      let uploads = track.uploads;
      uploads[userId] = (uploads[userId] || 0) + 1;
      let newPopularity = track.popularity + 1;
      let newDay = track.day + 1;
      let newWeek = track.week + 1;
      let newMonth = track.month + 1;
      let updatedAt = moment().format("YYYY-MM-DD HH:mm:ss");
      Stream.create({ track: track.id, type: true ,user: userId }, (err, track) => {
        if(err) {
          return res.serverError(err);
        }
        sails.sockets.blast('download stream added.');
      })
      Track.update(track.id, { popularity: newPopularity, day: newDay, week: newWeek, month: newMonth, uploads: uploads, updatedAt: updatedAt }).exec((err, tr) => {
        sails.sockets.blast('downloaded.' + userId, {
          track: tr
        });
        sails.sockets.blast('cart-update.' + userId, {
          type: 'remove', id: tr[0].id, cart: []
        });
      })
    })
  })
}

let download = (req, res) => {
  let userId = req.session.user.id;
  console.log('Try download track', req.param('id'))
  if(req.session.user.isLocked) {
    return res.serverError(req.session.user.isLocked.msg);
  }
  Track.findOne(req.param('id')).exec((err, track) => {
    if(err || !track) {
      return res.serverError({ msg: 'Track not found!' });
    }
    sails.log('Track uploads: ', track.uploads[userId] || [])
    if(track.uploads[userId] && track.uploads[userId] >= 3 && !req.session.user.admin) {
      sails.sockets.blast('error.' + userId, { error: 'You took maximum attempts to download' });
      return res.serverError('You took maximum attempts to download.');
    }
    /*res.set({
      'Content-Disposition': `attachment; filename="${track.name}"`
    })*/
    res.attachment(track.name);
    sails.session.redirectdownload = null;
    request(track.url).pipe(res).on('finish', function() {
      let uploads = track.uploads;
      uploads[userId] = (uploads[userId] || 0) + 1;
      let newPopularity = track.popularity + 1;
      let newDay = track.day + 1;
      let newWeek = track.week + 1;
      let newMonth = track.month + 1;
      let updatedAt = moment().format("YYYY-MM-DD HH:mm:ss");
      Stream.create({ track: track.id, type: true ,user: userId }, (err, track) => {
        if(err) {
          return res.serverError(err);
        }
        sails.sockets.blast('download stream added.');
      })
      Track.update(track.id, { popularity: newPopularity, day: newDay, week: newWeek, month: newMonth, uploads: uploads, updatedAt: updatedAt }).exec((err, tr) => {
        if(err) return res.serverError(err);
        sails.sockets.blast('downloaded.' + userId, { track: tr });
      })
    })
  })
}

module.exports = {
  getMetaData: (req, res) => {
    console.log('get metadata')
    let result = null;
    let url = require('path').resolve(sails.config.appPath, '.tmp') + '/test2.mp4';
    new jsmediatags.Reader(url)
      .setTagsToRead(["title", "artist", "bpm", "key"])
      .read({
        onSuccess: function(tag) {
          console.log(tag);
          res.json(tag)
        },
        onError: function(error) {
          console.log(':(', error.type, error.info);
        }
      });
    
  },
  checkDownloadCount: function(req, res, next) {
    sails.log('Check track', req.param('id'));
    if(!req.param('id')) {
      return res.badRequest();
    }
    if(req.session.user && req.session.user.uploads) {
      res.json(req.session.user.uploads[req.param('id')])
    }
    else {
      res.ok();
    }
  },
  downloadTrack: function(req, res) {
    sails.log('Get gile', req.params.all())
    if(!req.param('id')) {
      return res.serverError('This id: ' + req.param('id') + ' is not defined')
    }
    download(req, res);
  },
  upload: function (req, res) {
    // e.g.
    // 0 => infinite
    // 240000 => 4 minutes (240,000 miliseconds)
    // etc.
    //
    // Node defaults to 2 minutes.
    
    res.setTimeout(0);
    req
      .file('track')
      .upload({
        // You can apply a file upload limit (in bytes)
        dirname: require('path').resolve(sails.config.appPath, '.tmp'),
        maxBytes: 1024*1024*1000
      }, function whenDone(err, uploadedFiles) {
        if (err) return res.serverError(err);
        let promises = [];
        _.each(uploadedFiles, function(file, index) {
          promises.push(new Promise((resolve, reject) => {
            var filename = file.fd.substring(file.fd.lastIndexOf('/')+1);
            var tmpLocation = require('util').format('/.tmp/%s', filename);
            file.url = tmpLocation;
            delete file.fd;
            resolve();
          }))
        })
        Promise.all(promises).then(function() {
          res.json(uploadedFiles)
        }, function(err) {
          res.serverError(err);
        })
      });
  },
  /**
   * `FileController.s3upload()`
   *
   * Upload file(s) to an S3 bucket.
   *
   * NOTE:
   * If this is a really big file, you'll want to change
   * the TCP connection timeout.  This is demonstrated as the
   * first line of the action below.
   */
  s3upload: function (req, res) {
    // e.g.
    // 0 => infinite
    // 240000 => 4 minutes (240,000 miliseconds)
    // etc.
    //
    // Node defaults to 2 minutes.
    res.setTimeout(0);
    let options = {
      // adapter: require('skipper-s3'),
      adapter: require('skipper-better-s3'),
      bucket: sails.config.s3upload.bucket,
      key: sails.config.s3upload.key,
      secret: sails.config.s3upload.secret,
      onProgress: progress => {
        sails.log('Upload progress:', progress)
      }
    };
    req.file('track').upload(options, function whenDone(err, uploadedFiles) {
      if (err) return res.serverError(err);
      let promises = [];
      _.each(uploadedFiles, function(file, index) {
        promises.push(new Promise((resolve, reject) => {
          file.url = file.extra.Location;
          delete file.fd;
          resolve();
        }))
      })
      Promise.all(promises).then(function() {
        res.json(uploadedFiles)
      }, function(err) {
        res.serverError(err);
      })
    });
  },
  s3uploadMulti: function (req, res) {
    // e.g.
    // 0 => infinite
    // 240000 => 4 minutes (240,000 miliseconds)
    // etc.
    //
    // Node defaults to 2 minutes.
    res.setTimeout(0);
    let options = {
      // adapter: require('skipper-s3'),
      adapter: require('skipper-better-s3'),
      bucket: sails.config.s3upload.bucket,
      key: sails.config.s3upload.key,
      secret: sails.config.s3upload.secret,
      onProgress: progress => {
        sails.log('Upload progress:', progress)
      }
    };
    req.file('track').upload(options, function whenDone(err, uploadedFiles) {
      if (err) return res.serverError(err);
      let promises = [];
      _.each(uploadedFiles, function(file, index) {
        promises.push(new Promise((resolve, reject) => {
          file.url = file.extra.Location;
          delete file.fd;
          resolve();
        }))
      })
      Promise.all(promises).then(function() {
        res.json(uploadedFiles)
      }, function(err) {
        res.serverError(err);
      })
    });
  },
  /**
   * FileController.attachZip()
   *
   * Download a zip.
   */
  attachZip: (req, res) => {
    let userId = req.session.user.id;
    let zipName = new Date().getTime() + Math.floor(Math.random() * 99999) + '.zip';
    let downloadedName = 'tracks-' + sails.moment().format('DD-MMMM-YYYY') + '.zip';
    let startTime = new Date().getTime();
    // create a file to stream archive data to.
    let output = fs.createWriteStream(require('path').resolve(sails.config.appPath, '.tmp') + '/' + zipName);
    let archive = archiver('zip', {
        store: true // Sets the compression level.
    });
    // catch this error explicitly
    archive.on('error', function(err) {
      res.serverError(err);
    });
    // pipe archive data to the file
    archive.pipe(output);
    // append a file from string
    
    if(req.session.user.cart) {
      _.each(req.session.user.cart, function(item) {
        let url = item.url.indexOf('amazon') != -1 ? item.url : (req.baseUrl + item.url);
        archive.append(request.get( url ), { name: item.name });
        sails.log('Track append to zip, ', item.name, ' track url', url);
      })
    }
    // finalize the archive (ie we are done appending files but streams have to finish yet)
    archive.finalize();

    // listen for all archive data to be written

    output.on('close', function() {
      sails.log(archive.pointer() + ' total bytes');
      sails.log('archiver has been finalized and the output file descriptor has closed.');
      if(req.session.user.cart) {
        sails.log('Zip created time: ', (new Date().getTime() - startTime) / 1000, 's')
        /* Main version */
        res.download(require('path').resolve(sails.config.appPath, '.tmp') + '/' + zipName, downloadedName, function() {
          sails.log('Download finished');
          rimraf(require('path').resolve(sails.config.appPath, '.tmp') + '/' + zipName, function() {
            sails.log('Tmp zip removed');
          });
          markDownloadedTracks({ tracks: req.session.user.cart, userId: userId});
          req.session.user.cart = null;
        });
        sails.sockets.blast('cart-update.' + userId, { type: 'clear', cart: [] });
      }
      else {
        res.badRequest('Your cart is empty');
      }
    });
  },

  /**
   * FileController.markedAsDownloaded()
   *
   * Marked downloaded files
   */
  markedAsDownloaded: (req, res) =>{
    if(!req.session.user || !req.session.user.id) {
      return res.redirect('login');
    }
    let userId = req.session.user.id;
    markDownloadedTracks({ tracks: req.session.user.cart, userId: userId });
    req.session.user.cart = [];
    sails.sockets.blast('cart-update.' + userId, { type: 'clear', cart: [] });
    res.json({ cart: req.session.user.cart })
  }
};
