let request = require('request');
module.exports = {
  check: (user) => {
    return new Promise((resolve, reject) => {
        let options = {
          url: `${sails.config.aMember.url}/api/check-access/by-login?_key=${sails.config.aMember.apiKey}&login=${user.login}`
        };
        if(user.admin) {
          return resolve({
            message: true
          })
        }
        let callback = (error, response, body) => {
          if(!error && response.statusCode) {
            let info = JSON.parse(body);
            //let expDate = info.subscriptions[sails.config.aMember.product_id || -1];
            let expDate = -1;
            _.each(info.subscriptions, function(s, k){
                expDate = s;
            });
            
            if(expDate) {
              let isExist = new Date(`${expDate}`) > new Date().getTime();
              if(isExist) {
                resolve({
                  message: true
                });
              }
              else {
                reject({
                  error: sails.__('expire_subscripion')
                })
              }
            }
            else {
              reject({
                error: sails.__('no_subscription')
              });
            }
          }
          else {
            reject(error);
          }
        }
        request(options, callback);
    })
  }
}
