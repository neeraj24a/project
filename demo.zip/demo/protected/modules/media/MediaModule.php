<?php

class MediaModule extends CWebModule
{
	public $dashboardUrl = array("/media/dashboard");
	
	public function init()
	{
		// this method is called when the module is being created
		// you may place code here to customize the module or the application

		// import the module-level models and components
		$this->setImport(array(
			'media.models.*',
			'media.components.*',
		));
	}
	
	/**
	 * @param $str
	 * @param $params
	 * @param $dic
	 * @return string
	 */
	public static function t($str='',$params=array(),$dic='user') {
		if (Yii::t("MediaModule", $str)==$str)
		    return Yii::t("MediaModule.".$dic, $str, $params);
        else
            return Yii::t("MediaModule", $str, $params);
	}
}