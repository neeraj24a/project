<?php

class DashboardController extends Controller
{
	public $layout='//layouts/column2';
	/**
	 * Lists all models.
	 */
	public $defaultAction='index';
	
	protected function beforeAction($action){
		if(Yii::app()->user->isGuest){
			$this->redirect(Yii::app()->getModule('user')->loginUrl);
		} else {
			return true;
		}
	}
	
	
	public function actionIndex()
	{
		$this->render('dashboard');
	}

}