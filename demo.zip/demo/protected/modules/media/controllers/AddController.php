<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AddController
 *
 * @author neeraj
 */
class AddController extends Controller {

    public $layout = '//layouts/column2';

    /**
     * Lists all models.
     */
    public $defaultAction = 'index';

    protected function beforeAction($action) {
        if (Yii::app()->user->isGuest) {
            $this->redirect(Yii::app()->getModule('user')->loginUrl);
        } else {
            return true;
        }
    }

    public function actionIndex() {
        $this->render('dashboard/add');
    }

}
