<?php

class DefaultController extends Controller
{
	
	/**
	 * Lists all models.
	 */
	
	public function actionIndex()
	{
		$this->redirect(array("/media/dashboard"));
	}

}