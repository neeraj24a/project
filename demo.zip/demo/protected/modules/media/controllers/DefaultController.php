<?php

class DefaultController extends Controller {

    public $layout = '//layouts/column2';

    /**
     * Lists all models.
     */
    public $defaultAction = 'dashboard';

    protected function beforeAction($action) {
        if (Yii::app()->user->isGuest) {
            $this->redirect(Yii::app()->getModule('user')->loginUrl);
        } else {
            return true;
        }
    }

    public function actionDashboard() {
        $this->render('dashboard');
    }
    
    public function actionAdd() {
        $this->render('add');
    }
    
    public function actionUpload(){
//        die("here");
        $mode = 'authenticated-read';
        //$user_id = Yii::app()->user->id;
        //$bucket = "allvideotoolz";
	$bucket = "lokals-demo";
        $key_path = '';
	$data = '';
	$upload_handler = new UploadHandlerS3(null, true, null, $bucket, $mode,$key_path,$data);
    }

}
