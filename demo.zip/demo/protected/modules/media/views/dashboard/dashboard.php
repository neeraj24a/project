<?php $this->pageTitle=Yii::app()->name . ' - '.MediaModule::t("Dashboard");
$this->breadcrumbs=array(
	MediaModule::t("Dashboard"),
);
$this->menu=array(
    array('label'=>MediaModule::t('Add Media'), 'url'=>array('/media/add')),
    array('label'=>MediaModule::t('List All Media'), 'url'=>array('/media/list')),
);
?><h1><?php echo MediaModule::t('Dashboard'); ?></h1>