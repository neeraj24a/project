<?php

/*
 * Main Config Parameters
 */
$params = array(
    'adminEmail' => 'neeraj@dealrush.in',
    'upload_path' => '../assets/',
    'defaultPageSize' => 10,
    'access_key_id' => 'AKIAIOSXAMJOWZ4RQWSQ',
    'secret_access_key' => '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',
    'bucket' => 'lokals-demo'
);
?>
