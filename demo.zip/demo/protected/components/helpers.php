<?php
ob_start();
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Description of Helpers
 *
 * @author core
 */
function base_url() {
    return Yii::app()->baseUrl;
}
function create_guid() {
    $microTime = microtime();
    list($a_dec, $a_sec) = explode(" ", $microTime);
    $dec_hex = dechex($a_dec * 1000000);
    $sec_hex = dechex($a_sec);
    ensure_length($dec_hex, 5);
    ensure_length($sec_hex, 6);
    $guid = "";
    $guid .= $dec_hex;
    $guid .= create_guid_section(3);
    $guid .= '-';
    $guid .= create_guid_section(4);
    $guid .= '-';
    $guid .= create_guid_section(4);
    $guid .= '-';
    $guid .= create_guid_section(4);
    $guid .= '-';
    $guid .= $sec_hex;
    $guid .= create_guid_section(6);
    return $guid;
}
function ensure_length(&$string, $length) {
    $strlen = strlen($string);
    if ($strlen < $length) {
        $string = str_pad($string, $length, "0");
    } else if ($strlen > $length) {
        $string = substr($string, 0, $length);
    }
}
function create_guid_section($characters) {
    $return = "";
    for ($i = 0; $i < $characters; $i++) {
        $return .= dechex(mt_rand(0, 15));
    }
    return $return;
}
function current_user_id() {
    return Yii::app()->user->id;
}
function current_username() {
    return Yii::app()->user->name;
}
function checkPaymentStatus($id, $table) {
    $sql = "SELECT payment_status FROM $table WHERE id = '$id' LIMIT 1";
    $result = BaseModel::executeQuery($sql);
    return $result[0]['payment_status'];
}
function uploadGalleryImage($images, $path) {
    $base_path = Yii::app()->params['upload_path'];
    for ($i = 1; $i < sizeof($images) + 1; $i++) {
        $name = $images[$i][0];
        $target_path = $base_path . $path . "/";
        $type = $images[$i][1];
        $tmp_name = $images[$i][2];
        $allowedImageTypes = array("image/jpeg", "image/jpg", "image/png", "image/x-png", "image/gif");
        if (in_array($type, $allowedImageTypes)) {
            $target_path = $target_path . basename($name);
            move_uploaded_file($tmp_name, $target_path) or die("error!");
        }
    }
    return true;
}
function uploadThumb($name, $type, $tmp_name, $path) {
    // Where the file is going to be placed 
    $base_path = Yii::app()->params['upload_path'];
    $target_path = $base_path . $path . "/thumb/";
    $tmp = explode('.', $name);
    $extension = end($tmp);
    $randomName = 'thumbnail-' . rand(123456, 1234567890) . '.' . $extension;
    /* Add the original filename to our target path.  
      Result is "images/uploads/filename.extension" */
    $target_path = $target_path . basename($randomName);
    $allowedImageTypes = array("image/jpeg", "image/jpg", "image/png", "image/x-png", "image/gif");
    if (in_array($type, $allowedImageTypes)) {
        move_uploaded_file($tmp_name, $target_path) or die("error in thumbnail upload!");
    }
//            echo $randomName;
    return $randomName;
}
function uploadImage($name, $type, $tmp_name, $path) {
    // Where the file is going to be placed 
    $base_path = Yii::app()->params['upload_path'];
    $target_path = $base_path . $path . "/";
    $tmp = explode('.', $name);
    $extension = end($tmp);
    $randomName = 'ad-' . rand(123456, 1234567890) . '.' . $extension;
    /* Add the original filename to our target path.  
      Result is "images/uploads/filename.extension" */
    $target_path = $target_path . basename($randomName);
    $allowedImageTypes = array("image/jpeg", "image/jpg", "image/png", "image/x-png", "image/gif");
    if (in_array($type, $allowedImageTypes)) {
        move_uploaded_file($tmp_name, $target_path) or die("error in main image upload!");
    }
    return $randomName;
}

function uploadMultipleSong($file_name, $tmp_name, $path) {
	// Where the file is going to be placed 
    //$base_path = Yii::app()->params['upload_path'];
    //$target_path = $path;
    $target_path = $path . basename($file_name);
    move_uploaded_file($tmp_name, $target_path) or die("error in song upload!");
    return $file_name;
}

function uploadSong($file_name, $name, $tmp_name, $path) {
    // Where the file is going to be placed 
    $target_path = $path . "/";
    $tmp = explode('.', $name);
    $extension = end($tmp);
    $uploaded_file_name = $file_name . "." . $extension;
    /* Add the original filename to our target path.  
      Result is "images/uploads/filename.extension" */
    $target_path = $target_path . basename($uploaded_file_name);
    move_uploaded_file($tmp_name, $target_path) or die("error in song upload!");
    return $uploaded_file_name;
}
function uploadFile($name, $type, $tmp_name, $path) {
    // Where the file is going to be placed 
    $base_path = Yii::app()->params['upload_path'];
    $target_path = $base_path . $path . "/";
    $tmp = explode('.', $name);
    $extension = end($tmp);
    $randomName = rand(123456, 1234567890) . '.' . $extension;
//            echo $target_path;
//            die("here");
    /* Add the original filename to our target path.  
      Result is "images/uploads/filename.extension" */
    $target_path = $target_path . basename($randomName);
    $allowedImageTypes = array("application/octet-stream",
        "text/plain", "image/jpeg",
        "image/jpg", "image/png",
        "image/x-png", "image/gif",
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/zip",
        "video/quicktime",
        "video/mpeg",
        "video/flv",
        "video/avi");
    if (in_array($type, $allowedImageTypes)) {
        move_uploaded_file($tmp_name, $target_path) or die("error!");
    }
    return $randomName;
}
function getBrowser() {
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version = "";
    //First get the platform?
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    } elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    } elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    }
    // Next get the name of the useragent yes separately and for good reason.
    if (preg_match('/MSIE/i', $u_agent) && !preg_match('/Opera/i', $u_agent)) {
        $bname = 'Internet Explorer';
        $ub = "MSIE";
    } elseif (preg_match('/Firefox/i', $u_agent)) {
        $bname = 'Mozilla Firefox';
        $ub = "Firefox";
    } elseif (preg_match('/Chrome/i', $u_agent)) {
        $bname = 'Google Chrome';
        $ub = "Chrome";
    } elseif (preg_match('/Safari/i', $u_agent)) {
        $bname = 'Apple Safari';
        $ub = "Safari";
    } elseif (preg_match('/Opera/i', $u_agent)) {
        $bname = 'Opera';
        $ub = "Opera";
    } elseif (preg_match('/Netscape/i', $u_agent)) {
        $bname = 'Netscape';
        $ub = "Netscape";
    }
    // Finally get the correct version number.
    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) .
            ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
        // we have no matching number just continue
    }
    // See how many we have.
    $i = count($matches['browser']);
    if ($i != 1) {
        //we will have two since we are not using 'other' argument yet
        //see if version is before or after the name
        if (strripos($u_agent, "Version") < strripos($u_agent, $ub)) {
            $version = $matches['version'][0];
        } else {
            $version = $matches['version'][1];
        }
    } else {
        $version = $matches['version'][0];
    }
    // Check if we have a number.
    if ($version == null || $version == "") {
        $version = "?";
    }
    return array(
        'userAgent' => $u_agent,
        'name' => $bname,
        'version' => $version,
        'platform' => $platform,
        'pattern' => $pattern
    );
}
function pre($val, $exit = false) {
    echo '<pre>';
    print_r($val);
    if ($exit)
        exit();
}
/**
 * 
 * @param array $to
 * @param array $from
 */
function send_email($to, $subject, $body_html, $from = '') {
//    die("here");
    Yii::import('ext.phpmailer.PHPMailer');
    $mail = new PHPMailer;
    $mail->IsSMTP();
    /* $mail->Host = 'smtp.sendgrid.net';
      $mail->SMTPAuth = true;
      $mail->Username = 'info@corelynx.com';
      $mail->Password = 'g00dLuck$4$'; */
    $mail->Host = 'smtp.1and1.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'tester@corelynx.com';
    $mail->Password = 'Gr@$$h0pper$';
    if ($from != '') {
        $mail->SetFrom($from['email'], $from['name']);
    } else {
        $mail->SetFrom('tester@corelynx.com', 'Corelynx Tester');
    }
    $mail->Subject = $subject;
    $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!';
    $mail->MsgHTML($body_html);
    foreach ($to as $email) {
        $mail->AddAddress($email['email'], $email['name']);
    }
    $mail->Send();
    $msg = 'Mail Sent Successfully';
    return $msg;
}
function examplesMenu() {
    Yii::import("application.modules.stores.models.Stores", true);
    Yii::import("application.modules.examples.models.Examples", true);
    $store_limit = Yii::app()->params['store_example_limit'];
    $example_limit = Yii::app()->params['before_after_limit'];
    $stores_examples = Stores::model()->findAll(
            array('limit' => "$store_limit", 'order' => "sequence", "condition" => "publish = 1 AND store_type='example' AND deleted = 0 "));
    $examples = Examples::model()->findAll(
            array("condition" => "publish = 1 AND status = 1 AND deleted = 0 LIMIT $example_limit"));
    return array('stores' => $stores_examples, 'examples' => $examples);
}
function fixturesMenu() {
    Yii::import("application.modules.categories.models.*", true);
    return $data = Categories::model()->findAll();
}
function cmsPageInMenu($page) {
    Yii::import("application.modules.webcontents.models.*", true);
    $data = Webcontents::model()->getCmsPageData($page);
    return $data[0];
}
function logged_in_user_id() {
//    return array('id' => Yii::app()->user->id,'name' => Yii::app()->user->name);
    return Yii::app()->user->id;
}
function generateRandomString($length = 10) {
    $characters = '0123456789!@#$%&()abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
function accessoriesMenu() {
    Yii::import("application.modules.products.models.*", true);
    //return ProductGallery::model()->findAll();
    return Products::model()->getAllAccessories();
}
function slugCreator($str) {
    $slug = preg_replace('@[\s!:;_\?=\\\+\*/%&#]+@', '-', $str);
    //this will replace all non alphanumeric char with '-'
    $slug = mb_strtolower($slug);
    //convert string to lowercase
    $slug = trim($slug, '-');
    return $slug;
}
?>
