/**
 * AdminController
 *
 * @description :: Server-side logic for managing Admins
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
  index: function(req, res) {
    res.view('admin/panel', {
      user: req.session.user
    })
  },
	settingsSave: (req, res) => {
    console.log('params: ', req.params.all())
    if(sails.session.settings) {
      Cms.update(sails.session.settings.id, req.params.all(), (err, data) => {
        sails.log('Updated cms: ', data)
        sails.session.settings = data[0];
        sails.sockets.blast('settings-updated', sails.session.settings);
        res.redirect('/admin');
      })
    }
  }
};