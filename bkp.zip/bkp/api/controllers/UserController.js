/**
 * UserController
 *
 * @description :: Server-side logic for managing users
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */
let request = require('request');
let qs = require('querystring')
let loginRequest = (login, pass) => {
  return new Promise((resolve, reject) => {
    let url = `${sails.config.aMember.url}/api/check-access/by-login-pass`;
    let username = login;
    let options = {
      url: 'http://localhost:1338/userlogin' + '?' + qs.stringify({_key: sails.config.aMember.apiKey,login: username,pass:pass}),
    };
    let callback = (error, response, body) => {
      console.log("error");
      console.log(error);
      if(!error && response.statusCode) {
        let info = JSON.parse(body);
        if(info.error || !info.ok) {
          reject({error: info});
        }
        else {
          getInfo({ email: info.email, id: info.user_id }).then(data => {
            resolve(data);
          })
          // resolve(info);
        }
      }
      else {
        reject({error: error});
      }
    }
    request.get(options, callback);
  })
}
let getFullInfo =({id}) => {
  return new Promise((resolve, reject) => {
    if(id) {
      /* 
        For example:
        http://example.com/amember/api/users/user_id?_key=APIKEY
      */
      let options = {
        url: 'http://localhost:1338/dlogin'
      };
      let callback = (error, response, body) => {
        if(!error && response.statusCode) {
          let info = JSON.parse(body);
          if(info.error) {
            reject({ error: info });
          }
          else {
            resolve(info[0])
          }
        }
        else {
          reject({ error: error })
        }
      }
      request(options, callback);
      return;
    }
    else {
      reject({ error: `This id: ${id} - not found` })
    }
  })
}
let getSimpleInfo = ({email, id}) => {
  return new Promise((resolve, reject) => {
    if(email) {
      /* 
        For example:
        http://example.com/amember/api/check-access/by-email?_key=APIKEY&email=test@example.com
      */
      let options = {
        url: 'http://localhost:1338/vlogin'
      };
      let callback = (error, response, body) => {
        if(!error && response.statusCode) {
          let info = JSON.parse(body);
          if(info.error) {
            reject({ error: info });
          }
          else {
            resolve(info)
          }
        }
        else {
          reject({ error: error })
        }
      }
      request(options, callback);
      return;
    }
    else {
      reject({ error: `This email: ${email} - not found` })
    }
  })
}
let getInfo = ({email, id}) => {
  let user = {};
  return new Promise((resolve, reject) => {
    let promises = [getSimpleInfo({email, id}), getFullInfo({email, id})];
    Promise.all(promises).then(function(results) {
      results.forEach(item => {
        user = Object.assign(user, item);
      });
      resolve(user);
    }).catch(err => console.log(err));
  })
}
let checkUser = (user) => {
    let product = -1;
    //user.subscriptions[sails.config.aMember.product_id]
    _.each(user.subscriptions, function(s, k){
        product = k;
    });
  if(!user.admin) {
    if(user.is_locked && parseInt(user.is_locked) < 0){
      sails.log('User ' + user.login + ' locked');
      user.isLocked = {
        msg: sails.__('msg_locked'),
        type: 'locked'
      };
    }
    else if(new Date() > new Date(user.subscriptions[product])){
      sails.log('User ' + user.login + ' expired');
	  user.is_locked = "1";
      user.isLocked = {
        msg: sails.__('msg_expire'),
        type: 'expire'
      };
    }
    else if(user.subscriptions.hasOwnProperty('length') && !user.subscriptions.length) {
      sails.log('User ' + user.login + ' hasn\'t sub')
      user.is_locked = "1";
	  user.isLocked = {
        msg: sails.__('msg_nonesub'),
        type: 'none_sub'
      }
    }
  }
  return user;
}
module.exports = {
  login: function (req, res) {
    // See `api/responses/login.js`
    loginRequest(req.param('name'), req.param('password')).then(data => {
      let user = Object.assign(data, {
        id: data.user_id
      });
      req.session.user = checkUser(user);

      if(req.param('json') || req.isSocket) {
        return res.json(user);
      }
      sails.sockets.blast('login');
      res.redirect(sails.session.redirectdownload ? '/' : (req.param('returnto') || '/'))
    }, reason => {
      req.session.flash = reason;
      if(req.param('json') || req.isSocket) {
        return res.json(reason);
      }
      res.redirect('/login');
    });
  },
  uLogin: function (req, res){
	  let data = {"ok":true,"user_id":1,"name":"Neeraj Kumar","name_f":"Neeraj","name_l":"Kumar","email":"neeraj24a@gmail.com","login":"neeraj24a","subscriptions":{"3":"2019-02-05"},"categories":[],"groups":[],"resources":[]};
	  return res.json(data);
  },
  verifyLogin: function (req, res){
	  let data = {"ok":true,"user_id":1,"name":"Neeraj Kumar","name_f":"Neeraj","name_l":"Kumar","email":"neeraj24a@gmail.com","login":"neeraj24a","subscriptions":{"3":"2019-02-05"},"categories":[],"groups":[],"resources":[]};
	  return res.json(data);
  },
  detailUser: function (req, res){
	  let data = [{"admin":"1","need_session_refresh":"","signup_email_sent":"1","stripe_cc_expires":"0719","stripe_cc_masked":"XXXX2357","stripe_token":"cus_CMSKVsKkMk4YCB","user_id":1,"login":"neeraj24a","pass":null,"remember_key":"54007448a4197e104f1612ccbc04dc3ba7433c11","pass_dattm":"2018-02-05 22:43:58","email":"neeraj24a@gmail.com","name_f":"Neeraj","name_l":"Kumar","street":"","street2":"","city":"","state":"","zip":"","country":"","phone":"","added":"2018-02-05 22:43:58","remote_addr":"45.250.246.104","user_agent":"Mozilla\/5.0 (X11; Linux x86_64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/64.0.3282.140 Safari\/537.36","saved_form_id":null,"status":"1","unsubscribed":"1","lang":null,"i_agree":"0","is_approved":"1","is_locked":"0","disable_lock_until":null,"reseller_id":null,"comment":"","tax_id":null,"last_login":"2018-07-18 04:24:29","last_ip":"136.59.229.216","last_user_agent":"Mozilla\/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/67.0.3396.99 Safari\/537.36","last_session":"6nb692kh1jv804ujfd1cfgqbc1","aff_id":null,"aff_added":null,"is_affiliate":null,"aff_payout_type":null,"aff_custom_redirect":"0"}];
	  return res.json(data);
  },
  logout: function (req, res) {
    //sails.sockets.blast('logout.' + req.session.user.id)
    req.session.user = null;
    if (req.wantsJSON) {
      return res.ok('Logged out successfully!');
    }
    // Otherwise if this is an HTML-wanting browser, do a redirect.
    return res.redirect('/');
  },
  info: function(req, res) {
    if(!req.session.user) {
      if(req.param('json') || req.isSocket) {
        return res.json({error: sails.__('msg_nonelogin')});
      }
      return res.serverError(sails.__('msg_nonelogin'));
    }
    getInfo({ email: req.session.user.email, id: req.session.user.user_id }).then(data => {
      let user = checkUser(Object.assign(data, {
        id: data.user_id
      }));
      if(req.param('json') || req.isSocket) {
        res.json(user)
      }
      else {
        res.view('admin/user/show', {
          user: user
        })
      }
    }, reason => {
      req.session.flash = reason;
      if(req.param('json') || req.isSocket) {
        return res.json(reason);
      }
      res.redirect('/login');
    })
  }
};
