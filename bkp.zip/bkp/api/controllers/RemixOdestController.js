/**
 * trackController
 *
 * @description :: Server-side logic for managing tracks
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

let moment = require('moment');
var pager = require('sails-pager');
var slugify = require('slugify');
var Promise = require('bluebird');
var os = require('os');
os.tmpDir = os.tmpdir;

let download = (req, res) => {
  let userId = req.session.user.id;
  console.log('Try download track', req.param('id'))
  if(req.session.user.isLocked) {
	return res.serverError(req.session.user.isLocked.msg);
  }
  UserTrack.findOne(req.param('id')).exec((err, track) => {
	if(err || !track) {
	  return res.serverError({ msg: 'Track not found!' });
	}
	sails.log('Track uploads: ', track.uploads[userId] || [])
	if(track.uploads[userId] && track.uploads[userId] >= 3 && !req.session.user.admin) {
	  sails.sockets.blast('error.' + userId, { error: 'You took maximum attempts to download' });
	  return res.serverError('You took maximum attempts to download.');
	}
	/*res.set({
	  'Content-Disposition': `attachment; filename="${track.name}"`
	})*/
	res.attachment(track.name);
	sails.session.redirectdownload = null;
	request(track.url).pipe(res).on('finish', function() {
	  let uploads = track.uploads;
	  uploads[userId] = (uploads[userId] || 0) + 1;
	  let newDownloaded = track.downloaded + 1;
	  let updatedAt = moment().format("YYYY-MM-DD HH:mm:ss");
	  Stream.create({ track: track.id, type: true ,user: userId }, (err, track) => {
		if(err) {
		  return res.serverError(err);
		}
		sails.sockets.blast('download stream added.');
	  })
	  UserTrack.update(track.id, { downloaded: newDownloaded, uploads: uploads, updatedAt: updatedAt }).exec((err, tr) => {
		if(err) return res.serverError(err);
		sails.sockets.blast('downloaded.' + userId, { track: tr });
	  })
	})
  })
}
module.exports = {
	addDjRemix: function(req, res){
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : null;
		if(userId === null){
			let responseObj = {'error': true, 'message': 'You have to be logged in.'};
			return res.json(responseObj);
		}
		res.setTimeout(0);
		let options = {
		  // adapter: require('skipper-s3'),
		  adapter: require('skipper-better-s3'),
		  bucket: sails.config.s3upload.bucket,
		  key: sails.config.s3upload.key,
		  secret: sails.config.s3upload.secret,
		  onProgress: progress => {
			sails.log('Upload progress:', progress)
		  }
		};
		req.file('name').upload(options, function whenDone(err, uploadedFiles) {
		  if (err) return res.serverError(err);
		  let promises = [];
		  _.each(uploadedFiles, function(file, index) {
			promises.push(new Promise((resolve, reject) => {
			  file.url = file.extra.Location;
			  delete file.fd;
			  resolve();
			}))
		  })
		  Promise.all(promises).then(function() {
			params.year = moment().year();
			params.type = 'remix';
			params.url = uploadedFiles[0].url; 
			let slug = slugify(params.artist +' '+ params.title, {
                replacement: '-',    // replace spaces with replacement
                remove: /[$*_+~.()'"!\-:@]/g,        // regex to remove characters
                lower: true          // result in lower case
              });
			let title = params.title;
			let artist = params.artist;
			let search = title.replace(/ *\([^)]*\) */g, "") +' '+ artist.replace(/ *\([^)]*\) */g, "");
			let rsearch = artist.replace(/ *\([^)]*\) */g, "") +' '+ title.replace(/ *\([^)]*\) */g, "");
			params.slug = slug;
			params.search = search;
			params.rsearch = rsearch;
			var origifile = req.file('name')._files[0].stream.filename;
			params.name = origifile;
			
			UserTrack.create(params, (err, track) => {
				if(err) {
				  console.log('Remix file upload error');
				  console.log(err);
				  let responseObj = {'error': true,'message': 'Something went wrong please try again.'};
				  return res.json(responseObj);
				}
				console.log('Remix Added Successfully');
				let responseObj = {'error': false,'message': 'File Uploaded Successfuly'};
				return res.json(responseObj);
			});
		  }, function(err) {
			res.serverError(err);
		  })
		});
	},
	update: (req, res) => {
		let params = req.params.all();
		if(!params.id) {
		  if(req.isSocket || params.json) {
			return res.json(data);
		  }
		  else {
			return res.badRequest(`This id (${params.id}) doesn\'t found`)
		  }
		}
		UserTrack.update(params.id, req.params.all()).exec((err, track) =>  {
		  if(req.isSocket || req.param('json')) {
			if(err) {
			  return res.json({
				error: err
			  });
			}
			sails.sockets.blast('track-updated', track[0]);
			return res.json(track);
		  }
		  if(err) {
			return res.badRequest(err);
		  }
		  sails.sockets.blast('track-updated', track[0]);
		  res.redirect('/uploads');
		})
	},
	destroy: (req, res, next) => {
		sails.log.warn('Destroy track ', req.param('id'));
		UserTrack.findOne( req.param('id'), (err, track) => {
		  if(err) return next(err);
		  if(!track) return next('track doesn\'t exist.');
		  Track.destroy(req.param('id'), err => {
			if(err) return next(err);
		  })
		  if(req.isSocket) {
			res.ok();
		  }
		  else res.redirect('/uploads');
		})
	},
	addOdest: function(req, res){
		let params = req.params.all();
		/*let userId = req.session.user ? req.session.user.id : null;
		if(userId === null){
			return res.badRequest(`User not Logged In.`);
		}*/
		res.setTimeout(0);
		let options = {
		  // adapter: require('skipper-s3'),
		  adapter: require('skipper-better-s3'),
		  bucket: sails.config.s3upload.bucket,
		  key: sails.config.s3upload.key,
		  secret: sails.config.s3upload.secret,
		  onProgress: progress => {
			sails.log('Upload progress:', progress)
		  }
		};
		req.file('name').upload(options, function whenDone(err, uploadedFiles) {
		  if (err) return res.serverError(err);
		  let promises = [];
		  _.each(uploadedFiles, function(file, index) {
			promises.push(new Promise((resolve, reject) => {
			  file.url = file.extra.Location;
			  delete file.fd;
			  resolve();
			}))
		  })
		  Promise.all(promises).then(function() {
			params.year = moment().year();
			params.type = 'odest';
			params.url = uploadedFiles[0].url; 
			let slug = slugify(params.artist +' '+ params.title, {
                replacement: '-',    // replace spaces with replacement
                remove: /[$*_+~.()'"!\-:@]/g,        // regex to remove characters
                lower: true          // result in lower case
              });
			let title = params.title;
			let artist = params.artist;
			let search = title.replace(/ *\([^)]*\) */g, "") +' '+ artist.replace(/ *\([^)]*\) */g, "");
			let rsearch = artist.replace(/ *\([^)]*\) */g, "") +' '+ title.replace(/ *\([^)]*\) */g, "");
			params.slug = slug;
			params.search = search;
			params.rsearch = rsearch;
			var origifile = req.file('name')._files[0].stream.filename;
			params.name = origifile;
			
			UserTrack.create(params, (err, track) => {
				if(err) {
				  console.log('Odest file upload error');
				  console.log(err);
				  let responseObj = {'error': true,'message': 'Something went wrong please try again.'};
				  return res.json(responseObj);
				}
				console.log('Odest Added Successfully');
				let responseObj = {'error': false,'message': 'File Uploaded Successfuly'};
				return res.json(responseObj);
			});
		  }, function(err) {
			res.serverError(err);
		  })
		});
	},
	getTest: function(req, res){
		console.log(req.session.user);
		let responseObj = {'message': 'success', 'user': req.session.user};
		return res.json(responseObj);
	},
	getAlltracks: function(req, res){
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : 'guest';
		let userName = req.session.user ? req.session.user.login : '';
		let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
		let where = " uploadedBy = '"+userName+"'";
		let orderBy = 'createdAt';
		let sel = '*';
		let sqlArray = [];
		if(search.query.hasOwnProperty('searchValue')){
			if(search.query.searchValue.indexOf("'") > -1){
				var arr = search.query.searchValue.split("'");
				search.query.searchValue = arr.join("\\'");
			}
			where += " MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE)";
			sel = "*, MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE) AS relevance";
			orderBy = 'relevance';
		}
		let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 20));
		let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
		
		let responseObj = {};
		responseObj['message'] = 'Data retrieved successfully';
		responseObj['tracks'] = [];
		responseObj['data'] = [];
		responseObj['meta'] = {'pageCount': 0, 'nextPage' : true, 'prevPage': true, 'total': 0, 'page': page, 'perPage': limit};
		var generalQueryAsync = Promise.promisify(Track.query);
		generalQueryAsync('SELECT '+sel+' FROM remix_odest_track WHERE'+where+' ORDER BY '+orderBy+' DESC LIMIT '+ ((page  - 1) * limit) +', '+limit+'')
		.then(function(rawResult) {
			if (!rawResult) { return res.notFound(); }
			responseObj.tracks = rawResult;
			responseObj.data = rawResult;
			var totalQuery = Promise.promisify(Track.query);
			totalQuery('SELECT COUNT(*) AS totalRow FROM remix_odest_track WHERE'+where)
			.then(function(rawResult) {
				if (!rawResult) { return res.notFound(); }
				console.log('total');
				console.log(rawResult[0].totalRow);
				let lastPage = Math.ceil(parseInt(rawResult[0].totalRow) / limit);
				responseObj.meta.pageCount = lastPage;
				responseObj.meta.total = rawResult[0].totalRow;
				if(page == 1){
					responseObj.meta.prevPage = false;
					responseObj.meta.nextPage = page + 1;
				} else if(page == lastPage){
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = false;
				} else if (page != 1 && page < lastPage) {
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = page + 1;
				}
				console.log(responseObj.meta);
				return res.json(responseObj);
			}).catch(function (err) { return res.serverError(err); });
		}).catch(function (err) { return res.serverError(err); });
	},
	
	getRemixes: function(req, res) {
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : 'guest';
		let userName = req.session.user ? req.session.user.login : '';
		let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
		let where = " type = 'remix'";
		let orderBy = 'createdAt';
		let sel = '*';
		let sqlArray = [];
		if(search.query.hasOwnProperty('searchValue')){
			if(search.query.searchValue.indexOf("'") > -1){
				var arr = search.query.searchValue.split("'");
				search.query.searchValue = arr.join("\\'");
			}
			where += " MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE)";
			sel = "*, MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE) AS relevance";
			orderBy = 'relevance';
		}
		let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 20));
		let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
		
		let responseObj = {};
		responseObj['message'] = 'Data retrieved successfully';
		responseObj['tracks'] = [];
		responseObj['data'] = [];
		responseObj['meta'] = {'pageCount': 0, 'nextPage' : true, 'prevPage': true, 'total': 0, 'page': page, 'perPage': limit};
		var generalQueryAsync = Promise.promisify(Track.query);
		generalQueryAsync('SELECT '+sel+' FROM remix_odest_track WHERE'+where+' ORDER BY '+orderBy+' DESC LIMIT '+ ((page  - 1) * limit) +', '+limit+'')
		.then(function(rawResult) {
			if (!rawResult) { return res.notFound(); }
			responseObj.tracks = rawResult;
			responseObj.data = rawResult;
			var totalQuery = Promise.promisify(Track.query);
			totalQuery('SELECT COUNT(*) AS totalRow FROM remix_odest_track WHERE'+where)
			.then(function(rawResult) {
				if (!rawResult) { return res.notFound(); }
				console.log('total');
				console.log(rawResult[0].totalRow);
				let lastPage = Math.ceil(parseInt(rawResult[0].totalRow) / limit);
				responseObj.meta.pageCount = lastPage;
				responseObj.meta.total = rawResult[0].totalRow;
				if(page == 1){
					responseObj.meta.prevPage = false;
					responseObj.meta.nextPage = page + 1;
				} else if(page == lastPage){
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = false;
				} else if (page != 1 && page < lastPage) {
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = page + 1;
				}
				console.log(responseObj.meta);
				return res.json(responseObj);
			}).catch(function (err) { return res.serverError(err); });
		}).catch(function (err) { return res.serverError(err); });
	},
	
	getOdest: function(req, res) {
		let params = req.params.all();
		let userId = req.session.user ? req.session.user.id : 'guest';
		let userName = req.session.user ? req.session.user.login : '';
		let search = typeof params.search === 'string' ? JSON.parse(params.search) : params.search;
		let where = " type = 'odest'";
		let orderBy = 'createdAt';
		let sel = '*';
		let sqlArray = [];
		if(search.query.hasOwnProperty('searchValue')){
			if(search.query.searchValue.indexOf("'") > -1){
				var arr = search.query.searchValue.split("'");
				search.query.searchValue = arr.join("\\'");
			}
			where += " MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE)";
			sel = "*, MATCH(artist, title) AGAINST ('+"+search.query.searchValue+"' IN BOOLEAN MODE) AS relevance";
			orderBy = 'relevance';
		}
		let limit = _.get(search, 'pagelimit.limit', _.get(sails.session, 'settings.trackPerPage', 20));
		let page = _.get(search, 'pagelimit.page', _.get(search, 'page', 1));
		
		let responseObj = {};
		responseObj['message'] = 'Data retrieved successfully';
		responseObj['tracks'] = [];
		responseObj['data'] = [];
		responseObj['meta'] = {'pageCount': 0, 'nextPage' : true, 'prevPage': true, 'total': 0, 'page': page, 'perPage': limit};
		var generalQueryAsync = Promise.promisify(Track.query);
		generalQueryAsync('SELECT '+sel+' FROM remix_odest_track WHERE'+where+' ORDER BY '+orderBy+' DESC LIMIT '+ ((page  - 1) * limit) +', '+limit+'')
		.then(function(rawResult) {
			if (!rawResult) { return res.notFound(); }
			responseObj.tracks = rawResult;
			responseObj.data = rawResult;
			var totalQuery = Promise.promisify(Track.query);
			totalQuery('SELECT COUNT(*) AS totalRow FROM remix_odest_track WHERE'+where)
			.then(function(rawResult) {
				if (!rawResult) { return res.notFound(); }
				console.log('total');
				console.log(rawResult[0].totalRow);
				let lastPage = Math.ceil(parseInt(rawResult[0].totalRow) / limit);
				responseObj.meta.pageCount = lastPage;
				responseObj.meta.total = rawResult[0].totalRow;
				if(page == 1){
					responseObj.meta.prevPage = false;
					responseObj.meta.nextPage = page + 1;
				} else if(page == lastPage){
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = false;
				} else if (page != 1 && page < lastPage) {
					responseObj.meta.prevPage = page - 1;
					responseObj.meta.nextPage = page + 1;
				}
				console.log(responseObj.meta);
				return res.json(responseObj);
			}).catch(function (err) { return res.serverError(err); });
		}).catch(function (err) { return res.serverError(err); });
	},
	
	updateStream: function(req, res) {
		let params = req.params.all();
		if(!params.id) {
		  if(req.isSocket || params.json) {
			return res.json(data);
		  }
		  else {
			return res.badRequest(`This id (${params.id}) doesn\'t found`)
		  }
		}
		UserTrack.findOne( {id: params.id}, (err, track) => {
		  if(err) return next(err);
		  if(!track) return next('track doesn\'t exist.');
		  UserTrack.update({id: params.id}).set({played: (track.played + 1)});
		  if(req.isSocket) {
			res.ok();
		  }
		})
	},
	updateLikes: function(req, res) {
		let params = req.params.all();
		if(!params.id) {
		  if(req.isSocket || params.json) {
			return res.json(data);
		  }
		  else {
			return res.badRequest(`This id (${params.id}) doesn\'t found`)
		  }
		}
		let userId = req.session.user.id;
		console.log('Try like track', req.param('id'))
		if(req.session.user.isLocked) {
			return res.serverError(req.session.user.isLocked.msg);
		}
		UserTrack.findOne({id: params.id}, (err, track) => {
			if(err || !track) {
				return res.serverError({ msg: 'Track not found!' });
			}
			let lyks = JSON.parse(track.likes);
			let dislyks = JSON.parse(track.dislikes);
			console.log('Track likes: ', likes[userId] || []);
			//sails.log('Track likes: ', track.likes[userId] || [])
			if(lyks[userId] && lyks[userId] > 0) {
				sails.sockets.blast('error.' + userId, { error: 'already liked' });
				console.log('Already Liked');
				return res.json({'error': true,'message': 'Already Liked'});
			}
			let newDisLiked = track.disliked;
			let dislikes = track.dislikes;
			dislikes[userId] = 0;
			if(dislyks[userId] && dislyks[userId] > 0) {
				newDisLiked = newDisLiked - 1;
			}
			let likes = track.likes;
			likes[userId] = (lyks[userId] || 0) + 1;
			let newLiked = track.liked + 1;
			let updatedAt = moment().format("YYYY-MM-DD HH:mm:ss");
			UserTrack.update(track.id, { disliked: newDisLiked, dislikes: dislikes, liked: newLiked, likes: likes, updatedAt: updatedAt }).exec((err, tr) => {
				if(err) return res.serverError(err);
				console.log('Like Added' + userId, { track: tr });
				sails.sockets.blast('liked.' + userId, { track: tr });
				return res.json({'error': false,'likeCount':newLiked,'dislikeCount': newDisLiked});
			})
		})
	},
	updateDislikes: function(req, res) {
		let params = req.params.all();
		if(!params.id) {
		  if(req.isSocket || params.json) {
			return res.json(data);
		  }
		  else {
			return res.badRequest(`This id (${params.id}) doesn\'t found`)
		  }
		}
		let userId = req.session.user.id;
		console.log('Try dislike track', req.param('id'))
		if(req.session.user.isLocked) {
			return res.serverError(req.session.user.isLocked.msg);
		}
		UserTrack.findOne({id: params.id}, (err, track) => {
			if(err || !track) {
				return res.serverError({ msg: 'Track not found!' });
			}
			let dislykes = JSON.parse(track.dislikes);
			let lyks = JSON.parse(track.likes);
			console.log('Track dislikes: ', dislykes[userId] || []);
			//sails.log('Track dislikes: ', track.likes[userId] || [])
			if(dislykes[userId] && dislykes[userId] > 0 && !req.session.user.admin) {
				sails.sockets.blast('error.' + userId, { error: 'already liked' });
				console.log('Already Dis Liked');
				return res.json({'error': true,'message': 'Already Dis Liked'});
			}
			let newLiked = track.liked;
			let likes = track.likes;
			likes[userId] = 0;
			if(lyks[userId] && lyks[userId] > 0) {
				newLiked = newLiked - 1;
			}
			let dislikes = track.dislikes;
			dislikes[userId] = (dislykes[userId] || 0) + 1;
			let newDisLiked = track.disliked + 1;
			let updatedAt = moment().format("YYYY-MM-DD HH:mm:ss");
			UserTrack.update(track.id, { liked: newLiked, likes: likes, disliked: newDisLiked, dislikes: dislikes, updatedAt: updatedAt }).exec((err, tr) => {
				if(err) return res.serverError(err);
				console.log('DisLike Added' + userId, { track: tr });
				sails.sockets.blast('disliked.' + userId, { track: tr });
				return res.json({'error': false,'likeCount':newLiked,'dislikeCount':newDisLiked});
			})
		})
	},
	downloadTrack: function(req, res) {
		sails.log('Get gile', req.params.all())
		if(!req.param('id')) {
		  return res.serverError('This id: ' + req.param('id') + ' is not defined')
		}
		download(req, res);
	}
};