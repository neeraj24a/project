-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2018 at 03:34 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pool`
--

-- --------------------------------------------------------

--
-- Table structure for table `remix_odest_track`
--

CREATE TABLE `remix_odest_track` (
  `id` int(10) UNSIGNED NOT NULL,
  `uploadedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `played` int(11) NOT NULL DEFAULT '0',
  `downloaded` int(11) NOT NULL DEFAULT '0',
  `liked` int(11) NOT NULL DEFAULT '0',
  `disliked` int(11) NOT NULL DEFAULT '0',
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `artist` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remixer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `genre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subgenre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bpm` int(11) DEFAULT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `action` int(11) DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `search` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rsearch` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploads` longtext COLLATE utf8mb4_unicode_ci,
  `likes` longtext COLLATE utf8mb4_unicode_ci,
  `dislikes` longtext COLLATE utf8mb4_unicode_ci,
  `size` int(11) DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `remix_odest_track`
--

INSERT INTO `remix_odest_track` (`id`, `uploadedBy`, `type`, `played`, `downloaded`, `liked`, `disliked`, `comment`, `name`, `artist`, `title`, `remixer`, `genre`, `subgenre`, `bpm`, `key`, `year`, `action`, `url`, `slug`, `search`, `rsearch`, `uploads`, `likes`, `dislikes`, `size`, `createdAt`, `updatedAt`) VALUES
(1, 'neeraj24a', 'remix', 0, 0, 0, 0, 'Clean', 'Test Song - Test Artist.mp3', 'Test Artist', 'Test Song', 'remixer', 'Hip-Hop', 'Remix', 98, '1E', 2018, 0, 'jhjh', 'jhjhjh', 'hjhjhj', 'hjhjh', '{}', '{}', '{}', 78454, '2018-08-08 00:00:00', '2018-08-08 00:00:00'),
(2, 'neeraj24a', 'remix', 0, 0, 2, 0, 'Clean', 'Test Song 2 - Test Artist 2.mp3', 'Test Artist 2', 'Test Song 2', 'remixer', 'Hip-Hop', 'Remix', 98, '1E', 2018, 0, 'jhjh2', 'jhjhjh2', 'hjhjhj2', 'hjhjh2', '{}', '{\"1\":2}', '{\"1\":0}', 78454, '2018-08-08 00:01:00', '2018-08-17 18:59:29'),
(3, 'neeraj24a', 'odest', 0, 0, 0, 0, 'Clean', 'Odest Song - Odest Artist.mp3', 'Odest Artist', 'Odest Song', 'remixer', 'Hip-Hop', 'Remix', 98, '1E', 2018, 0, 'jhjh', 'jhjhjh', 'hjhjhj', 'hjhjh', '{}', '{}', '{}', 78454, '2018-08-08 00:02:00', '2018-08-08 00:02:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `remix_odest_track`
--
ALTER TABLE `remix_odest_track`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `remix_odest_track` ADD FULLTEXT KEY `artist` (`artist`);
ALTER TABLE `remix_odest_track` ADD FULLTEXT KEY `title` (`title`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `remix_odest_track`
--
ALTER TABLE `remix_odest_track`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
