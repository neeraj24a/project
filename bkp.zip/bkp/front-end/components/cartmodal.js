import Vue from 'vue';

export default Vue.component('cartmodal', {
  template: `
	<transition name="modal">
		<div class="container" id="wrapper">
			<modal v-if="loadModal"> 
			  <h3 slot="header" class="modal-title">
				Modal title
			  </h3>
				
			  <div slot="footer">
			   <button type="button" class="btn btn-outline-info" @click="closeModal()"> Close </button>
			   <a href="/crate" class="btn btn-primary" data-dismiss="modal">
				 Go To Cart
			   </a>
			  </div>
			</modal>
		</div>
	</transition>`,
  data: () => {
    return {
		loadModal: true
    }
  },
  mounted() {
    
  },
  methods: {
    closeModal() {
      this.loadModal = false;
    }
  }
})