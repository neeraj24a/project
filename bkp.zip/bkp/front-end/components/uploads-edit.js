import Vue from 'vue';

export default Vue.component('update-modal', {
	template: '#update-modal-template',
    props: ['id'],
	methods: {
        close() {  this.$emit('close') },
		handleSubmit1(event) {
			console.log(event);
		}
    }
})