import Vue from 'vue';
export default Vue.directive('locked', {
	inserted(el, binding, vnode) {
		el.tip = null;
		if(binding.value) {
			el.tip = new Opentip(el, {});
			el.tip.setContent(binding.value);
		}
	},
	componentUpdated(el, binding, vnode) {
		if(!el.tip) {
			if(binding.value) {
				el.tip = new Opentip(el, {});
				el.tip.setContent(binding.value);
			}
		}
	}
})