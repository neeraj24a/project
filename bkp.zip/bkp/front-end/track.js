import {BASE_URL} from '../../config';
import _ from 'lodash/core';
import get from 'lodash/get';
import findIndex from 'lodash/findIndex';
import cloneDeep from 'lodash/cloneDeep';
import moment from 'moment';



import Vue from 'vue';
import { getModel } from '../server/services/collections-service';
import * as TrackService from '../server/services/track-service';
import { getGenreFilters } from '../server/services/filter-service';
import '../server/components/dnd';

Vue.config.errorHandler = function (err, vm, info) {
  console.log(err)
  console.log(vm)
  console.log(info)
}

let newTrackApp = new Vue({
  data() {
    return {
      allProgress: 0,
      preparedFiles: [],
      uploadedFiles: [],
      genres: [],
      schema: {},
      preparingFiles: false,
      saving: false,
      moment
    }
  },
  mounted() {
    this.reset();
    TrackService.getViewSchema().then(schema => {
      this.viewSchema = schema;
    });
    getModel('track').then(data => {
      this.schema = data;
    })
    getGenreFilters().then(data => {
      this.genres = data;
      return data;
    })
  },
  methods: {
    testMetadata() {
      TrackService.getMetadata({formData: [], params: {}}).then(data => {
        console.log(data)
      })
    },
    getRemix(file) {
      // get remix for attachment to new track before upload to server 
      return new Promise((resolve, reject) => {
        if(!file) return reject('Enter valid data');
        let filterParams = {
          artist: {
						contains: file.artist
					},
					title: {
						contains: file.title.substr(0, (file.title.indexOf('(') != -1 ? file.title.indexOf('(') : file.title.length - 1)).trim()
					},
          type: file.type
        };
        console.log(filterParams)
        let ui = new Date().getTime() + Math.floor(Math.random() * 9999);
        TrackService.getTracks({
          search: {
            query: filterParams
          },
          ui: ui
        }).then(data => {
          resolve({file, remixes: data.tracks});
        })
      })
    },
    reset() {
      // reset form to initial state
      this.preparedFiles = [];
    },
    addToResult(file) {
      if(!file) return;
      this.convertToSchema(file)
      .then(this.getRemix)
      .then(({file, remixes}) => {
        file.remix = remixes || [];
        this.preparedFiles.push(file);
      })
      .catch(data => {
        if(data) {
          return this.preparedFiles.push(data);
        }
        console.warn(data)
      });
    },
    preSave(files) {
      // this.preparingFiles = true;
      let promises = [];
      files.forEach(function(element) {
        promises.push(
          this.convertToSchema(element)
          // .then(newFile => {
          //   return this.checkExisting(newFile);
          // })
          .then(newFile => {
            if(newFile.isExist) {
              this.preparedFiles.push(newFile);
              return Promise.reject({file: newFile})
            }
            return this.getRemix(newFile);
          })
          .then(({file, remixes}) => {
            file.remix = remixes || [];
            if(file) {
              this.preparedFiles.push(file);
            }
            return file
          })
        );
      }, this);
      Promise.all(promises).then(result => {
        console.log('all done')
        this.preparingFiles = false;
      }).catch(() => {
        console.log('finish')
        this.preparingFiles = false;
      })
    },
    uploadFile({formData, onProgress}) {
      return new Promise((resolve, reject) => {
        delete formData.isExist;
        TrackService.s3upload({
        // TrackService.upload({
          formData,
          onProgress: onProgress
        })
        .then(
          (data) => {
            resolve(data);
          },
          (err) => {
            console.log(err)
          }
        )
      })
    },
    saveAll() {
      let savingFiles = this.preparedFiles.filter(item => {
        return !item.saving
      });
      if(this.saving) return Promise.reject('Is saving now!');
      if(!savingFiles.length) return Promise.reject('Nothing to save')
      return savingFiles.forEach(item => {
        this.$set(item, 'uploading', true);
        this.saveFile(item, 'auto');
      })
    },
    saveFile(obj, type) {
      // return false;
      if(obj.isExist) {
        let removedIndex = findIndex(this.preparedFiles, obj);
        console.log('removedIndex: ',removedIndex);
        this.removeTrack(removedIndex);
        return;
      }
      if(obj.saving) return Promise.reject('Is saving now!');
      return new Promise((resolve, reject) => {
        this.$set(obj, 'saving', true);
        this.$set(obj, 'single', true);
        // create form data for upload file
        const formData = new FormData();
        formData.append('track', obj.file, obj.name);
        // call method for upload
        this.$set(obj, 'uploading', true);
        this.uploadFile({
            formData,
            onProgress: progress => {
              // change progress state
              this.$set(obj, 'progress', Math.min(parseInt(progress), 90))
              // this.getProgress();
          }}).then(files => {
            // change state
            // call method of the save and change state
            obj.url = files[0].url;
            delete obj.file;
            this.saveTrack(obj).then(() => {
              // change saving state
              this.removeTrack(findIndex(this.preparedFiles, obj));
              resolve(obj);
            })
          });
      })
    },
    getProgress() {
      let sum = 0;
      let savingCount = 0;
      this.preparedFiles.forEach(obj => {
        if(obj.saving) savingCount++;
        sum = sum + parseFloat(obj.progress || 0);
      });
      this.allProgress = Math.min(sum / savingCount, 95);
      return sum;
    },
    convertToSchema(file) {
      return new Promise((resolve, reject) => {
        let vs = cloneDeep(this.viewSchema);
        let randomName = new Date().getTime() + Math.floor(Math.random() * 9999);
        let year = new Date(String(get(file, 'metatags.year', null))).getFullYear();
        let defaultOptios = Object.assign(vs, {
          name: get(file, 'name', get(file, 'filename', randomName)),
          artist: get(file, 'metatags.artist', null),
          title: get(file, 'metatags.title', ''),
          year: isNaN(year) ? 0 : year + 1,
          genre: get(file, 'metatags.genre', null),
          subgenre: get(file, 'metatags.subgenre', null),
          bpm: get(file, 'metatags.bpm', null),
          key: get(file, 'metatags.key', null),
          comment: get(file, 'metatags.comment', null),
          type: file.type.split("/")[0],
          remixer: get(file, 'metatags.remixer', null),
          isRadio: 0
        });
        console.log('File options: ', defaultOptios)
        let newFile = Object.assign(defaultOptios, {
         file
        });
        if(file.isExist) {
          console.log('File exist')
          newFile.isExist = true;
          return reject(newFile);
        }
        resolve(newFile);
      })
    },
    saveTrack(obj, index) {
      console.log('start track saving');
      return new Promise((resolve, reject) => {
        delete obj.progress;
        delete obj.isExist;
        delete obj.file;

        obj.remix = obj.remix.map(item => item.id);
        TrackService.save(obj).then(track => {
          console.log('Track is saved');
          resolve();
        }, reason => {
          console.log('track isn\'t saved. Error: ', reason);
          reject(reason)
        })
      })
    },
    checkExisting(file) {
      // get remix for attachment to new track before upload to server 
      return new Promise((resolve, reject) => {
        if(!file) return reject('Enter valid data');
        let filterParams = {
          artist: file.artist,
          title: file.title
        };
        let ui = new Date().getTime() + Math.floor(Math.random() * 9999);
        TrackService.getTracks({
          search: {
            query: filterParams
          },
          ui: ui
        }).then(responce => {
          file.isExist = !!responce.tracks.length;
          resolve(file);
        })
      })
    },
    removeTrack(index, array) {
      if(!array) array = this.preparedFiles
      console.log('remove: ', index);
      array.splice(index, 1);
    }
  }
});

if(document.getElementById('track-creation')) {
  newTrackApp.$mount('#track-creation')
}