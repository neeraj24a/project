'use strict';
import axios from 'axios';
import {BASE_URL} from '../../config';

const getConfig = function() {
  const url = `${BASE_URL}/config`;
  return axios.get(url).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      error: error
    })
  });
}

const trackSchema = function(updateNeeded) {
  const url = `${BASE_URL}/get-model/userTrack`;
  return axios.get(url).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      message: 'Tracks model not found',
      error: error
    })
  });
}

const getTracks = (params) => {
  const url = `${BASE_URL}/search/remix-oddest`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.get(url, params, function(data) {
		    resolve(data);
      });
    }
    axios.get(url, {
      params: Object.assign({ json: true }, params)
    }).then(response => {
      // get body data
	    return response.data.tracks;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}
const getRemixTracks = (params) => {
	const url = `${BASE_URL}/search/remix`;
	return new Promise((resolve, reject) => {
		if(io.socket) {
		  return io.socket.get(url, params, function(data) {
				resolve(data);
		  });
		}
		axios.get(url, {
		  params: Object.assign({ json: true }, params)
		}).then(response => {
		  // get body data
			return response.data.tracks;
		}, error => {
		  // error callback
		  reject(new Error({
			message: 'Tracks not found',
			erorr: erorr
		  }))
		  return new Error({
			message: 'Tracks not found',
			erorr: erorr
		  })
		});
	})
}
const getOdestTracks = (params) => {
	const url = `${BASE_URL}/search/odest`;
	return new Promise((resolve, reject) => {
		if(io.socket) {
		  return io.socket.get(url, params, function(data) {
				resolve(data);
		  });
		}
		axios.get(url, {
		  params: Object.assign({ json: true }, params)
		}).then(response => {
		  // get body data
			return response.data.tracks;
		}, error => {
		  // error callback
		  reject(new Error({
			message: 'Tracks not found',
			erorr: erorr
		  }))
		  return new Error({
			message: 'Tracks not found',
			erorr: erorr
		  })
		});
	})
}
const updateRemixOdestStreamCount = (params) => {
	const url = `${BASE_URL}/update-ro-stream-count`;
	const trackId = params.trackId;
	return new Promise((resolve, reject) => {
		if(io.socket) {
		  io.socket.get(`${url}/${trackId}`, {}, function (data){
			resolve(data);
		  });
		}
		else {
		  axios.get(`${url}/${trackId}`, {}).then((data) => {
			resolve();
		  });
		}
	})
}
const updateRemixOdestLikesCount = (params) => {
	const url = `${BASE_URL}/update-ro-like-count`;
	const trackId = params.trackId;
	return new Promise((resolve, reject) => {
		if(io.socket) {
		  io.socket.get(`${url}/${trackId}`, {}, function (data){
			resolve(data);
		  });
		}
		else {
		  axios.get(`${url}/${trackId}`, {}).then((data) => {
			resolve();
		  });
		}
	})
}
const updateRemixOdestDisLikesCount = (params) => {
	const url = `${BASE_URL}/update-ro-dislike-count`;
	const trackId = params.trackId;
	return new Promise((resolve, reject) => {
		if(io.socket) {
		  io.socket.get(`${url}/${trackId}`, {}, function (data){
			resolve(data);
		  });
		}
		else {
		  axios.get(`${url}/${trackId}`, {}).then((data) => {
			resolve();
		  });
		}
	})
}
const update = (params) => {
  // /admin/track/update/:id
  const url = `${BASE_URL}/remix-odest/track/update/${params.id}`;
  params = Object.assign(params, { json: true });
  return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.post(url, params, function(data) {
        resolve(data);
      });
    }
    axios.post(url, params)
    // get data
    .then(x => {
      resolve(x.data)
      return x.data;
    }, err => {
      reject(err)
    })
  })
}
const removeTrack = (params) => {
  const url = `${BASE_URL}/remix-odest/track/destroy`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.delete(`${BASE_URL}/remix-odest/track/destroy/${params.id}`, { _csrf: params.csrf }, function (data){
        resolve();
      });
    }
    else {
      axios.delete(`${BASE_URL}/remix-odest/track/destroy/${params.id}`, { _csrf: params.csrf }).then((data) => {
        resolve();
      });
    }
  })
}
const upload = (formData) => {
    const url = `${BASE_URL}/file/upload`;
    return axios.post(url, formData)
        // get data
        .then(x => x.data)
        // add url field
        .then(x => x.map(file => Object.assign({},
            file, {})));
}

const save = (file, _csrf) =>{
  const url = `${BASE_URL}/track/create`;
    return axios.post(url, {
      _csrf: _csrf,
      fileInfo: file
    })
        // get data
        .then(x => x.data, err => {
          console.log(err)
        })
        // // add url field
        // .then(x => x.map(file => Object.assign({},
        //     file, {})));
}

const checkDownloadCount = ({id, csrf}) => {
  const url = `${BASE_URL}/check-download-track`;
  return new Promise((resolve, reject) => {
    axios.get(`${url}/${id}`, { _csrf: csrf || '' }).then(response =>{
      resolve(response.data);
    }).catch(error => {
      console.log(error);
    });
  })
}
const markedAllAsDownloaded = () => {
  const url = `${BASE_URL}/marked-as-downloaded`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.get(url, {}, responce => {
        resolve(responce);
      });
    }
    else {
      axios.get(url, { }).then(data => {
        resolve();
      });
    }
  })
}

export { 
  trackSchema,
  getTracks,
  update,
  getRemixTracks,
  getOdestTracks,
  updateRemixOdestStreamCount,
  updateRemixOdestLikesCount,
  updateRemixOdestDisLikesCount,
  removeTrack,
  getConfig,
  upload,
  checkDownloadCount,
  save,
  markedAllAsDownloaded
}