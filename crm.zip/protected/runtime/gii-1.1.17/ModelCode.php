<?php
return array (
  'template' => 'default',
  'connectionId' => 'db',
  'tablePrefix' => '',
  'modelPath' => 'application.modules.admin.models',
  'baseClass' => 'BaseModel',
  'buildRelations' => '0',
  'commentsAsLabels' => '0',
);
