<?php
/* @var $this UsersController */
/* @var $model Users */
/* @var $form CActiveForm */
?>
<div class="panel panel-default">
    <div class="panel-heading">Users Form</div>
    <div class="panel-body">
        <div class="row">
        <?php $form=$this->beginWidget('CActiveForm', array(
            'id'=>'users-form',
            // Please note: When you enable ajax validation, make sure the corresponding
            // controller action is handling ajax validation correctly.
            // There is a call to performAjaxValidation() commented in generated controller code.
            // See class documentation of CActiveForm for details on this.
            'enableAjaxValidation'=>false,
    )); ?>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'username'); ?>
                    <?php echo $form->textField($model,'username',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'username'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'password'); ?>
                    <?php echo $form->passwordField($model,'password',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'password'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'role'); ?>
                    <?php echo $form->textField($model,'role',array('size'=>10,'maxlength'=>10,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'role'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'relation'); ?>
                    <?php echo $form->textField($model,'relation',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'relation'); ?>
                </div>
            </div>
            <div class="col-lg-6 m-t-20">
                <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save',array('class' => 'mb-sm btn btn-info')); ?>
            </div>
            <?php $this->endWidget(); ?>
        </div>
    </div>
</div>
