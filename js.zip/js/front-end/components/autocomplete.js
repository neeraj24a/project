// import io from 'socket.io-client'
import * as _ from "lodash";

import Vue from 'vue';
import {BASE_URL} from '../../config';

import * as TrackService from '../services/track-service';

let selectedField = 'artist';
// let getTracks = (searchQuery, ui) => {
//   if(io.socket) {
//     io.socket.get(BASE_URL + '/search/autocomplete', , function(data) {
//     });
//   }
// }

Vue.directive('focus', {
  update(el, binding) {
    if(binding.value) {
      el.focus();
    }
  }
})
Vue.directive('scrolltoview', {
  update(el, binding) {
    if(binding.value) {
      el.offsetParent.scrollTop = el.offsetTop - el.offsetParent.offsetHeight + el.offsetHeight;
    }
  }
})

export default Vue.component('autocomplete', {
  template: `
    <div class="autocomplete-bar">
      <span v-for="item in selectedItems">{{item.artist}} - {{item.title}}</span>
      <input class="head_search search-bar__input"
				type="text"
        autocomplete="off"
        name="search"
        v-model="search"
        :disabled="disabled"
        v-on:focus=""
        v-on:blur="onBlur"
        v-on:keyup="keyUp($event)"
				placeholder="Search...">
      <div class="autocomplete-search-list primary dk" v-if="searchStart">
        <ul v-if="!notEnoughtLetters">
          <li
            class="autocomplete-search-item"
            :class="{selected: selectedIndex === index }"
            v-on:click="selectItem(item, 'name')"
            v-for="(item, index) in searchItems"
            v-scrolltoview="selectedIndex === index"
          >
            {{item.artist}} - {{item.title}}
          </li>
        </ul>
        <div v-if="searchStart">
          <div v-if="notEnoughtLetters">Enter more letters</div>
          <div v-else-if="!searchItems.length">No results</div>
        </div>
      </div>
    </div>`,
  props: ['value', 'filters', 'local', 'disabled'],
  data: function() {
    return {
      selectedItem: null,
      searchItems: [],
      isfocus: true,
      search: this.search,
      selectedIndex: -1,
      selectedItems: [],
      searchStart: false,
      notEnoughtLetters: true,
      ui: new Date().getTime() + Math.floor(Math.random() * 9999)
    }
  },
  watch: {
    value: function(value) {
      this.search = value;
    }
  },
  mounted() {
    
  },
  methods: {
    onBlur() {
      setTimeout(() => { this.searchStart = false; }, 100);
    },
    keyUp(e) {
      this.notEnoughtLetters = e.target.value.length < 0;
      this.searchStart = true; 
      switch (e.keyCode) {
        case 13:
          // enter button
          this.selectItem(this.searchItems[this.selectedIndex]);
          break;
        case 38:
          // up button
          if (this.selectedIndex >= 0) this.selectedIndex--;
          e.preventDefault();
          break;
        case 40:
          // down button
          if (this.selectedIndex < this.searchItems.length - 1) this.selectedIndex++;
          e.preventDefault();
          break;
        default:
          if(!this.notEnoughtLetters) this.getTracks();
          break;
      }
    },
    getTracks() {
      let self = this;
      let ui = this.ui;
			let filterParams = {};
			// filter by main genre if checked
			if(this.filters.genre) filterParams.genre = this.filters.genre;
			// filter by sub genre if checked
			if(this.filters.subgenre) filterParams.subgenre = this.filters.subgenre;
			// filter by date if checked
			if(this.filters.date.createdAt) filterParams.createdAt = this.filters.date.createdAt;
			if(this.filters.isRadio) filterParams.isRadio = '1';
			if(this.filters.trackType) filterParams.type = this.filters.trackType;
			filterParams.sort = 'createdAt ASC';
			// get current page
			// filterParams.page = this.filters.page || 1;
			// filter by search words if exist
			filterParams.or = [
        {
          artist: {
            contains: this.search
          }
        },
        {
          title: {
            contains: this.search
          }
        },
        {
          search: {
            contains: this.search
          }
        },
        {
          rsearch: {
            contains: this.search
          }
        }
      ];
      if(this.local) {
        this.selectedIndex = -1;
        this.searchItems = this.local;
        let searchText = this.search.toLowerCase();
        
        delete filterParams.sort
        for(let key in filterParams) {
          this.searchItems = this.searchItems.filter(item => {
            if(key == 'or') {
              let artistExist = item.artist && item.artist.toLowerCase().indexOf(searchText) != -1
              let titleExist = item.title && item.title.toLowerCase().indexOf(searchText) != -1
              let searchExist = item.search && item.search.toLowerCase().indexOf(searchText) != -1
              let rsearchExist = item.rsearch && item.rsearch.toLowerCase().indexOf(searchText) != -1
              return artistExist || titleExist || searchExist || rsearchExist;
            }
            else {
              return  item[key] == filterParams[key]
            }
          })
        }
        return;
      }
      console.log(filterParams);
      TrackService.getTracks({
        search: {
          query: filterParams,
          pagelimit: {
            page: 1
          }
        },
        ui: this.ui
      }).then((data) => {
        if(data.ui == this.ui){
          this.searchItems = data.tracks;
          this.selectedIndex = -1;
        }
      })
    },
    changeValue(item) {
      if(item) {
        if(item[selectedField]) this.search = item;
        this.getTracks();
        this.updateValue();
        this.search = item.artist + ' - ' + item.title;
      }
    },
    updateValue() {
      this.$emit('search', this.search);
    },
    selectItem(item) {
      if(item) {
        this.selectedItem = item;
        this.selectedIndex = this.searchItems.indexOf(item);
        this.changeValue(item);
        this.selectedIndex = -1;
      }
      else {
        this.updateValue();
      }
      this.searchStart = false;
    }
  }
})