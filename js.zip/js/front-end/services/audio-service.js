'use strict';
import axios from 'axios';
import {BASE_URL} from '../../config';

const getConfig = function() {
  const url = `${BASE_URL}/config`;
  return axios.get(url).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      error: error
    })
  });
}

const trackSchema = function(updateNeeded) {
  const url = `${BASE_URL}/get-model/track`;
  return axios.get(url).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      message: 'Tracks model not found',
      error: error
    })
  });
}

const getTracks = (params) => {
    console.log(params);
    console.log(`${params.search.name}`);
    const url = `${BASE_URL}/media/${params.search.name}`;
    console.log(url);
    return new Promise((resolve, reject) => {
    if(io.socket) {
      return io.socket.get(url, params, function(data) {
        resolve(data);
      });
    }
    axios.get(url, {
      params: Object.assign({ json: true }, params)
    }).then(response => {
      // get body data
      resolve(response.data.tracks);
      return response.data.tracks;
    }, error => {
      // error callback
      reject(new Error({
        message: 'Tracks not found',
        erorr: erorr
      }))
      return new Error({
        message: 'Tracks not found',
        erorr: erorr
      })
    });
  })
}

const checkDownloadCount = ({id, csrf}) => {
  const url = `${BASE_URL}/check-download-track`;
  return new Promise((resolve, reject) => {
    axios.get(`${url}/${id}`, { _csrf: csrf || '' }).then(response =>{
      resolve(response.data);
    }).catch(error => {
      console.log(error);
    });
  })
}
const markedAllAsDownloaded = () => {
  const url = `${BASE_URL}/marked-as-downloaded`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.get(url, {}, responce => {
        resolve(responce);
      });
    }
    else {
      axios.get(url, { }).then(data => {
        resolve();
      });
    }
  })
}

export { 
  trackSchema,
  getTracks,
  getConfig,
  checkDownloadCount,
  markedAllAsDownloaded
}