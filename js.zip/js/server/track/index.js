'use strict';
import _ from 'lodash';
import clone from 'lodash/clone';
import some from 'lodash/some';
import Vue from 'vue';

import moment from 'moment';
import * as TrackService from '../services/track-service';
import * as FilterService from '../services/filter-service';

const window = window;

Vue.config.errorHandler = function (err, vm, info) {
	console.log(err)
	console.log(vm)
	console.log(info)
}


let trackApp = new Vue({
	data: {
		loadingTrack: true,
		searchValue: '',
		isRadio: false,
		viewTracks: [],
		pagination: null,
		moment
	},
	beforeCreate() {
		FilterService.getGenreFilters().then(data => {
			this.filters = data;
		})
	},
	created () {
		this.loadingTracks().then(data => {
			if(io.socket) {
				console.log('socket init')
				io.socket.on('track-updated', function updateTrack(updated) {
					console.log(updated)
					let tmp = _.find(this.viewTracks, { id: updated.id*1 })
					tmp = updated;
				});
			}
		});
		
	},
	methods: {
		loadingTracks () {
			return this.getFilterTrack();
		},
		searchAllRemixes() {
			TrackService.searchAllRemixes();
		},
    searchRemix(track) {
      track.searching = true;
      return this.getRemix(track).then(data => {
        // this.newRemix = _.differenceBy(data.remixes, track.remix, 'id');
				this.newRemix = data.remixes;
        delete track.searching;
        this.saveState(track);
				track.remix = this.newRemix;
				this.changedTrack(track);
				return data;
      })
    },
    getRemix(track) {
      // get remix for attachment to new track before upload to server 
      return new Promise((resolve, reject) => {
        if(!track) return reject('Enter valid data');
        let filterParams = {
          artist: {
						contains: track.artist
					},
					title: {
						contains: track.title.substr(0, (track.title.indexOf('(') != -1 ? track.title.indexOf('(') : track.title.length - 1)).trim()
					},
          // type: track.type,
          id: {
            '!': track.id
          }
        };
        let ui = new Date().getTime() + Math.floor(Math.random() * 9999);
        TrackService.getTracks({
          search: {
            query: filterParams
          },
          ui: ui
        }).then(responce => {
          resolve({track, remixes: responce.data});
        })
      })
    },
		saveState(track) {
			this.savedItem = Object.assign({}, track);
		},
		changedTrack(track) {
			let diff = {};
			for(let key in this.savedItem) {
				if(track.hasOwnProperty(key) && key != 'showRemix') {
					if(track[key] != this.savedItem[key]) {
						diff[key] = track[key];
					}
				}
			}
			diff.id = track.id;
			track.saving = true;
			this.$set(track, 'saving', true);
			if(diff.remix) {
				diff.remix = diff.remix.map(item => item.id);
			}
      TrackService.update(diff).then(data => {
				delete track.saving;
				this.saveState(track);
				this.$set(track, 'saving', false);
			})
		},
		removeTrack(track) {
			track.removed = true;
			let isConfirm = confirm('Are you sure to remove track: ' + track.artist + ' - ' + track.title);
			if(isConfirm) {
				TrackService.removeTrack(track).then(data => {
					track.removed = false;
					this.viewTracks.splice(this.viewTracks.indexOf(track), 1);
					this.searchTrack();
				})
			}
			else {
				track.removed = false;
			}
		},
		prevPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				this.pagination.page--;
				this.getFilterTrack();
			})
		},
		nextPage() {
			return new Promise((resolve, reject) => {
				// if(this.noMore) return reject(this.noMore);
				this.pagination.page++;
				this.getFilterTrack().then(() => {
					resolve();
				}, reason => {
					// this.activeFilter.page--;
					// this.noMore = reason;
				});
			})
		},
		refindRemix() {
			let allPromises = [];
			this.loadingTrack = true;
			this.viewTracks.forEach(item => {
				let prom = this.searchRemix(item);
				allPromises.push(prom);
			})
			Promise.all(allPromises).then(results => {
				this.loadingTrack = false;
			})
		},
		searchTrack() {
			if(this.pagination) this.pagination.page = 1; 
			this.getFilterTrack();
		},
		getFilterTrack({params, concat} = {}) {
			let filterParams = Object.assign({}, params ? params.filter : {});
			filterParams.sort = 'createdAt DESC';
			filterParams.or = [
				{
					artist: {
					contains: this.searchValue
				}
				},
				{
					title: {
						contains: this.searchValue
					}
				}
			]
			if(this.isRadio) {
				filterParams.isRadio = '1';
			}
			this.loadingTrack = true;
			return new Promise((resolve, reject) => {
				TrackService.getTracks({ search: {
					query: filterParams,
					pagelimit: {
						page: this.pagination ? this.pagination.page : 1 
					}
				}
			}).then(data => {
					this.pagination = data.meta;
					this.viewTracks = concat ? this.viewTracks.concat(data.tracks) : data.tracks.map(item => { item.showRemix = false; return item; });
					if (data.tracks.length) {
						resolve(data);
					}
					else {
						reject({ message: 'No more tracks'});
					}
					this.loadingTrack = false;
				}, reason => {
					reject({ message: reason });
					this.loadingTrack = false;
				})
			})
		}
	}
})
if(document.getElementById('admin-tracks')) {
	trackApp.$mount('#admin-tracks')
}