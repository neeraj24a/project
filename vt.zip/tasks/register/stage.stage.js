module.exports = function (gulp, plugins) {
  gulp.task('stage', function(cb) {
    plugins.sequence(
      'compileAssets:stage',
      'concat:stage',
      'sails-linker-gulp:prodAssets',
      'sails-linker-gulp:prodViews',
      'images:stage',
      cb
    );
  });
};
