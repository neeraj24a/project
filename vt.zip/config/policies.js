/**
 * Policy Mappings
 */
module.exports.policies = {
  '*': 'flash',
  CartController: {
    'add': ['isLoggedIn', 'isSubscribed']
  },
  FileController: {
    'attachZip': ['isLoggedIn', 'isSubscribed'],
    'downloadTrack': ['isLoggedIn', 'isSubscribed']
  }
};
