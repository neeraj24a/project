export default class {
  constructor(el, options) {
    this.options = Object.assign({
      enabled: true
    }, options || {});
    this.el = el;
    this.state = false;

    this.findElements();
    this.addEvents();
  }
  findElements() {
    this.window = window;
  }
  addEvents() {
    this.windowHandler = (e) => {
      this.calculateDimensions();
      e.preventDefault();
    };
    this.window.addEventListener('scroll', this.windowHandler, this);
    this.window.addEventListener('resize', this.windowHandler, this);
  }
  calculateDimensions() {
    if(!this.options.enabled) return;
    let dim = this.el.getBoundingClientRect();
    let h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);

    if(dim.bottom < h) {
      this.calculating = true;
      // setTimeout(function() {
        console.log('timeout')
        this.options.callback().then(() => {
          console.log('callback')
          this.calculating = false;
          this.calculateDimensions();
        }, reason => {
          this.calculating = false;
        })
      // }.bind(this), 1000)
    }
    else {
      this.calculating = false;
    }
  }
  refresh() {
    this.calculateDimensions();
  }
  destroy() {
    this.window.removeEventListener('scroll', this.windowHandler);
    this.window.removeEventListener('resize', this.windowHandler);
  }
}