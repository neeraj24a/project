'use strict';
import _ from 'lodash/core';
import 'mediaelement';
import interact from 'interactjs';



let globalPlayer = null;
let AudioPlayer = class {
  constructor(el, src, options) {
    this.options = Object.assign({
      toggleButton: '.tracks-list__play',
      progress: '.tracks-list__player-progress',
      progressWrapper: '.tracks-list__player-wrapper',
      preview: 100, // in percent
      onOverPreview: () => {
        console.log('over preview time');
      },
    }, options || {});

    this.el = el;
    this.src = src;
    this.state = false;
    let self = this;

    this.findElements().then(() => {
      this.createPlayerWrapper().then((playerObj) => {
        this.player = playerObj;
        this.addEvents();
        this.playerEvents();
      });
      
    }, reason => {
      console.error(reason)
    })
    
  }
  findElements() {
    this.toggleButton = this.el.querySelector(this.options.toggleButton)
    this.progress = this.el.querySelector(this.options.progress)
    this.progressWrapper = this.el.querySelector(this.options.progressWrapper)

    return new Promise((resolve, reject) => {
      if(this.toggleButton && this.progress && this.progressWrapper) {
        resolve();
      }
      else {
        reject('Player\'s structure not ready');
      }
    })
  }
  addEvents() {
    this.toggleButton.addEventListener('click', (e) => {
      this.toggle();
      e.preventDefault();
    }, this);
    this.progressWrapper.addEventListener('mousemove', e => {
      e.preventDefault();
    })
    this.progressWrapper.addEventListener('mouseup', (e) => {
      e.preventDefault();
      let dimensions = this.progressWrapper.getBoundingClientRect();
      let preview = this.options.preview;
      let koef = 100 / parseInt(preview);
      let percentSeek = (e.x - dimensions.left) / dimensions.width;
      let settedTime = this.player.duration * percentSeek / koef;
      this.setTime(settedTime);
    }, this);
  }
  createPlayerWrapper() {
    return new Promise((resolve, reject) => {
      this.playerObj = document.createElement('audio');
      this.playerObj.setAttribute('preload', 'auto');
      this.el.appendChild(this.playerObj);
      // create wavebox
      // let wavebox = document.createElement('div');
      // this.progressWrapper.appendChild(wavebox);
      // let ui = 'wavesurfer' + new Date().getTime() + Math.floor(9999 * Math.random());
      // wavebox.setAttribute('id', ui);
      // wavebox.classList.add('wavebox');
      // this.wavesurfer = WaveSurfer.create(Object.assign({
      //     waveColor: 'grey',
      //     progressColor: 'black',
      //     barWidth: 1,
      //     scrollParent: false
      // }, this.options.waveOptions, { container: '#' + ui, height: this.progressWrapper.offsetHeight }));
      // resolve(this.wavesurfer);
      resolve(new MediaElement(this.playerObj));
    });
  }
  updateOptions(newOptions) {
    this.options = Object.assign(this.options, newOptions)
  }
  playerEvents() {
    this.player.addEventListener('timeupdate', (e) => {
      this.checkTime(e.timeStamp / 1000)
    }, this)

    this.player.addEventListener('play', (e) => {
      this.updateState(e);
      if(typeof this.options.onPlay === 'function') this.options.onPlay();
    }, this);
    this.player.addEventListener('pause', (e) => {
      this.updateState(e);
      if(typeof this.options.onPause === 'function') this.options.onPause();
    }, this);
    this.player.addEventListener('ended', (e) => {
      this.updateState(e);
      if(typeof this.options.onEnd === 'function') this.options.onEnd();
    }, this);
  }
  updateState(event) {
    let state = false;
    switch (event.type) {
      case 'play':
        state = true;
        break;
      case 'pause':
      case 'ended':
        state = false;
        break;
      default:
        state = false;
        break;
    }
    this.state = state;
    this.el.classList.toggle('playing', this.state);
  }
  checkTime(currentTime) {
    let percent = this.player.currentTime / this.player.duration * 100;
    let preview = this.options.preview;
    if(parseInt(preview) && parseInt(preview) < 100 && percent > parseInt(preview)) {
      this.stop();
      if(typeof this.options.onOverPreview === 'function') this.options.onOverPreview()
    }
    this.updateProgress(currentTime);
  }
  updateProgress(currentTime) {
    let preview = this.options.preview;
    let previewDuration = this.player.duration / 100 * parseInt(preview);
    let koef = 100 / (parseInt(preview) || 100);
    let percent = this.player.currentTime / this.player.duration * 100;
    let width = Math.min(percent * koef, 100);

    this.progress.style.width = width + '%';
  }
  toggle() {
    this[this.state ? 'pause': 'play']();
  }
  setTime(time) {
    if(this.player) this.player.setCurrentTime(time);
  }
  play() {
    if(!this.init) {
      this.init = true;
      if(this.player) this.player.setSrc(this.src);
    }
    setTimeout(() => {
      if(this.player) this.player.play();
    });

    if(globalPlayer && !_.isEqual(globalPlayer, this)) {
      globalPlayer.pause();
      if(globalPlayer.videoPlayer) {
        globalPlayer.videoHide();
      }
    }
    globalPlayer = this;
  }
  pause() {
    if(this.player) this.player.pause();
  }
  stop() {
    if(this.player) {
      this.pause()
      this.setTime(0)
    }
  }
  destroy() {
    console.log('destroy player')
    this.player.remove();
    this.el.removeChild(this.playerObj);
  }
}
let VideoPlayer = class {
  constructor(el, src, title, options) {
    this.options = Object.assign({
      toggleButton: '.tracks-list__play',
      progress: '.tracks-list__player-progress',
      progressWrapper: '.tracks-list__player-wrapper',
      videoPlayer: '.video-player',
      videoPlaceHolder: '.video-placeholder',
      titleHolder: '.video-title',
      preview: 15, // in percent
      onOverPreview: () => {
        console.log('over preview time');
      },
      shownClass: 'video-showing'
    }, options || {});

    this.el = el;
    this.src = src;
    this.state = false;
    this.title = title;
    let self = this;

    this.findElements().then(() => {
      this.createPlayerWrapper().then((playerObj) => {
        this.player = playerObj.media;
        
        if(this.src) this.setSrc();
        if(this.title) this.setTitle();
        this.addEvents();
        this.playerEvents();
        this.createDrag();
      });
      
    }, reason => {
      console.error(reason)
    })
    
  }
  findElements() {
    // this.toggleButton = this.el.querySelector(this.options.toggleButton)
    // this.progress = this.el.querySelector(this.options.progress)
    // this.progressWrapper = this.el.querySelector(this.options.progressWrapper)
    this.videoPlayer = this.el.querySelector(this.options.videoPlayer)
    if(this.videoPlayer) this.videoPlaceHolder = this.videoPlayer.querySelector(this.options.videoPlaceHolder)

    return new Promise((resolve, reject) => {
      if(this.el && this.videoPlayer && this.videoPlaceHolder) {
        resolve();
      }
      else {
        reject('Player\'s structure not ready');
      }
    })
  }
  addEvents() {
    // this.toggleButton.addEventListener('click', (e) => {
    //   this.toggle();
    //   e.preventDefault();
    // }, this);
    // this.progressWrapper.addEventListener('mousemove', e => {
    //   e.preventDefault();
    // })
    // this.progressWrapper.addEventListener('mouseup', (e) => {
    //   e.preventDefault();
    //   let dimensions = this.progressWrapper.getBoundingClientRect();
    //   let preview = this.options.preview;
    //   let koef = 100 / parseInt(preview);
    //   let percentSeek = (e.x - dimensions.left) / dimensions.width;
    //   let settedTime = this.player.duration * percentSeek / koef;
    //   this.setTime(settedTime);
    // }, this);
  }
  createDrag() {
    // this.videoShow();
    let videoBox = this.videoPlayer;
    let dragMoveListener = function(event) {
      if(this.isFullScreen) return;
      var target = event.target,
        // keep the dragged position in the data-x/data-y attributes
        x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx,
        y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;
      target.style.webkitTransform =
      target.style.transform =
        'translate(' + x + 'px, ' + y + 'px)';

      // update the posiion attributes
      target.setAttribute('data-x', x);
      target.setAttribute('data-y', y);
    }.bind(this)
    let interactInst = interact(this.videoPlayer, {
      context: document
    }).draggable({
      inertia: true,
      restrict: {
        restriction: "body"
      },
      onmove: dragMoveListener
    })
  }
  createPlayerWrapper() {
    return new Promise((resolve, reject) => {
      this.playerObj = document.createElement('video');
      this.playerObj.setAttribute('preload', 'auto');
      
      if(this.videoPlaceHolder) {
        this.videoPlaceHolder.appendChild(this.playerObj);
        this.videoHandler();
      }
      resolve(new MediaElementPlayer(this.playerObj, {
        stretching: 'responsive',
        alwaysShowControls: true,
        clickToPlayPause: false,
        features: ['playpause','current','progress','duration','tracks','volume', 'fullscreen'],
      }));
      
    });
  }
  videoHandler() {
    if(this.videoPlayer) {
      this.videoPlayer.querySelector('.close').addEventListener('click', e => {
        this.pause();
        this.videoHide();
      }, this)
    }
  }
  videoShow() {
    if(this.videoPlayer) this.videoPlayer.classList.add(this.options.shownClass);
  }
  videoHide() {
    if(this.videoPlayer) this.videoPlayer.classList.remove(this.options.shownClass);
  }
  updateOptions(src, title, newOptions) {
    if(typeof this.options.onUpdate === 'function') this.options.onUpdate();
    if(this.player) this.pause();
    if (src) this.src = src;
    if(title) this.title = title;
    this.options = Object.assign(this.options, newOptions || {})
    this.setTitle();
    this.setSrc();
  }
  playerEvents() {
    this.player.addEventListener('timeupdate', (e) => {
      this.checkTime(e.timeStamp / 1000)
    }, this)
    this.player.addEventListener('play', (e) => {
      this.updateState(e);
      this.videoShow();
      if(typeof this.options.onPlay === 'function') this.options.onPlay();
    }, this);
    this.player.addEventListener('pause', (e) => {
      this.updateState(e);
      if(typeof this.options.onPause === 'function') this.options.onPause();
    }, this);
    this.player.addEventListener('ended', (e) => {
      this.updateState(e);
      if(typeof this.options.onEnd === 'function') this.options.onEnd();
    }, this);
    // webkitfullscreenchange mozfullscreenchange fullscreenchange
    let self = this;
    let fullScreenHandler = function(e) {
      let state = document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen;
      // Now do something interesting
      this.isFullScreen = state ? true : false;
    }.bind(this);
    document.addEventListener('webkitfullscreenchange', fullScreenHandler, this);
    document.addEventListener('mozfullscreenchange', fullScreenHandler, this);
    document.addEventListener('fullscreenchange', fullScreenHandler, this);
  }
  updateState(event) {
    let state = false;
    switch (event.type) {
      case 'play':
        state = true;
        break;
      case 'pause':
      case 'ended':
        state = false;
        break;
      default:
        state = false;
        break;
    }
    this.state = state;
    this.el.classList.toggle('playing', this.state);
  }
  checkTime(currentTime) {
    let percent = this.player.currentTime / this.player.duration * 100;
    let preview = this.options.preview;
    if(parseInt(preview) && parseInt(preview) < 100) {
      if(percent > parseInt(preview)) {
        this.stop();
        if(typeof this.options.onOverPreview === 'function') this.options.onOverPreview()
      }
    }
    // this.updateProgress(currentTime);
  }
  updateProgress(currentTime) {
    let preview = this.options.preview;
    let previewDuration = this.player.duration / 100 * parseInt(preview);
    let koef = 100 / (parseInt(preview) || 100);
    let percent = this.player.currentTime / this.player.duration * 100;
    let width = Math.min(percent * koef, 100);
    this.progress.style.width = width + '%';
  }
  toggle() {
    this[this.state ? 'pause': 'play']();
  }
  setTime(time) {
    if(this.player) this.player.setCurrentTime(time);
  }
  setSrc() {
    if(this.player) this.player.setSrc(this.src);
  }
  setTitle() {
    document.getElementById("videoTitle").innerHTML = this.title;
    //this.titleHolder.querySelector(this.title);
  }
  play() {
    if(globalPlayer && !_.isEqual(globalPlayer, this)) {
      // globalPlayer.pause();
      //   if(globalPlayer.videoPlayer) {
      //     globalPlayer.videoHide();
      //   }
    }
    setTimeout(() => {
      if(this.player) this.player.play();
    });
    globalPlayer = this;
  }
  pause() {
    if(this.player && this.player.pause) this.player.pause();
  }
  stop() {
    if(this.player) {
      this.pause()
      this.setTime(0)
    }
  }
  destroy() {
    console.log('destroy player')
    this.player.remove();
    this.el.removeChild(this.playerObj);
  }
}
export {
  AudioPlayer,
  VideoPlayer
}