'use strict';
import * as axios from 'axios';

import {BASE_URL} from '../../config';


function getModel(name) {
	const url = `${BASE_URL}/get-model`;
	return axios.get(url + '/' + name).then(response => {
		return response.data;
	}, error => {
		// error callback
		console.log(error)
		return new Error({
			message: 'Model not found',
			error: error
		})
	});
}
function getGenres() {
	const url = `${BASE_URL}/admin/getgenres`;
	return axios.get(url).then(response => {
		console.log(response.data);
		return response.data;
	}, error => {
		// error callback
		return new Error({
			message: 'Genres model not found',
			error: error
		})
	});
}

function removeGenre() {
	const url = `${BASE_URL}/admin/remove`;
	return axios.get(url).then(response => {
		console.log(response.data);
		return response.data;
	}, error => {
		// error callback
		return new Error({
			message: 'Genres model not found',
			error: error
		})
	});
}


export {
	getModel,
	removeGenre
}
