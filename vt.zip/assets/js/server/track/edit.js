// import * as _ from 'lodash/core';
import pickBy from 'lodash/pickBy';
import differenceBy from 'lodash/differenceBy';
import get from 'lodash/get';
import findIndex from 'lodash/findIndex';
import cloneDeep from 'lodash/cloneDeep';

import {BASE_URL} from '../../config';


import Vue from 'vue';
import * as CollectionService from '../services/collections-service';
import * as TrackService  from '../services/track-service';

let trackApp = new Vue({
  data: {
    remixResult: [],
    ui: new Date().getTime() + Math.floor(Math.random() * 99999),
    editTrack: null,
    newRemix: [],
    track: {},
    loading: null,
    searching: null,
    saved: null,
    nothingRemix: null
  },
  mounted() {
    this.loading = true;
    this.getTrack().then(data => {
      this.loading = false;
      this.track = data;
    }, reason => {
      this.error = reason;
    })
  },
  methods: {
    getTrack() {
      return new Promise((resolve, reject) => {
        if(this._vnode.data.attrs.track) {
          this.loading = true;
          TrackService.getTrack({
            id: this._vnode.data.attrs.track
          }).then(data => {
            resolve(data)
          }, reason => {
            reject(reason)
          })
        }
      })
    },
    searchRemix(track) {
      this.searching = true;
      this.getRemix(track).then(data => {
        this.newRemix = differenceBy(data.remixes, track.remix, 'id');
        this.searching = false;
        // show nothing
        if(!this.newRemix.length) {
          this.nothingRemix = true;
          let self = this;
          setTimeout(() => {
            self.nothingRemix = false;
          }, 1000);
        }
      })
    },
    getRemix(track) {
      // get remix for attachment to new track before upload to server 
      return new Promise((resolve, reject) => {
        if(!track) return reject('Enter valid data');
        let filterParams = {
          or: [
            {
              artist: {
                contains: track.artist
              }
            },
            {
              title: {
                contains: track.title.replace(/(\((clean|dirty)\))$/gi, '').trim()
              }
            }
          ],
          id: {
            '!': track.id
          }
        };
        let ui = new Date().getTime() + Math.floor(Math.random() * 9999);
        TrackService.getTracks({
          search: {
            query: filterParams
          },
          ui: ui
        }).then(responce => {
          resolve({track, remixes: responce.data});
        })
      })
    },
    removeRemix(list, remix) {
      let removedIndex = list.indexOf(remix);
      list.splice(removedIndex, 1);
    },
    resetNewRemix() {
      this.newRemix = [];
    },
    saveTrack() {
      if(this.saved) return;
      this.track.remix = this.track.remix.concat(this.newRemix.slice());
      this.resetNewRemix();
      let tmpObj = Object.assign({}, this.track);
      tmpObj.remix = this.track.remix.map(x => x.id.toString());
      TrackService.update(tmpObj).then(data => {
        console.log(data)
        this.saved = true;
        let self = this;
        setTimeout(function() {
          self.saved = false;
        }, 1000);
      })
    }
  }
})

if(document.getElementById('track-edit')) {
  trackApp.$mount('#track-edit')
}