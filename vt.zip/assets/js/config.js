let BASE_URL = window.location.origin || '';
let dropBoxKey;
// if(process.env.NODE_ENV === 'production') {
//   BASE_URL = window.location.origin;
// }
// else if(process.env.NODE_ENV === 'stage') {
//   BASE_URL = "http://136.243.156.125:1346";
// }
// else {
//   BASE_URL = "http://app.djsite.lo:1338";
// }
export {
  BASE_URL,
  dropBoxKey
}