import Vue from 'vue';
import InfiniteScroll from '../../plugins/infinite-scroll'

Vue.directive('infinitescrollItem', {
	inserted(el, binding, vnode) {
		if(el.parentNode.scrollInst && el == el.parentNode.lastElementChild) {
			el.parentNode.scrollInst.calculateDimensions();
		}
	}
})
export default Vue.directive('infinitescroll', {
	inserted(el, binding, vnode) {
		el.scrollInst = new InfiniteScroll(el, binding.value.options);
		// vnode.context.$watch(binding.value.model, () => {
			// scrollInst.refresh()
		// })
	}
})