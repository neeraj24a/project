import Vue from 'vue';

let filterComponent = Vue.component('genre-filter', {
	template: `
		<li>
      <a class="genre-filter__link" href="#">
        {{ title }}
      </a>
		</li>
	`,
	props: ['title']
});

export {
  filterComponent
}