'use strict';
import * as axios from 'axios';
import {BASE_URL} from '../../config';

const getRemixerFilters = function(updateNeeded) {
  const url = `${BASE_URL}/remixerfilter/json`;
  return axios.get(url).then(response => {
    // get body data
    return response.data;
  }, error => {
    // error callback
    console.log(error);
    return new Error({
      message: 'Remixer not found',
      error: error
    })
  });
}
export {
    getRemixerFilters
}