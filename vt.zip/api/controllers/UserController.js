/**
 * UserController
 *
 * @description :: Server-side logic for managing users
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */
let request = require('request');
let qs = require('querystring')
let loginRequest = (login, pass) => {
  return new Promise((resolve, reject) => {
    let url = `${sails.config.aMember.url}/api/check-access/by-login-pass`;
    let username = login;
    /*if(login.indexOf(' ') >= 0){
	username = login.replace(/ /g,"%20");
    }*/
    console.log(`${url}?_key=${sails.config.aMember.apiKey}&login=${username}&pass=${pass}`);
    console.log(`${sails.config.aMember.url}/api/check-access/by-login-pass` + '?' + qs.stringify({_key: sails.config.aMember.apiKey,login: username,pass:pass}));
    let options = {
      url: `${sails.config.aMember.url}/api/check-access/by-login-pass` + '?' + qs.stringify({_key: sails.config.aMember.apiKey,login: username,pass:pass}),
    };
    let callback = (error, response, body) => {
      console.log("error");
      console.log(error);
      if(!error && response.statusCode) {
        let info = JSON.parse(body);
        if(info.error || !info.ok) {
          reject({error: info});
        }
        else {
          getInfo({ email: info.email, id: info.user_id }).then(data => {
            resolve(data);
          })
          // resolve(info);
        }
      }
      else {
        reject({error: error});
      }
    }
    request.get(options, callback);
  })
}
let getFullInfo =({id}) => {
  return new Promise((resolve, reject) => {
    if(id) {
      /* 
        For example:
        http://example.com/amember/api/users/user_id?_key=APIKEY
      */
      let options = {
        url: `${sails.config.aMember.url}/api/users/${id}/?_key=${sails.config.aMember.apiKey}`
      };
      let callback = (error, response, body) => {
        if(!error && response.statusCode) {
          let info = JSON.parse(body);
          if(info.error) {
            reject({ error: info });
          }
          else {
            resolve(info[0])
          }
        }
        else {
          reject({ error: error })
        }
      }
      request(options, callback);
      return;
    }
    else {
      reject({ error: `This id: ${id} - not found` })
    }
  })
}
let getSimpleInfo = ({email, id}) => {
  return new Promise((resolve, reject) => {
    if(email) {
      /* 
        For example:
        http://example.com/amember/api/check-access/by-email?_key=APIKEY&email=test@example.com
      */
      let options = {
        url: `${sails.config.aMember.url}/api/check-access/by-email/?_key=${sails.config.aMember.apiKey}&email=${email}`
      };
      let callback = (error, response, body) => {
        if(!error && response.statusCode) {
          let info = JSON.parse(body);
          if(info.error) {
            reject({ error: info });
          }
          else {
            resolve(info)
          }
        }
        else {
          reject({ error: error })
        }
      }
      request(options, callback);
      return;
    }
    else {
      reject({ error: `This email: ${email} - not found` })
    }
  })
}
let getInfo = ({email, id}) => {
  let user = {};
  return new Promise((resolve, reject) => {
    let promises = [getSimpleInfo({email, id}), getFullInfo({email, id})];
    Promise.all(promises).then(function(results) {
      results.forEach(item => {
        user = Object.assign(user, item);
      });
      resolve(user);
    }).catch(err => console.log(err));
  })
}
let checkUser = (user) => {
    let product = -1;
    //user.subscriptions[sails.config.aMember.product_id]
    _.each(user.subscriptions, function(s, k){
        product = k;
    });
  if(!user.admin) {
    if(user.is_locked && parseInt(user.is_locked) < 0){
      sails.log('User ' + user.login + ' locked');
      user.isLocked = {
        msg: sails.__('msg_locked'),
        type: 'locked'
      };
    }
    else if(new Date() > new Date(user.subscriptions[product])){
      sails.log('User ' + user.login + ' expired');
      user.isLocked = {
        msg: sails.__('msg_expire'),
        type: 'expire'
      };
    }
    else if(user.subscriptions.hasOwnProperty('length') && !user.subscriptions.length) {
      sails.log('User ' + user.login + ' hasn\'t sub')
      user.isLocked = {
        msg: sails.__('msg_nonesub'),
        type: 'none_sub'
      }
    }
  }
  return user;
}
module.exports = {
  login: function (req, res) {
    // See `api/responses/login.js`
    loginRequest(req.param('name'), req.param('password')).then(data => {
      let user = Object.assign(data, {
        id: data.user_id
      });
      req.session.user = checkUser(user);

      if(req.param('json') || req.isSocket) {
        return res.json(user);
      }
      sails.sockets.blast('login');
      res.redirect(sails.session.redirectdownload ? '/' : (req.param('returnto') || '/'))
    }, reason => {
      req.session.flash = reason;
      if(req.param('json') || req.isSocket) {
        return res.json(reason);
      }
      res.redirect('/login');
    });
  },
  logout: function (req, res) {
    //sails.sockets.blast('logout.' + req.session.user.id)
    req.session.user = null;
    if (req.wantsJSON) {
      return res.ok('Logged out successfully!');
    }
    // Otherwise if this is an HTML-wanting browser, do a redirect.
    return res.redirect('/');
  },
  info: function(req, res) {
    if(!req.session.user) {
      if(req.param('json') || req.isSocket) {
        return res.json({error: sails.__('msg_nonelogin')});
      }
      return res.serverError(sails.__('msg_nonelogin'));
    }
    getInfo({ email: req.session.user.email, id: req.session.user.user_id }).then(data => {
      let user = checkUser(Object.assign(data, {
        id: data.user_id
      }));
      if(req.param('json') || req.isSocket) {
        res.json(user)
      }
      else {
        res.view('admin/user/show', {
          user: user
        })
      }
    }, reason => {
      req.session.flash = reason;
      if(req.param('json') || req.isSocket) {
        return res.json(reason);
      }
      res.redirect('/login');
    })
  }
};
