/**
 * ThemeController
 *
 * @description :: Server-side logic for managing files
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */
module.exports = {
  toggle: function (req, res) {
    let params = req.params.all();
    let tmpObj = {};
    let existedTheme = sails.models.cms.definition.theme.enum;
    let index = 0;

    if(params.theme && existedTheme.indexOf(params.theme) != -1) {
      tmpObj.theme = sails.models.cms.definition.theme.enum[existedTheme.indexOf(params.theme)];
    }
    else {
      params.theme = req.session.theme || sails.session.settings.theme;
      index = existedTheme.indexOf(params.theme);
      
      if(index == -1) index = 0;
      if(existedTheme[index]) index++;
      if(index > existedTheme.length - 1) index = 0;

      tmpObj.theme = sails.models.cms.definition.theme.enum[index];

      if(existedTheme.length > 1) {
        let nextTheme = sails.models.cms.definition.theme.enum[index < existedTheme.length - 1 ? index + 1 : 0];
        tmpObj.nextTheme = nextTheme;
      }
    }
    req.session.theme = tmpObj.theme;
    req.session.nextTheme = tmpObj.nextTheme;

    if(params.json || req.isSocket) {
      res.json(tmpObj);
    }
    else {
      // res.redirect(req.header('Referer') || '');
      return res.redirect('back');;
    }
  }
};
