/**
 * isSubscribed
 *
 * @module      :: Policy
 * @description :: Simple policy to allow sibscribed user
 * @docs        :: http://sailsjs.org/#!documentation/policies
 *
 */
module.exports = function(req, res, next) {
  if(!req.session.user || !req.session.user.id) {
    return res.redirect('login');
  }
  Subscriptions.check(req.session.user).then(function(data) {
    return next();
  }, function(data) {
    if(sails.config.aMember.paymentPage) {
      if(req.isSocket || req.param('json')) {
        return res.json({
          error: true,
          redirect: sails.config.aMember.paymentPage,
          message: `${data.message}`
        })
      }
      return res.redirect(sails.config.aMember.paymentPage)
      // return res.serverError(data.message)
    }
    if(req.isSocket || req.param('json')) {
      return res.json({
        error: true,
        message: data.message
      })
    }
    return res.serverError(data.message);
  });
};