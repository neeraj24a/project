/**
 * Genrefilter.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    title: {
      type: 'string'
    },
    subfilter: {
      type: 'boolean',
      defaultsTo: false
    },
    key: {
      type: 'string',
      unique: true
    },
    toJSON: function() {
        var obj = this.toObject();
        delete obj.token;
        delete obj._csrf;
        return obj;
    }
  },
  beforeValidate: (values, next) => {
    values.subfilter = values.subfilter ? true : false;
    next();
  },
  beforeCreate: (values, next) => {
    values.subfilter = values.subfilter ? true : false;
    next();
  }
};

