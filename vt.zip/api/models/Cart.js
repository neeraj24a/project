/**
 * Cart.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */
let moment = require('moment');
module.exports = {
    attributes: {
      track: {
        type: 'integer',
      },
      user: {
        type: 'integer',
        defaultsTo: null,
      },
      createdAt: {
        type: 'date',
        defaultsTo: function() {
          return moment().format("YYYY-MM-DD")
          // return new Date();
        }
      },
      updatedAt: {
        type: 'date',
        defaultsTo: function() {
          return moment().format("YYYY-MM-DD")
          // return new Date();
        }
      },
      toJSON: function() {
          var obj = this.toObject();
          delete obj.token;
          delete obj._csrf;
          return obj;
      }
    },
    beforeValidate: (values, next) => {
      values.type = values.type ? true : false;
      next();
    },
    beforeCreate: (values, next) => {
      values.type = values.type ? true : false;
      next();
    }
  };
