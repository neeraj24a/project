/**
 * Cms.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    theme: {
      type: 'string',
      enum: ['color-theme-2', 'color-theme-1'],
      defaultsTo: 'color-theme-2'
    },
    previewAudio: {
      type: 'integer',
      defaultsTo: 20
    },
    previewVideo: {
      type: 'integer',
      defaultsTo: 20
    },
    trackPerPage: {
      type: 'integer',
      defaultsTo: 50
    },
    cartSize: {
      type: 'integer',
      defaultsTo: 50
    },
    toJSON: function() {
        var obj = this.toObject();
        delete obj.token;
        delete obj._csrf;
        return obj;
    }
  },
  beforeUpdate: function(values, next) {
    values.previewAudio = Math.max(5, Math.min(values.previewAudio, 100));
    values.previewVideo = Math.max(5, Math.min(values.previewVideo, 100));
    values.trackPerPage = Math.max(1, values.trackPerPage);
    values.cartSize = Math.max(50, values.cartSize);
    

    if(values.showingmodels && typeof values.showingmodels == 'string') {
      values.showingmodels = values.showingmodels.split(',').map((item) => {
        return item.trim();
      });
    }
    next();
  }
};

