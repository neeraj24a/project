-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 29, 2017 at 07:54 PM
-- Server version: 5.5.54-0+deb8u1
-- PHP Version: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ministore_template`
--

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
`id` int(10) unsigned NOT NULL,
  `hash` char(128) DEFAULT NULL,
  `items` text,
  `shipping_address` text,
  `payment_info` text COMMENT 'Json of payment info',
  `status` varchar(255) DEFAULT NULL COMMENT 'Order status:  1) Pending-Shipping 2)Shipped 3)Completed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `hash`, `items`, `shipping_address`, `payment_info`, `status`, `created_at`) VALUES
(51, '597ccb9a14b3d', '[{"name":"Clita","quantity":"4","price":"200","currency":"EUR"},{"name":"Mero","quantity":"2","price":"250","currency":"EUR"}]', '{"recipient_name":"John Brucker","email":"test@gmail.com","line1":"Walterstr.","line2":"34","city":"Vienna","country_code":"AQ","postal_code":"20111","phone":"+4827271727"}', '{"payment_method":"credit_card","total":"1303.99","subtotal":"1300","shipping":"3.99","stripeToken":"tok_1Akz7yBNn2c83d0IisfNR3x2","stripeEmail":"test@gmail.com","stripeChargeResponse":{"id":"ch_1Akz81BNn2c83d0IZFpwGayq","object":"charge","amount":130399,"amount_refunded":0,"application":null,"application_fee":null,"balance_transaction":"txn_1Akz81BNn2c83d0IyYEdwHiE","captured":true,"created":1501350809,"currency":"eur","customer":null,"description":"test@gmail.com","destination":null,"dispute":null,"failure_code":null,"failure_message":null,"fraud_details":[],"invoice":null,"livemode":false,"metadata":{"stripeEmail":"test@gmail.com","recipient_name":"John Brucker","email":"test@gmail.com","line1":"Walterstr.","line2":"34","city":"Vienna","country_code":"AQ","postal_code":"20111","phone":"+4827271727"},"on_behalf_of":null,"order":null,"outcome":{"network_status":"approved_by_network","reason":null,"risk_level":"normal","seller_message":"Payment complete.","type":"authorized"},"paid":true,"receipt_email":null,"receipt_number":null,"refunded":false,"refunds":{"object":"list","data":[],"has_more":false,"total_count":0,"url":"\\/v1\\/charges\\/ch_1Akz81BNn2c83d0IZFpwGayq\\/refunds"},"review":null,"shipping":null,"source":{"id":"card_1Akz7yBNn2c83d0IEc4qmJI8","object":"card","address_city":null,"address_country":null,"address_line1":null,"address_line1_check":null,"address_line2":null,"address_state":null,"address_zip":null,"address_zip_check":null,"brand":"Visa","country":"US","customer":null,"cvc_check":"pass","dynamic_last4":null,"exp_month":2,"exp_year":2022,"fingerprint":"m3mR3nBiCQwu3m64","funding":"credit","last4":"0077","metadata":[],"name":"test@gmail.com","tokenization_method":null},"source_transfer":null,"statement_descriptor":null,"status":"succeeded","transfer_group":null}}', NULL, '2017-07-29 17:53:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order`
--
ALTER TABLE `order`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `hash` (`hash`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=52;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
