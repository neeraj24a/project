<div class="content-wrapper">
    <h3>Company Facilities</h3>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php 
                        $model->company = Companies::model()->findByPk($model->company)->name; 
                        pre($model->company, true);
                    ?>
                    <?php $model->facility = Facilities::model()->findByPk($model->facility)->name; ?>
                    <?php //$model->type = getParam('facility_type')[$model->type]; ?>
                    <?php echo $model->company; ?>
                    <div class="col-lg-2 pull-right">
                        <a href="<?php echo Yii::app()->createUrl("admin/cFacilities/update?id=" . $model->id); ?>" class="mb-sm btn btn-warning">Update</a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <?php
                        $this->widget('zii.widgets.CDetailView', array(
                            'data' => $model,
                            'htmlOptions' => array('class' => 'table table-striped table-bordered table-hover'),
                            'attributes' => array(
                                'company',
                                'facility',
                                'type',
                            ),
                        ));
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>