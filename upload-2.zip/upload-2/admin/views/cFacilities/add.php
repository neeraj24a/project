<div class="content-wrapper">
    <h3>Add Existing Facility For <?php echo $company_name; ?></h3>
    <div class="row">
        <div class="col-sm-12">
            <?php $this->renderPartial('_add', array('model'=>$model)); ?>
        </div>
    </div>
</div>