<?php
/* @var $this FacilityInspectorController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Facility Inspectors',
);

$this->menu=array(
	array('label'=>'Create FacilityInspector', 'url'=>array('create')),
	array('label'=>'Manage FacilityInspector', 'url'=>array('admin')),
);
?>

<h1>Facility Inspectors</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
