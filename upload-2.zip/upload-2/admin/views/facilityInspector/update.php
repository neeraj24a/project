<div class="content-wrapper">
    <h3>Update Facility Inspector</h3>
    <div class="row">
        <div class="col-sm-12">
            <?php $this->renderPartial('_add', array('model'=>$model)); ?>
        </div>
    </div>
</div>