<?php
/* @var $this FacilityInspectorController */
/* @var $model FacilityInspector */

$this->breadcrumbs=array(
	'Facility Inspectors'=>array('index'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List FacilityInspector', 'url'=>array('index')),
	array('label'=>'Create FacilityInspector', 'url'=>array('create')),
	array('label'=>'Update FacilityInspector', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete FacilityInspector', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage FacilityInspector', 'url'=>array('admin')),
);
?>

<h1>View FacilityInspector #<?php echo $model->id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id',
		'facility_id',
		'inspector_id',
		'status',
		'deleted',
		'created_by',
		'modified_by',
		'date_entered',
		'date_modified',
	),
)); ?>
