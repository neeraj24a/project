<?php
/* @var $this FacilityInspectorController */
/* @var $model FacilityInspector */
/* @var $form CActiveForm */
?>
<div class="panel panel-default">
    <div class="panel-heading">Facility Addition Form</div>
    <div class="panel-body">
        <div class="row">
        <?php $form=$this->beginWidget('CActiveForm', array(
            'id'=>'facilityInspector-form',
            // Please note: When you enable ajax validation, make sure the corresponding
            // controller action is handling ajax validation correctly.
            // There is a call to performAjaxValidation() commented in generated controller code.
            // See class documentation of CActiveForm for details on this.
//            'enableAjaxValidation'=>true,
			)); ?>
			<div class="col-lg-12">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model,'facility_id'); ?>
                                    <?php
                                        $facilities = Facilities::model()->findAll();
                                        $list = CHtml::listData($facilities, 'id', 'name');
                                    ?>
                                    <?php echo $form->dropDownList($model,'facility_id',$list,array('empty'=>'Select Facility','class'=>'form-control')); ?>
                                    <?php echo $form->error($model,'facility_id'); ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model,'inspector_id'); ?>
									<?php
                                        $inspectors = Inspectors::model()->findAll();
                                        $list = CHtml::listData($inspectors, 'id', 'first_name');
                                    ?>
                                    <?php echo $form->dropDownList($model,'inspector_id', $list,array('empty' => 'Select Inspector','class'=>'form-control')); ?>
                                    <?php echo $form->error($model,'inspector_id'); ?>
                                </div>
                            </div>
			</div>
                        <div class="col-lg-12 m-t-20">
                            <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save',array('class' => 'mb-sm btn btn-info')); ?>
                            <a href="<?php echo Yii::app()->user->returnUrl; ?>" class="mb-sm btn btn-warning pull-right">Back</a>
                        </div>
            <?php $this->endWidget(); ?>
        </div>
    </div>
</div>