<div class="block-center mt-xl wd-xl">
    <!-- START panel-->
    <div class="panel panel-dark panel-flat">
        <div class="panel-heading text-center">
            <a href="#">
                <img class="block-center img-rounded" src="img/logo.png" alt="Image">
            </a>
        </div>
        <div class="panel-body">
            <p class="text-center pv">PASSWORD RESET</p>
            <?php
            $form = $this->beginWidget('CActiveForm', array(
                'id' => 'login-form',
                'enableClientValidation' => true,
                'clientOptions' => array(
                    'validateOnSubmit' => true,
                ),
                'htmlOptions' => array(
                    'autcomplete' => "off",
                    'class' => 'mb-lg',
                    'role' => 'form'
                ),
            ));
            ?>
                <p class="text-center">Choose Your New Password.</p>
                <div class="form-group has-feedback">
                    <?php echo $form->labelEx($model,'password',array("class" => "text-muted")); ?>
                    <?php echo $form->passwordField($model, 'password', array('class' => 'form-control', 'placeholder' => 'Enter Password')); ?>
                    <span class="fa fa-lock form-control-feedback text-muted"></span>
                    <?php echo $form->error($model,'password'); ?>
                </div>
                <div class="form-group has-feedback">
                    <?php echo $form->labelEx($model,'repeatPassword',array("class" => "text-muted")); ?>
                    <?php echo $form->passwordField($model, 'repeatPassword', array('class' => 'form-control', 'placeholder' => 'Re Enter Password')); ?>
                    <span class="fa fa-lock form-control-feedback text-muted"></span>
                    <?php echo $form->error($model,'repeatPassword'); ?>
                </div>
                <button class="btn btn-danger btn-block" type="submit">Reset</button>
            <?php $this->endWidget(); ?>
        </div>
    </div>
</div>