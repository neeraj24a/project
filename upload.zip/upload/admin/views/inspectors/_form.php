<?php
/* @var $this InspectorsController */
/* @var $model Inspectors */
/* @var $form CActiveForm */
?>
<div class="panel panel-default">
    <div class="panel-heading">Inspector Addition Form</div>
    <div class="panel-body">
        <div class="row">
        <?php $form=$this->beginWidget('CActiveForm', array(
            'id'=>'inspectors-form',
            // Please note: When you enable ajax validation, make sure the corresponding
            // controller action is handling ajax validation correctly.
            // There is a call to performAjaxValidation() commented in generated controller code.
            // See class documentation of CActiveForm for details on this.
        //    'enableAjaxValidation'=>true,
        )); ?>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'first_name'); ?>
                    <?php echo $form->textField($model,'first_name',array('size'=>60,'maxlength'=>256,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'first_name'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'last_name'); ?>
                    <?php echo $form->textField($model,'last_name',array('size'=>60,'maxlength'=>256,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'last_name'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'web_enabled'); ?>
                    <?php echo $form->dropDownList($model,'web_enabled',array("0" => 'No',"1" => 'Yes'),array("empty" => "Select","class"=>'form-control')); ?>
                    <?php echo $form->error($model,'web_enabled'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'email'); ?>
                    <?php echo $form->textField($model,'email',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'email'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'phone'); ?>
                    <?php echo $form->textField($model,'phone',array('size'=>60,'maxlength'=>12,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'phone'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'phone2'); ?>
                    <?php echo $form->textField($model,'phone2',array('size'=>60,'maxlength'=>12,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'phone2'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-12">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'address'); ?>
                    <?php echo $form->textField($model,'address',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'address'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'city'); ?>
                    <?php echo $form->textField($model,'city',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'city'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'state'); ?>
                    <?php echo $form->textField($model,'state',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'state'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'country'); ?>
                    <?php echo $form->textField($model,'country',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'country'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'zip'); ?>
                    <?php echo $form->textField($model,'zip',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'zip'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'org'); ?>
                    <?php echo $form->textField($model,'org',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'org'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'url'); ?>
                    <?php echo $form->textField($model,'url',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'url'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'semi'); ?>
                    <?php echo $form->dropDownList($model,'semi',array("0" => 'No',"1" => 'Yes'),array("empty" => "Select",'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'semi'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'semi_from'); ?>
                    <?php echo $form->textField($model,'semi_from',array("size" => 60,"maxlength" => "255",'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'semi_from'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-4">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'prev_agency'); ?>
                    <?php echo $form->textField($model,'prev_agency',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'prev_agency'); ?>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'prev_positions'); ?>
                    <?php echo $form->textField($model,'prev_positions',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'prev_positions'); ?>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'prev_years'); ?>
                    <?php echo $form->textField($model,'prev_years',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'prev_years'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'curr_employed'); ?>
                    <?php echo $form->dropDownList($model,'curr_employed',array("0" => 'No',"1" => 'Yes'),array("empty" => "Select",'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'curr_employed'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'curr_employer'); ?>
                    <?php echo $form->textField($model,'curr_employer',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'curr_employer'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'reg_travel_states'); ?>
                    <?php echo $form->textField($model,'reg_travel_states',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'reg_travel_states'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'reg_travel_countries'); ?>
                    <?php echo $form->textField($model,'reg_travel_countries',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'reg_travel_countries'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'expertise'); ?>
                    <?php echo $form->textField($model,'expertise',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'expertise'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'acct_name'); ?>
                    <?php echo $form->textField($model,'acct_name',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'acct_name'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'acct_num'); ?>
                    <?php echo $form->textField($model,'acct_num',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'acct_num'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'bank_name'); ?>
                    <?php echo $form->textField($model,'bank_name',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'bank_name'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'bank_address'); ?>
                    <?php echo $form->textField($model,'bank_address',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'bank_address'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'swift'); ?>
                    <?php echo $form->textField($model,'swift',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'swift'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'bic'); ?>
                    <?php echo $form->textField($model,'bic',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'bic'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'routing'); ?>
                    <?php echo $form->textField($model,'routing',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'routing'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'special_inst'); ?>
                    <?php echo $form->textField($model,'special_inst',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'special_inst'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'route'); ?>
                    <?php echo $form->textField($model,'route',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'route'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'assignments'); ?>
                    <?php echo $form->textField($model,'assignments',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'assignments'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <?php echo $form->labelEx($model,'notes'); ?>
                    <?php echo $form->textField($model,'notes',array('size'=>60,'maxlength'=>255,'class'=>'form-control')); ?>
                    <?php echo $form->error($model,'notes'); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12 m-t-20">
            <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save',array('class' => 'mb-sm btn btn-info')); ?>
            <a href="<?php echo Yii::app()->createUrl("admin/inspectors"); ?>" class="mb-sm btn btn-warning pull-right">Back</a>
        </div>
        <?php $this->endWidget(); ?>
        </div>
    </div>
</div>