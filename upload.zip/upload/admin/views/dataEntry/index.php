<?php
/* @var $this DataEntryController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Data Entries',
);

$this->menu=array(
	array('label'=>'Create DataEntry', 'url'=>array('create')),
	array('label'=>'Manage DataEntry', 'url'=>array('admin')),
);
?>

<h1>Data Entries</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
