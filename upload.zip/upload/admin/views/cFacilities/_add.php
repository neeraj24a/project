<?php
/* @var $this CompaniesController */
/* @var $model Companies */
/* @var $form CActiveForm */
?>
<div class="panel panel-default">
    <div class="panel-heading">Facility Addition Form</div>
    <div class="panel-body">
        <div class="row">
        <?php $form=$this->beginWidget('CActiveForm', array(
            'id'=>'cFacilities-form',
            // Please note: When you enable ajax validation, make sure the corresponding
            // controller action is handling ajax validation correctly.
            // There is a call to performAjaxValidation() commented in generated controller code.
            // See class documentation of CActiveForm for details on this.
//            'enableAjaxValidation'=>true,
			)); ?>
			<div class="col-lg-12">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model,'facility'); ?>
                                    <?php
                                        $facilities = Facilities::model()->findAll();
                                        $list = CHtml::listData($facilities, 'id', 'name');
                                    ?>
                                    <?php echo $form->dropDownList($model,'facility',$list,array('empty'=>'Select Facility','class'=>'form-control')); ?>
                                    <?php echo $form->hiddenField($model,'company',array('value'=>$_GET['company'],'class'=>'form-control')); ?>
                                    <?php echo $form->error($model,'facility'); ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model,'type'); ?>
                                    <?php echo $form->dropDownList($model,'type', getParam('facility_type'),array('empty' => 'Select Type','class'=>'form-control')); ?>
                                    <?php echo $form->error($model,'type'); ?>
                                </div>
                            </div>
			</div>
                        <div class="col-lg-12 m-t-20">
                            <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save',array('class' => 'mb-sm btn btn-info')); ?>
                            <a href="<?php echo Yii::app()->createUrl("admin/facilities"); ?>" class="mb-sm btn btn-warning pull-right">Back</a>
                        </div>
            <?php $this->endWidget(); ?>
        </div>
    </div>
</div>