<div class="content-wrapper">
    <h3>Add Contact</h3>
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">Company Addition Form</div>
                <div class="panel-body">
                    <div class="row">
                        <?php
                        $form = $this->beginWidget('CActiveForm', array(
                            'id' => 'contacts-form',
                            // Please note: When you enable ajax validation, make sure the corresponding
                            // controller action is handling ajax validation correctly.
                            // There is a call to performAjaxValidation() commented in generated controller code.
                            // See class documentation of CActiveForm for details on this.
                            //'enableAjaxValidation' => true,
                        ));
                        ?>
                        <div class="col-lg-12">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model, 'first_name'); ?>
                                    <?php echo $form->textField($model, 'first_name', array('size' => 60, 'maxlength' => 128, 'class' => 'form-control')); ?>
                                    <?php echo $form->error($model, 'first_name'); ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model, 'last_name'); ?>
                                    <?php echo $form->textField($model, 'last_name', array('size' => 60, 'maxlength' => 128, 'class' => 'form-control')); ?>
                                    <?php echo $form->error($model, 'last_name'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model, 'email'); ?>
                                    <?php echo $form->textField($model, 'email', array('size' => 60, 'maxlength' => 128, 'class' => 'form-control')); ?>
                                    <?php echo $form->error($model, 'email'); ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model, 'role'); ?>
                                    <?php echo $form->dropDownList($model, 'role', array('general' => 'General', 'kosher' => 'Kosher'), array('empty' => 'Select Role', 'class' => 'form-control')); ?>
                                    <?php echo $form->error($model, 'role'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model, 'mobile'); ?>
                                    <?php echo $form->textField($model, 'mobile', array('size' => 60, 'maxlength' => 128, 'class' => 'form-control')); ?>
                                    <?php echo $form->error($model, 'mobile'); ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model, 'office'); ?>
                                    <?php echo $form->textField($model, 'office', array('size' => 60, 'maxlength' => 128, 'class' => 'form-control')); ?>
                                    <?php echo $form->error($model, 'office'); ?>
                                </div>
                            </div>
                        </div>
                        <?php echo $form->hiddenField($model, 'type', array('value' => 'facility')); ?>
                        <?php echo $form->hiddenField($model, 'link_id', array('value' => $facility)); ?>
                        <div class="col-lg-12">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <?php echo $form->labelEx($model, 'comments'); ?>
                                    <?php echo $form->textArea($model, 'comments', array('class' => 'form-control')); ?>
                                    <?php echo $form->error($model, 'comments'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 m-t-20">
                        <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save', array('class' => 'mb-sm btn btn-info')); ?>
                            <a href="<?php echo Yii::app()->createUrl("admin/companies"); ?>" class="mb-sm btn btn-warning pull-right">Back</a>
                        </div>
                        <?php $this->endWidget(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>