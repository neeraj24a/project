<div class="row">

    <?php
    $form = $this->beginWidget('CActiveForm', array(
        'action' => Yii::app()->createUrl($this->route),
        'method' => 'get',
    ));
    ?>
	<div class="col-lg-12">
		<div class="col-lg-3">
                    <?php echo $form->labelEx($model,'company_id'); ?>
                    <?php 
                        $mod = Companies::model()->findAll(); 
                        $list = CHtml::listData($mod, 'id', 'name');
                    ?>
                    <?php echo $form->dropDownList($model,'company_id',$list,
                        array('empty'=>'Select Company','class'=>'form-control', 'ajax' => array(
                                    'type'=>'POST', //request type
                                    'url'=>CController::createUrl('inspections/loadfacility'), //url to call.
                                    'data'=>array('company'=>'js:this.value'),
                                    'update'=>'#Inspections_facility_id', //selector to update
                                    )
                            )
                    ); ?>
		</div>
		<div class="col-lg-3">
                    <?php echo $form->labelEx($model,'facility_id'); ?>
                    <?php echo $form->dropDownList($model,'facility_id',array(),array('empty'=>'Select Facility','class'=>'form-control')); ?>
		</div>
		<div class="col-lg-3">
                    <?php echo $form->labelEx($model,'inspector'); ?>
                    <?php 
                        $ins = Inspectors::model()->findAll(); 
                        $i = CHtml::listData($ins, 'id', 'first_name');
                    ?>
                    <?php echo $form->dropDownList($model,'inspector',$i,array('empty'=>'Select Inspector','class'=>'form-control')); ?>
		</div>
                <div class="col-lg-3">
                    <?php echo $form->labelEx($model,'insp_date'); ?>
                    <?php 
                        $this->widget('zii.widgets.jui.CJuiDatePicker', array(
                            'model' => $model,
                            'attribute' => 'insp_date',
                            'options' => array(
                                'dateFormat' => 'yy-mm-dd',     // format of "2012-12-25"
                                'showOtherMonths' => true,      // show dates in other months
                                'selectOtherMonths' => true,    // can seelect dates in other months
                                'changeYear' => true,           // can change year
                                'changeMonth' => true,          // can change month
                            ),
                            'htmlOptions' => array(
                                'class'=>'form-control'    // textField maxlength
                            ),
                        ));
                    ?>
		</div>
	</div>
        <div class="col-lg-12 m-t-20">
            <?php echo CHtml::submitButton('Search', array('class' => 'mb-sm btn btn-success')); ?>
            <a href="<?php echo Yii::app()->createUrl('admin/inspections'); ?>" class="mb-sm btn btn-warning">Reset</a>
        </div>
    <?php $this->endWidget(); ?>
</div>