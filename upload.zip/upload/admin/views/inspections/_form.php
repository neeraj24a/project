<div class="panel panel-default">
    <div class="panel-heading">Inspection Addition Form</div>
    <div class="panel-body">
        <div class="row">
        <?php $form=$this->beginWidget('CActiveForm', array(
            'id'=>'inspections-form',
            // Please note: When you enable ajax validation, make sure the corresponding
            // controller action is handling ajax validation correctly.
            // There is a call to performAjaxValidation() commented in generated controller code.
            // See class documentation of CActiveForm for details on this.
            // 'enableAjaxValidation'=>true,
            'htmlOptions' => array('enctype' => 'multipart/form-data'),
            )); ?>
                <div class="col-lg-12">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'company_id'); ?>
                            <?php 
                                $mod = Companies::model()->findAll(); 
                                $list = CHtml::listData($mod, 'id', 'name');
                            ?>
                            <?php echo $form->dropDownList($model,'company_id',$list,
                                    array('empty'=>'Select Company','class'=>'form-control', 'ajax' => array(
						'type'=>'POST', //request type
						'url'=>CController::createUrl('inspections/loadfacility'), //url to call.
						'data'=>array('company'=>'js:this.value'),
						'update'=>'#Inspections_facility_id', //selector to update
						))); ?>
                            <?php echo $form->error($model,'company_id'); ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'facility_id'); ?>
                            <?php echo $form->dropDownList($model,'facility_id',array(),array('empty'=>'Select Facility','class'=>'form-control')); ?>
                            <?php echo $form->error($model,'facility_id'); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'inspector'); ?>
                            <?php 
                                $mod = Inspectors::model()->findAll(); 
                                $list = CHtml::listData($mod, 'id', 'first_name');
                            ?>
                            <?php echo $form->dropDownList($model,'inspector',$list,array('empty'=>'Select Inspector','class'=>'form-control')); ?>
                            <?php echo $form->error($model,'inspector'); ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'insp_date'); ?>
                            <?php 
                                $this->widget('zii.widgets.jui.CJuiDatePicker', array(
                                    'model' => $model,
                                    'attribute' => 'insp_date',
                                    'options' => array(
                                        'dateFormat' => 'yy-mm-dd',     // format of "2012-12-25"
                                        'showOtherMonths' => true,      // show dates in other months
                                        'selectOtherMonths' => true,    // can seelect dates in other months
                                        'changeYear' => true,           // can change year
                                        'changeMonth' => true,          // can change month
                                    ),
                                    'htmlOptions' => array(
                                        'class'=>'form-control'    // textField maxlength
                                    ),
                                ));
                            ?>
                            <?php echo $form->error($model,'insp_date'); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'issues'); ?>
                            <?php echo $form->dropDownList($model,'issues',array('0' => 'No','1' => 'Yes'),array('empty'=>'Select','class'=>'form-control')); ?>
                            <?php echo $form->error($model,'issues'); ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'resolved_status'); ?>
                            <?php echo $form->dropDownList($model,'resolved_status',array('open' => 'Open','resolved' => 'Resolved'),
                                    array('empty'=>'Select','class'=>'form-control')); ?>
                            <?php echo $form->error($model,'resolved_status'); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'report'); ?>
                            <?php echo $form->textArea($model,'report',array('class'=>'form-control')); ?>
                            <?php echo $form->error($model,'report'); ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'notes'); ?>
                            <?php echo $form->textArea($model,'notes',array('class'=>'form-control')); ?>
                            <?php echo $form->error($model,'notes'); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'attachment'); ?>
                            <?php echo $form->fileField($model,'attachment',array('class'=>'form-control')); ?>
                            <?php echo $form->error($model,'attachment'); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'special'); ?>
                            <?php echo $form->textField($model,'special',array('class'=>'form-control')); ?>
                            <?php echo $form->error($model,'special'); ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo $form->labelEx($model,'initial'); ?>
                            <?php echo $form->dropDownList($model,'initial',array('0' => 'No','1' => 'Yes'),array('empty'=>'Select','class'=>'form-control')); ?>
                            <?php echo $form->error($model,'initial'); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 m-t-20">
                    <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save',array('class' => 'mb-sm btn btn-info')); ?>
                    <a href="<?php echo Yii::app()->createUrl("admin/inspections"); ?>" class="mb-sm btn btn-warning pull-right">Back</a>
                </div>
            <?php $this->endWidget(); ?>
        </div>
    </div>
</div>
<?php if(isset($model->company_id)): ?>
<script>

/*<![CDATA[*/
jQuery(function($) {
    jQuery.ajax({
        'type':'POST',
        'url':'<?php echo Yii::app()->createUrl('/admin/inspections/loadfacility'); ?>',
        'data':{'company':'<?php echo $model->company_id; ?>'},
        'cache':false,
        'success':function(html){
            jQuery("#Inspections_facility_id").html(html)
            jQuery("#Inspections_facility_id").val('<?php echo $model->facility_id; ?>');
        }});
});
/*]]>*/
</script>
<?php endif; ?>