/**
 * Production environment settings
 *
 * This file can include shared settings for a production environment,
 * such as API keys or remote database passwords.  If you're using
 * a version control solution for your Sails app, this file will
 * be committed to your repository unless you add it to your .gitignore
 * file.  If your repository will be publicly viewable, don't add
 * any private information to this file!
 *
 */

module.exports = {

  /***************************************************************************
   * Set the default database connection for models in the production        *
   * environment (see config/connections.js and config/models.js )           *
   ***************************************************************************/

  // models: {
  //   connection: 'localMySql'
  // },
  // models: {
  //   connection: 'remoteMySql'
  // },
  // models: {
  //  connection: 'localDiskDb'
  //},
  models: {
    connection: 'remoteMySql'
  },
  /***************************************************************************
   * Set the port in the production environment to 80                        *
   ***************************************************************************/
  environment: 'production',
  migrate: 'safe',
  hookTimeout: 1000000,
  port: 80,
  // dropbox settings
  dropbox: {
    key: 'your_dropbox_apikey' // https://www.dropbox.com/developers/apps/create
  },
  // amember settings
  aMember: {
    apiKey: 'oHuRIBCUZsAuMvp2qYwa',
    url: 'http://videotoolz20.com/amember_new',
    paymentPage: 'http://videotoolz20.com/amember_new/signup',
    product_id: 2
  },
  // amazon s3 bucket settings
  s3upload: {
    bucket: 'videotoolzaudio',
    key: 'AKIAJDGJID7SHB4YTYFQ',
    secret: 'KwXmHwVwunYoWSfrjDvKkeih1PmO6mIkO19m9Vnc'
  },
  // email sender settings
  email: {
    testMode: false,
    service: 'gmail',
    auth: {
      user: 'your_email@gmail.com',
      pass: 'your_pass'
    },
    from: 'videotoolz.com',
    to: 'your_email@gmail.com'
  },
  defaultSettings: {
    theme: 'color-theme-2',
    previewAudio: 20,
    previewVideo: 20,
    trackPerPage: 50,
    cartSize: 50
  },
  /***************************************************************************
   * Set the log level in production environment to "silent"                 *
   ***************************************************************************/
  log: {
    level: "silly"
  }
};
