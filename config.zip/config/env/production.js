/**
 * Production environment settings
 *
 * This file can include shared settings for a production environment,
 * such as API keys or remote database passwords.  If you're using
 * a version control solution for your Sails app, this file will
 * be committed to your repository unless you add it to your .gitignore
 * file.  If your repository will be publicly viewable, don't add
 * any private information to this file!
 *
 */

module.exports = {

  /***************************************************************************
   * Set the default database connection for models in the production        *
   * environment (see config/connections.js and config/models.js )           *
   ***************************************************************************/

   models: {
     connection: 'localMySql'
   },
  // models: {
  //   connection: 'remoteMySql'
  // },
  // models: {
  //  connection: 'localDiskDb'
  //},
 // models: {
   // connection: 'remoteMySql'
  //},
  /***************************************************************************
   * Set the port in the production environment to 80                        *
   ***************************************************************************/
  environment: 'production',
  migrate: 'safe',
  hookTimeout: 1000000,
  port: 1338,
  // dropbox settings
  dropbox: {
    key: 'lzccioq8a737x01' // https://www.dropbox.com/developers/apps/create
  },
  // amember settings
  aMember: {
    //apiKey: 'j7AwvVHxQAGip1ayckoj',
    apiKey: '5XAcMA4i3crPhaoUkQMD',
    url: 'https://www.8thwonderpromos.com/amember',
    paymentPage: 'https://www.8thwonderpromos.com/amember/signup',
    product_id: 2
  },
  // amazon s3 bucket settings
  s3upload: {
    bucket: '8thwonderpromos',
    //bucket: 'test-videotoolz',
    //key: 'AKIAJDGJID7SHB4YTYFQ',
    key: 'AKIAI3O3BW7XYKHKLOKA',
    secret: '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'
    //secret: 'KwXmHwVwunYoWSfrjDvKkeih1PmO6mIkO19m9Vnc'
  },
  // email sender settings
  email: {
    testMode: false,
    service: 'Gmail',
    auth: {
      user: '8thwonderpromos@gmail.com',
      pass: '19283746'
    },
    from: 'support@8thwonderpromos.com',
    to: 'support@8thwonderpromos.com',
    techTo: 'neeraj24a@gmail.com'
    // to: 'neeraj24a@gmail.com'
  },
  defaultSettings: {
    theme: 'color-theme-2',
    previewAudio: 20,
    previewVideo: 20,
    trackPerPage: 50,
    cartSize: 500
  },
  /***************************************************************************
   * Set the log level in production environment to "silent"                 *
   ***************************************************************************/
  log: {
    level: "silly"
  }
};
