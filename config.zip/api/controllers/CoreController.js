/**
 * CoreController
 *
 * @description :: Server-side logic for managing cores
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	model: (req, res) => {
    let name = req.param('name');
    if(!name) {
      return res.json({
        message: 'Name is not valid'
      });
    }
    if(!sails.models[name]) {
      return res.json({
        message: 'Model is not exist'
      });
    }
    let modelSchema = _.clone(sails.models[name]._attributes);
    
    delete modelSchema.id;
    delete modelSchema.createdAt;
    delete modelSchema.updatedAt;
    delete modelSchema.token;
    delete modelSchema._csrf;

    return res.json(modelSchema);
  },
  config: (req, res) => {
    console.log(req.param('setting'))
    let setting = req.param('setting');
    return res.json(setting && sails.config.hasOwnProperty(setting) ? sails.config[setting] : sails.config)
  },
  sendEmail: (req, res) => {
    let params = req.params.all();
    if(params.subject == "t"){
      sails.hooks.email.send(
        "mainEmail",
        {
          recipientName: sails.config.email.from,
          senderName: params.name,
          subject: params.subject,
          message: params.message,
          email: params.email
        },
        {
          service: sails.config.email.service,
          auth: sails.config.email.auth,
          from: sails.config.email.from,
          testMode: false,
          to: sails.config.email.techTo,
          subject: params.subject,
          replyTo: params.email
        },
        function(error) {
          if (error) {
            sails.log(error);
            req.session.flash = error;
              return res.json({
                error: error
              });
          }
          sails.log('Mail sended');
          res.json({
            msg: 'Email sended'
          });
        }
      )
    } else {
      sails.hooks.email.send(
        "mainEmail",
        {
          recipientName: sails.config.email.from,
          senderName: params.name,
          subject: params.subject,
          message: params.message,
          email: params.email
        },
        {
          service: sails.config.email.service,
          auth: sails.config.email.auth,
          from: sails.config.email.from,
          testMode: false,
          to: sails.config.email.to,
          subject: params.subject,
          replyTo: params.email
        },
        function(error) {
          if (error) {
            sails.log(error);
            req.session.flash = error;
              return res.json({
                error: error
              });
          }
          sails.log('Mail sended');
          res.json({
            msg: 'Email sended'
          });
        }
      )
    }
    
  },
  sendCopyright: (req, res) => {
    let params = req.params.all();
    sails.hooks.email.send(
      "reportEmail",
      {
        recipientName: sails.config.email.from,
        senderName: params.fname + " " + params.lname,
        company: params.company,
        street: params.street,
        zip: params.zip,
        phone: params.phone,
        name: params.name,
        relation: params.relation,
        title: params.title,
        link: params.link,
        comment: params.comment,
        artist: params.artist,
        date: params.date
      },
      {
        service: sails.config.email.service,
        auth: sails.config.email.auth,
        from: sails.config.email.from,
        testMode: false,
        to: sails.config.email.to,
        subject: "Copyright Report Submitted",
      },
      function(error) {
        if (error) {
          sails.log(error);
          req.session.flash = error;
            return res.json({
              error: error
            });
        }
        sails.log('Mail sended');
        res.json({
          msg: 'Email sended'
        });
      }
    )
  },
  sendFeedback: (req, res) => {
    let params = req.params.all();
    sails.hooks.email.send(
      "feedbackEmail",
      {
        recipientName: sails.config.email.from,
        senderName: params.name,
        subject: "Feedback Form Submission",
        message: params.message,
        email: params.email,
        video: params.video,
        music: params.music,
        functionality: params.functionality,
        design: params.design
      },
      {
        service: sails.config.email.service,
        auth: sails.config.email.auth,
        from: sails.config.email.from,
        testMode: false,
        to: sails.config.email.to,
        subject: "Feedback Form Submission",
        replyTo: params.email
      },
      function(error) {
        if (error) {
          sails.log(error);
          req.session.flash = error;
            return res.json({
              error: error
            });
        }
        sails.log('Mail sended');
        res.json({
          msg: 'Email sended'
        });
      }
    )
  }
};
