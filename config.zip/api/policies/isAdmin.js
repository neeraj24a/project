/**
 * isAuthenticated
 *
 * @module      :: Policy
 * @description :: Simple policy to allow any authenticated administrator
 * @docs        :: http://sailsjs.org/#!documentation/policies
 *
 */
module.exports = function(req, res, next) {

  // If `req.session.me` exists, that means the user is logged in.
  if (req.session.user && req.session.user.admin) return next();

  // If this is not an HTML-wanting browser, e.g. AJAX/sockets/cURL/etc.,
  // send a 401 response letting the user agent know they need to login to
  // access this endpoint.
  if (req.wantsJSON) {
    return res.send(401);
  }
  let returnUrl = req.url;
  // Otherwise if this is an HTML-wanting browser, do a redirect.
  req.session.flash = {
    error: {
      msg: sails.__('forAdminError')
    }
  };
  return res.redirect('/login?returnto=' + returnUrl);
};