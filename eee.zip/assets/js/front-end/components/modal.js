import Vue from 'vue';

export default Vue.component('modal', {
  template: '#modal-template',
  props: ['model'],
  data: () => {
    return {
      message: '',
      type: 'prompt', // 'alert', 'prompt'
    }
  },
  mounted() {
    this.message = this.model.message;
  },
  methods: {
    confirm() {
      if(typeof this.model.confirm === 'function') this.model.confirm();
    },
    reject() {
      if(typeof this.model.reject === 'function') this.model.reject();
    }
  }
})