'use strict';
import * as axios from 'axios';
import {BASE_URL} from '../../config';

const getUserInfo = function() {
  const url = `${BASE_URL}/user-info`;
  return axios.get(url, { params: { json: true } }).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      error: error
    })
  });
}

const getConfig = function() {
  const url = `${BASE_URL}/config`;
  return axios.get(url, { params: { json: true } }).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      error: error
    })
  });
}

const getCart = () => {
  const url = `${BASE_URL}/get-cart`;
  return new Promise((resolve, reject) => {
    console.log('get cart')
    if(io.socket) {
      io.socket.get(url, {}, function (data){
        resolve(data);
      });
    }
    else {
      axios.get(url, { params: { json: true }}).then((response) => {
        resolve(response.data);
      });
    }
  })
}
const updateStreamCount = ({trackId}) => {
  const url = `${BASE_URL}/update-stream-count`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.get(`${url}/${trackId}`, {}, function (data){
        resolve(data);
      });
    }
    else {
      axios.get(`${url}/${trackId}`, {}).then((data) => {
        resolve();
      });
    }
  })
}
const addToCart = ({trackId}) => {
  const url = `${BASE_URL}/add-to-cart`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.get(`${url}/${trackId}`, {}, function (data){
        resolve(data);
      });
    }
    else {
      axios.get(`${url}/${trackId}`, {}).then((data) => {
        resolve();
      });
    }
  })
}
const removeFromCart = ({trackId}) => {
  const url = `${BASE_URL}/remove-from-cart`;
  return new Promise((resolve, reject) => {
    if(io.socket) {
      io.socket.get(`${url}/${trackId}`, {}, function (data){
        resolve(data);
      });
    }
    else {
      axios.get(`${url}/${trackId}`, {}).then((data) => {
        resolve();
      });
    }
  })
}

const trackSchema = function(updateNeeded) {
  const url = `${BASE_URL}/get-model/track`;
  return axios.get(url, { params: { json: true } }).then(response => {
    return response.data;
  }, error => {
    // error callback
    return new Error({
      message: 'Tracks model not found',
      error: error
    })
  });
}

const getZip = () => {
  const url = `${BASE_URL}/get-archive`;
  return new Promise((resolve, reject) => {
    // if(io.socket) {
    //   io.socket.get(url, {}, function (data){
    //     resolve();
    //   });
    // }
    // else {
      axios.get(url, { json: true }).then((data) => {
        resolve();
      });
    // }
  })
}
export { 
  trackSchema,
  getConfig,
  getUserInfo,
  getCart,
  updateStreamCount,
  addToCart,
  removeFromCart,
  getZip
}