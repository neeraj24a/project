jQuery(function onReady(params) {
	$(function(){
		$('.main-nav__list').slicknav({
			appendTo: '.main-nav'
		});
	});
})
