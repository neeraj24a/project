/**
 * GenrefilterController
 *
 * @description :: Server-side logic for managing genrefilters
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
  index: (req, res, next) => {
    Genrefilter
    .find()
    .exec((err, filters) => {
      // if(err) return next(err);
      if (req.param('json')) res.json(filters || {});
      else res.view('admin/genrefilter/index',{
        filters: filters || {}
      });
    })
  },
	new: function(req, res) {
    res.view('admin/genrefilter/new');
  },
  create: (req, res) => {
    Genrefilter.create(req.params.all(), (err, filter) => {
      if(err) {
        return res.serverError(err);
      }
      if (req.param('json')) res.json(filter);
      else res.redirect('/admin/genrefilter');
    })
  },
  edit: (req, res, next) => {
    Genrefilter.findOne( req.param('id'), (err, filter) => {
      if(err) return next(err);
      if(!filter) return next();
      res.view('admin/genrefilter/edit',{
        filter: filter
      })
    })
  },
  update: (req, res) => {
    Genrefilter.update(req.param('id'), req.params.all(), (err) =>  {
      if(err) {
        return res.redirect('/admin/genrefilter/edit/' + req.param('id'));
      }
      if (req.param('json')) res.json(filter);
      else res.redirect('/admin/genrefilter');
    })
  },
  destroy: (req, res, next) => {
    Genrefilter.findOne( req.param('id'), (err, filter) => {
      if(err) return next(err);
      if(!filter) return next('filter doesn\'t exist.');
      Genrefilter.destroy(req.param('id'), err => {
        if(err) return next(err);
      })
      if (req.param('json')) res.json(filter);
      else res.redirect('/admin/genrefilter');
    })
  },
  json: (req, res, next) => {
    Genrefilter
    .find()
    .exec((err, filters) => {
      if(err) return next(err);
      res.json(filters)
    })
  }
};