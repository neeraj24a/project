<div class="block-center mt-xl wd-xl">
    <!-- START panel-->
    <div class="panel panel-dark panel-flat">
        <div class="panel-heading text-center">
            <a href="#">
                <img class="block-center img-rounded" src="img/logo.png" alt="Image">
            </a>
        </div>
        <div class="panel-body">
            <p class="text-center pv">PASSWORD RESET</p>
            <?php if(Yii::app()->user->hasFlash('recoveryMessage')): ?>
                <div class="success">
                    <?php echo Yii::app()->user->getFlash('recoveryMessage'); ?>
                </div>
            <?php else: ?>
                <?php
                $form = $this->beginWidget('CActiveForm', array(
                    'id' => 'login-form',
                    'enableClientValidation' => true,
                    'clientOptions' => array(
                        'validateOnSubmit' => true,
                    ),
                    'htmlOptions' => array(
                        'autcomplete' => "off",
                        'class' => 'mb-lg',
                        'role' => 'form'
                    ),
                ));
                ?>
                    <p class="text-center">Fill with your mail to receive instructions on how to reset your password.</p>
                    <div class="form-group has-feedback">
                        <?php echo $form->labelEx($model,'username',array("class" => "text-muted")); ?>
                        <?php echo $form->textField($model, 'username', array('class' => 'form-control', 'placeholder' => 'Enter Username')); ?>
                        <span class="fa fa-envelope form-control-feedback text-muted"></span>
                        <?php echo $form->error($model,'username'); ?>
                    </div>
                    <button class="btn btn-danger btn-block" type="submit">Reset</button>
                <?php $this->endWidget(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>