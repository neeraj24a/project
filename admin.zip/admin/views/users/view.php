<div class="content-wrapper">
    <h3>User Details</h3>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo $model->username; ?>
                    <div class="col-lg-2 pull-right">
                        <a href="<?php echo Yii::app()->createUrl("admin/users/update?id=" . $model->id); ?>" class="mb-sm btn btn-warning">Update</a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <?php
						$relation = $model->relation;
                        if($model->role == 'admin'){
                            $model->relation = CHtml::link(CHtml::encode('Details'),array('admins/view','id'=>$relation));
                        } else if($model->role == 'company'){
                            $model->relation = CHtml::link(CHtml::encode('Details'),array('contacts/view','id'=>$relation));
                        } else if($model->role == 'inspector'){
                            $model->relation = CHtml::link(CHtml::encode('Details'),array('inspector/view','id'=>$relation));
                        }
                        $this->widget('zii.widgets.CDetailView', array(
                            'data' => $model,
                            'htmlOptions' => array('class' => 'table table-striped table-bordered table-hover'),
                            'attributes' => array(
                                'username',
                                'role',
                                array(               // related city displayed as a link
                                    'label'=>'Relation',
                                    'type'=>'raw',
                                    'value'=>$model->relation,
                                ),
                                'last_visit',
                            ),
                        ));
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Linked To
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <?php
						if($model->role == "admin"){
							$dataProvider = $info->userAdmin($relation);
							$url = "admin/admins/";
						} else if($model->role == "company"){
							$dataProvider = $info->userContact($relation);
							$url = "admin/contacts/";
						} else if($model->role == "inspector"){
							$dataProvider = $info->userInspector($relation);
							$url = "admin/inspectors/";
						} else if($model->role == "data_entry"){
							$dataProvider = $info->userDataEntry($relation);
							$url = "admin/dataEntry/";
						}
                        $this->widget('zii.widgets.grid.CGridView', array(
                            'id'=>'info-grid',
                            'itemsCssClass' => 'table table-bordered table-hover dataTable',
                            'dataProvider' => $dataProvider,
//                            'filter' => $model,
                            'columns' => array(
                                'first_name',
                                'last_name',
                                'email',
								/*array(
                                    'class' => 'CButtonColumn',
                                    'template' => '{v} {u}', // <-- TEMPLATE WITH THE TWO STATES
                                    'htmlOptions' => array(
                                        'width' => 120,
                                    ),
                                    'buttons' => array(
                                        'v' => array(
                                            'label' => '<i class="fa fa-search"></i>',
                                            'url' => 'Yii::app()->createUrl({{$url}}."view", array("id"=>$data->id))',
                                            'options' => array('class' => 'view', 'title' => 'View'),
                                        ),
                                        'u' => array(
                                            'label' => '<i class="fa fa-edit"></i>',
                                            'url' => 'Yii::app()->createUrl({$url}."update", array("id"=>$data->id))',
                                            'options' => array('class' => 'edit', 'title' => 'Update'),
                                        ),
                                    ),
                                )*/
                            ),
                        ));
                        ?> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
