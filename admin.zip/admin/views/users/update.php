<div class="content-wrapper">
    <h3>Update <?php echo $model->username; ?></h3>
    <div class="row">
        <div class="col-sm-12">
            <?php $this->renderPartial('_update', array('model'=>$model)); ?>
        </div>
    </div>
</div>