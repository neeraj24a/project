<div class="content-wrapper">
    <h3>Inspection Details</h3>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="col-lg-6 pull-right">
                        <a href="<?php echo Yii::app()->createUrl("admin/inspections/update?id=" . $model->id); ?>" class="mb-sm mb-lm btn btn-warning pull-right">Update</a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <?php
                        $model->company_id = Companies::model()->findByPk($model->company_id)->name;
                        $model->facility_id = Facilities::model()->findByPk($model->facility_id)->name;
                        $ins = Inspectors::model()->findByPk($model->inspector);
                        $model->inspector = $ins->first_name.' '.$ins->last_name;
                        $this->widget('zii.widgets.CDetailView', array(
                            'data' => $model,
                            'htmlOptions' => array('class' => 'table table-striped table-bordered table-hover'),
                            'attributes' => array(
                                'company_id',
                                'facility_id',
                                'inspector',
                                'insp_date',
                                'issues',
                                'resolved_status',
                                'report',
                                'notes',
                                'attachment',
                                'special',
                                'initial',
                            ),
                        ));
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>