<?php
/* @var $this CompaniesController */
/* @var $model Companies */
/* @var $form CActiveForm */
?>
<div class="row">

    <?php
    $form = $this->beginWidget('CActiveForm', array(
        'action' => Yii::app()->createUrl($this->route),
        'method' => 'get',
    ));
    ?>
	<div class="col-lg-12">
		<div class="col-lg-6">
			<?php echo $form->label($model, 'first_name'); ?>
			<?php echo $form->textField($model, 'first_name', array('size' => 60, 'maxlength' => 128, 'class' => 'form-control')); ?>
		</div>
		<div class="col-lg-6">
			<?php echo $form->label($model, 'last_name'); ?>
			<?php echo $form->textField($model, 'last_name', array('class' => 'form-control')); ?>
		</div>
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">
			<?php echo $form->label($model, 'type'); ?>
			<?php echo $form->dropDownList($model, 'type', array('company' => 'Company', 'facility' => 'Facility'),
                                array('empty' => 'Select Type','class' => 'form-control', 'ajax' => array(
						'type'=>'POST', //request type
						'url'=>CController::createUrl('contacts/getlinks'), //url to call.
						'data'=>array('type'=>'js:this.value'),
						'update'=>'#Contacts_link_id', //selector to update
						))); ?>
		</div>
		<div class="col-lg-4">
			<?php echo $form->label($model, 'link_id'); ?>
			<?php echo $form->dropDownList($model, 'link_id',array(), array('empty' => 'Select Link','class' => 'form-control')); ?>
                    <p>Note: You have choose Type First.</p>
		</div>
	</div>
    <div class="col-lg-12 m-t-20">
        <?php echo CHtml::submitButton('Search', array('class' => 'mb-sm btn btn-success')); ?>
        <a href="<?php echo Yii::app()->createUrl('admin/contacts'); ?>" class="mb-sm btn btn-warning">Reset</a>
    </div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->