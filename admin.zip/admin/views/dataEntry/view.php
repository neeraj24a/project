<div class="content-wrapper">
    <h3>Data Entry Details</h3>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo $model->first_name.' '.$model->last_name; ?>
                    <div class="col-lg-6 pull-right">
                        <a href="<?php echo Yii::app()->createUrl("admin/dataEntry/update?id=" . $model->id); ?>" class="mb-sm mb-lm btn btn-warning pull-right">Update</a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <?php
                        $comp = $model->company;
                        $model->company = Companies::model()->findByPk($comp)->name;
                        $this->widget('zii.widgets.CDetailView', array(
                            'data' => $model,
                            'htmlOptions' => array('class' => 'table table-striped table-bordered table-hover'),
                            'attributes' => array(
                                'first_name',
                                'last_name',
                                'address',
                                'city',
                                'state',
                                'zip',
                                'country',
                                'email',
                                'phone',
                                'position',
                                'company',
                            ),
                        ));
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Contacts
                    <div class="col-lg-6 pull-right">
                        <a href="<?php echo Yii::app()->createUrl("admin/companies/addcontact?id=".$model->id); ?>" class="mb-sm mb-lm btn btn-warning pull-right">Add Contact</a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        
                        <?php
                        $this->widget('zii.widgets.grid.CGridView', array(
                            'id'=>'contacts-grid',
                            'itemsCssClass' => 'table table-bordered table-hover dataTable',
                            'dataProvider' => $company->contactComp($comp),
//                            'filter' => $model,
                            'columns' => array(
                                'name',
                                'jewish',
                                'url',
                                'city',
                                'state',
                                'zip',
                                'country',
                                array(
                                    'class' => 'CButtonColumn',
                                    'template' => '{v} {u}', // <-- TEMPLATE WITH THE TWO STATES
                                    'htmlOptions' => array(
                                        'width' => 120,
                                    ),
                                    'buttons' => array(
                                        'v' => array(
                                            'label' => '<i class="fa fa-search"></i>',
                                            'url' => 'Yii::app()->createUrl("admin/companies/view", array("id"=>$data->id))',
                                            'options' => array('class' => 'view', 'title' => 'View'),
                                        ),
                                        'u' => array(
                                            'label' => '<i class="fa fa-edit"></i>',
                                            'url' => 'Yii::app()->createUrl("admin/companies/update", array("id"=>$data->id))',
                                            'options' => array('class' => 'edit', 'title' => 'Update'),
                                        )
                                    ),
                                )
                            ),
                        ));
                        ?> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>