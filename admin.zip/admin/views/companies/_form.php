<?php
/* @var $this CompaniesController */
/* @var $model Companies */
/* @var $form CActiveForm */
?>
<div class="panel panel-default">
    <div class="panel-heading">Users Form</div>
    <div class="panel-body">
        <div class="row">
        <?php $form=$this->beginWidget('CActiveForm', array(
            'id'=>'companies-form',
            // Please note: When you enable ajax validation, make sure the corresponding
            // controller action is handling ajax validation correctly.
            // There is a call to performAjaxValidation() commented in generated controller code.
            // See class documentation of CActiveForm for details on this.
            'enableAjaxValidation'=>true,
			)); ?>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'first_name'); ?>
						<?php echo $form->textField($model,'first_name',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'first_name'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'last_name'); ?>
						<?php echo $form->textField($model,'last_name',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'last_name'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'profile_pic'); ?>
						<?php echo $form->fileField($model,'profile_pic',array('class'=>'form-control')); ?>
						<?php echo $form->error($model,'profile_pic'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'jewish'); ?>
						<?php echo $form->dropDownList($model,'jewish',array('yes' => 'Yes','no' => 'No', 'unknown' => 'Unknown'),array('empty' => 'Select Jewish','class'=>'form-control')); ?>
						<?php echo $form->error($model,'jewish'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'url'); ?>
						<?php echo $form->textField($model,'url',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'url'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'address'); ?>
						<?php echo $form->textField($model,'address',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'address'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'address2'); ?>
						<?php echo $form->textField($model,'address2',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'address2'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'city'); ?>
						<?php echo $form->textField($model,'city',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'city'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'state'); ?>
						<?php echo $form->textField($model,'state',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'state'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'zip'); ?>
						<?php echo $form->textField($model,'zip',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'zip'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'country'); ?>
						<?php echo $form->textField($model,'country',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'country'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'lat'); ?>
						<?php echo $form->textField($model,'lat',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'lat'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'lng'); ?>
						<?php echo $form->textField($model,'lng',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'lng'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_address'); ?>
						<?php echo $form->textField($model,'kc_address',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_address'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_address2'); ?>
						<?php echo $form->textField($model,'kc_address2',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_address2'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_city'); ?>
						<?php echo $form->textField($model,'kc_city',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_city'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_state'); ?>
						<?php echo $form->textField($model,'kc_state',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_state'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_zip'); ?>
						<?php echo $form->textField($model,'kc_zip',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_zip'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_country'); ?>
						<?php echo $form->textField($model,'kc_country',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_country'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_lat'); ?>
						<?php echo $form->textField($model,'kc_lat',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_lat'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_lng'); ?>
						<?php echo $form->textField($model,'kc_lng',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_lng'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_comp_notes'); ?>
						<?php echo $form->textArea($model,'kc_comp_notes',array('class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_comp_notes'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-12">
					<div class="form-group">
						<?php echo $form->labelEx($model,'overview'); ?>
						<?php echo $form->textArea($model,'overview',array('class'=>'form-control')); ?>
						<?php echo $form->error($model,'overview'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'kc_lng'); ?>
						<?php echo $form->textField($model,'kc_lng',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'kc_lng'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'ar'); ?>
						<?php echo $form->textField($model,'ar',array('class'=>'form-control')); ?>
						<?php echo $form->error($model,'ar'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'rc'); ?>
						<?php echo $form->textField($model,'rc',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'rc'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'admin'); ?>
						<?php echo $form->textField($model,'admin',array('class'=>'form-control')); ?>
						<?php echo $form->error($model,'admin'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'email'); ?>
						<?php echo $form->textField($model,'email',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'email'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'email2'); ?>
						<?php echo $form->textField($model,'email2',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'email2'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'phone'); ?>
						<?php echo $form->textField($model,'phone',array('size'=>60,'maxlength'=>12,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'phone'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'phone2'); ?>
						<?php echo $form->textField($model,'phone2',array('size'=>60,'maxlength'=>12,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'phone2'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'phone3'); ?>
						<?php echo $form->textField($model,'phone3',array('size'=>60,'maxlength'=>12,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'phone3'); ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'contract_type'); ?>
						<?php echo $form->dropDownList($model,'contract_type',array('R'=>'Regular','PL'=>'Private'),array('class'=>'form-control')); ?>
						<?php echo $form->error($model,'contract_type'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">
						<?php echo $form->labelEx($model,'active'); ?>
						<?php echo $form->dropDownList($model,'active',array('yes'=>'Yes','no'=>'No'),array('class'=>'form-control')); ?>
						<?php echo $form->error($model,'active'); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-12 m-t-20">
                <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save',array('class' => 'mb-sm btn btn-info')); ?>
				<a href="<?php echo Yii::app()->createUrl("admin/companies"); ?>" class="mb-sm btn btn-warning pull-right">Back</a>
            </div>
            <?php $this->endWidget(); ?>
        </div>
    </div>
</div>