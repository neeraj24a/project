<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FP
 *
 * @author SONY
 */
class FP extends CFormModel {
    
    public $username;
    
    public function rules() {
        return array(
            array('username','required'),
        );
    }
    
    /**
     * Declares attribute labels.
     */
    public function attributeLabels() {
        return array(
            'username' => 'Enter your Username',
        );
    }
    
}
