<?php

class UsersController extends Controller {

    /**
     * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout = '//layouts/column2';

    public function beforeAction($action) {
        if (!parent::beforeAction($action)) {
            return false;
        }
        if (Yii::app()->user->id) {
            return true;
        } else {
            $this->redirect(CController::createUrl("/admin/login"));
        }
    }

    /**
     * Displays a particular model.
     * @param integer $id the ID of the model to be displayed
     */
    public function actionView($id) {
		$model = $this->loadModel($id);
		
		if($model->role == "admin"){
			$info = new Admins('userAdmin');
			$info->unsetAttributes();
		} else if($model->role == "company"){
			$info = new Contacts('userContact');
			$info->unsetAttributes();
		} else if($model->role == "inspector"){
			$info = new Inspectors('userInspector');
			$info->unsetAttributes();
		} else if($model->role == "data_entry"){
			$info = new DataEntry('userDataEntry');
			$info->unsetAttributes();
		} else {
			throw new CHttpException(404, 'Oh! Something went wrong. Try Again');
		}
		
		$this->render('view', array(
            'model' => $model,
			'info' => $info
        ));
    }

    /**
     * Creates a new model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     */
    public function actionCreate() {
        $model = new Users;

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);

        if (isset($_POST['Users'])) {
            $model->attributes = $_POST['Users'];
            $model->password = md5($model->password);
            $model->repeatPassword = md5($model->repeatPassword);
            
            if ($model->save())
                $this->redirect(array('view', 'id' => $model->id));
        }

        $this->render('create', array(
            'model' => $model,
        ));
    }

    /**
     * Updates a particular model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id the ID of the model to be updated
     */
    public function actionUpdate($id) {
        $model = $this->loadModel($id);
        $model->repeatPassword = $model->password;
        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);

        if (isset($_POST['Users'])) {
            $model->attributes = $_POST['Users'];
            if ($model->save())
                $this->redirect(array('view', 'id' => $model->id));
        }

        $this->render('update', array(
            'model' => $model,
        ));
    }

    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'admin' page.
     * @param integer $id the ID of the model to be deleted
     */
    public function actionDelete($id) {
        $this->loadModel($id)->delete();

        // if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
        if (!isset($_GET['ajax']))
            $this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('manage'));
    }

    /**
     * Lists all models.
     */
    public function actionIndex() {
        $this->redirect(array('manage'));
    }

    /**
     * Manages all models.
     */
    public function actionManage() {
        $model = new Users('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['Users']))
            $model->attributes = $_GET['Users'];

        $this->render('admin', array(
            'model' => $model,
        ));
    }

    public function actionLoadrelation() {
        $role = $_POST['role'];
        $html = '<option value="">Select Relation</option>';
        if(!empty($role)){
            if ($role == "admin") {
                $result = BaseModel::getAll('Admins');
            } else if ($role == "company") {
                $result = BaseModel::getAll('Contacts', array("condition" => "type = 'company'"));
            } else if ($role == "data_entry") {
                $result = BaseModel::getAll('DataEntry');
            } else if ($role == "inspector") {
                $result = BaseModel::getAll('Inspectors');
            }
            foreach ($result as $r) {
                $html .= '<option value="' . $r->id . '">' . $r->first_name . ' ' . $r->last_name . '</option>';
				/*$users = Users::model()->findAll(array("condition" => "relation <> '$r->id'"));
                if ($users !== null) {
                    $html .= '<option value="' . $r->id . '">' . $r->first_name . ' ' . $r->last_name . '</option>';
                }*/
            }
        }
        echo $html;
    }
    
    public function actionResetPassword($id){
        $model = new Recovery;
        
        if (isset($_POST['Recovery'])) {
            $model->attributes = $_POST['Recovery'];
            if ($model->validate()) {
                $m = Users::model()->findByPk($id);
                $m->password = md5($model->password);
                $m->repeatPassword = md5($model->repeatPassword);
                if($m->save()){
                    Yii::app()->user->setFlash('passwordChanged', "Password Changed Successfully For ". $m->username);
                    $this->redirect(array('/admin/users'));
                }
            }
        }
        $this->render('reset', array('model' => $model));
    }

    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     * @param integer $id the ID of the model to be loaded
     * @return Users the loaded model
     * @throws CHttpException
     */
    public function loadModel($id) {
        $model = Users::model()->findByPk($id);
        if ($model === null)
            throw new CHttpException(404, 'The requested page does not exist.');
        return $model;
    }

    /**
     * Performs the AJAX validation.
     * @param Users $model the model to be validated
     */
    protected function performAjaxValidation($model) {
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'users-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }
    
    public function gridRelation($row) {
        if($row->role == "admin"){
            $rec = Admins::model()->findByPk($row->relation);
            return $rec->first_name.' '.$rec->last_name;
        } else if($row->role == "company"){
            $rec = Contacts::model()->findByPk($row->relation);
            return $rec->first_name.' '.$rec->last_name;
        } else if($row->role == "data_entry"){
            $rec = DataEntry::model()->findByPk($row->relation);
            return $rec->first_name.' '.$rec->last_name;
        } else if($row->role == "inspector"){
            $rec = Inspectors::model()->findByPk($row->relation);
            return $rec->first_name.' '.$rec->last_name;
        }
    }

}
