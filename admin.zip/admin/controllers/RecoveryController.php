<?php

class RecoveryController extends Controller {

    public $layout = '//layouts/login_main';

    public function actionIndex($activekey) {
        $user = Users::model()->find(array("condition" => "active_key = '$activekey'"));

        if ($user === null) {
            throw new CHttpException(404, 'Oh! Something went wrong Please Try Again to reset your password.');
            die;
        }
        $model = new Recovery;
        if (isset($_POST['Recovery'])) {
            $model->attributes = $_POST['Recovery'];
            if ($model->validate()) {
                $m = Users::model()->findByPk($user->id);
                $m->password = md5($model->password);
                $m->repeatPassword = md5($model->repeatPassword);
                $m->active_key = "";
                if($m->save()){
                    Yii::app()->user->setFlash('passwordChanged', "Password Changed Successfully.");
                    $this->redirect(array('/admin/login'));
                } else {
                    pre($m->getErrors(), true);
                }
            } else {
                pre($model->getErrors(), true);
            }
        }
        $this->render('index', array('model' => $model));
    }

}
