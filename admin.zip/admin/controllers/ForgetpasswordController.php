<?php

class ForgetpasswordController extends Controller {

    public $layout = '//layouts/login_main';

    public function actionIndex() {
        if (Yii::app()->user->isGuest) {
            $model = new FP;
            if(isset($_POST['FP'])){
                $model->attributes = $_POST['FP'];
                if($model->validate()){
                    $username = $model->username;
                    $user = Users::model()->find(array("condition" => "username = '$username'"));
                    if($user !== null){
                        $key = create_guid();
                        $m = Users::model()->findByPk($user->id);
                        if($m->role == 'admin'){
                            $e = Admins::model()->findByPk($m->relation);
                        } else if($m->role == 'company'){
                            $e = Contacts::model()->findByPk($m->relation);
                        } else if($m->role == 'data_entry'){
                            $e = DataEntry::model()->findByPk($m->relation);
                        } else if($m->role == 'inspector'){
                            $e = Inspectors::model()->findByPk($m->relation);
                        }
                        $m->active_key = $key;
                        $m->repeatPassword = $m->password;
                        if($m->save()){
                            $activation_url = 'http://' . $_SERVER['HTTP_HOST'] . Yii::app()->createUrl("admin/recovery", array("activkey" => $key));
                            Yii::app()->user->setFlash('recoveryMessage', "Please check your email. An instructions has been sent to your email address.");
                            $subject = "Password Reset";
                            $message = AdminModule::t("You have requested the password recovery. To set a new password, go to {activation_url}.", array(
                                '{activation_url}' => $activation_url,
                            ));
                            
                            AdminModule::sendMail($e->email,$subject,$message);
                        }
                    }
                }
            }
            $this->render('index', array('model' => $model));
        } else {
            die("here");
            $this->redirect(array('/admin/dashboard'));
        }
    }

}
